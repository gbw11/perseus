"""Archive bounded runtime diagnostics and calculate time-weighted CPU samples."""
import gzip, hashlib, json, shutil, sys
from pathlib import Path

here = Path(__file__).parent
repo = here.parent/'worktrees/display-257-dual-stream'
destination = repo/'docs/verification/evidence/display-257-runtime-20261102'
destination.mkdir(parents=True, exist_ok=True)
for name in sys.argv[1:]:
    source = here/name
    data = json.loads((source/'result.json').read_text())
    samples = data.get('resources', {}).get('samples', [])
    elapsed = sum(b['at']-a['at'] for a,b in zip(samples,samples[1:]))
    means = {
        group: sum((b['at']-a['at'])*b['groups'][group]['cpu_percent']/100
                   for a,b in zip(samples,samples[1:]))/elapsed
        for group in ('sender','native_worker','other_pipeline','browser','xorg')
    } if elapsed else {}
    summary = {k:v for k,v in data.items() if k not in ('resources','initial_status','final_status')}
    summary['streams'] = {k:{a:b for a,b in v.items() if a!='markers'} for k,v in data.get('streams',{}).items()}
    summary['latency'] = {k:{a:b for a,b in v.items() if a!='milliseconds'} for k,v in data.get('latency',{}).items()}
    summary['sample_window_s'] = elapsed
    summary['cpu_mean_cores'] = means
    summary['cpu_scope'] = 'service cgroups; process birth/exit intervals undercount startup/exit CPU; Chromium/Xorg excluded from pipeline'
    if samples:
        summary['available_min_mib'] = min(s['available_bytes'] for s in samples)/1048576
        summary['pipeline_rss_first_last_mib'] = [sum(s['groups'][g]['rss_sum_bytes'] for g in ('sender','native_worker','other_pipeline'))/1048576 for s in (samples[0],samples[-1])]
        summary['rss_note'] = 'sum of per-process RSS; shared pages may be counted twice; not exclusive resident memory'
    (destination/(name+'.json.gz')).write_bytes(gzip.compress((source/'result.json').read_bytes(),mtime=0))
    (destination/(name+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({'trial':name,'error':data.get('error'),'streams':summary.get('streams'),'cpu':means,'latency':summary.get('latency')},ensure_ascii=False))
    for p in source.glob('*.jpg'): shutil.copyfile(p,destination/(name+'-'+p.name))
for name in ('runtime_probe_20261102.py','latency_marker_20261102.py','dual_physical_20261102.py','board_prepare.py','archive_runtime_evidence.py'):
    (destination/(name+'.gz')).write_bytes(gzip.compress((here/name).read_bytes(),mtime=0))
files = list((repo/'platform/services/display/router/xenova_display').glob('native_*.py'))
files += [repo/'platform/services/display/router/deploy/board-kms/stream-host.py', repo/'platform/services/display/router/xenova_display/stream.py']
(destination/'source-hashes.json').write_text(json.dumps({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
