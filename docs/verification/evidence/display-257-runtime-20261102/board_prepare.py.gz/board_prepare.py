"""Pinned SSH preparation helper; password is prompted and never saved."""
import argparse
import base64
import getpass
import hashlib
import json
from pathlib import Path
import socket
import tarfile
import secrets
import paramiko

PIN = 'xuqfEeu0Ilfz3NvCd1ffCP74KMUIOmEEp7kDGxGeYPw'

PREFLIGHT = r'''
import hashlib,importlib.util,json,os,platform,shutil,subprocess
from pathlib import Path
def run(args):
    try:
        r=subprocess.run(args,capture_output=True,text=True,timeout=12)
        return {'code':r.returncode,'stdout':r.stdout.strip()[:14000],'stderr':r.stderr.strip()[:1000]}
    except Exception as e:return {'error':type(e).__name__}
programs=['python3','pip3','Xorg','Xwayland','weston','chromium','chromium-browser','ffmpeg','ffprobe','xrandr','xauth','openbox','systemctl','opkg','rpm','dpkg','node']
result={'architecture':platform.machine(),'python':platform.python_version(),'programs':{p:shutil.which(p) for p in programs},
 'modules':{p:bool(importlib.util.find_spec(p)) for p in ['fastapi','uvicorn','pydantic','playwright','paho','xenova_display','dom0_manager','xenova_mqtt']},
 'os':Path('/etc/os-release').read_text(),'disk':run(['df','-h','/','/tmp','/opt']),
 'x_sockets':sorted(str(p) for p in Path('/tmp/.X11-unix').glob('X*')),
 'runtime_directories':sorted(str(p) for p in Path('/run/user').glob('*')),
 'graphics_processes':run(['ps','-eo','pid,user,comm']),
 'listeners':run(['ss','-lnt']), 'drm':[],
 'xen':run(['xl','list']),
 'services':run(['systemctl','list-units','--all','--no-legend','--no-pager']),
 'display_files':[]}
result['graphics_processes']['stdout']='\n'.join(l for l in result['graphics_processes'].get('stdout','').splitlines() if any(w in l.lower() for w in ['chrom','xorg','weston','xwayland','openbox','cage','sway','ffmpeg']))
result['services']['stdout']='\n'.join(l for l in result['services'].get('stdout','').splitlines() if any(w in l.lower() for w in ['xenova','display','weston','xorg','kiosk','capture','mqtt']))
for connector in Path('/sys/class/drm').glob('card*-*'):
    if not (connector/'status').exists():continue
    edid=(connector/'edid').read_bytes() if (connector/'edid').exists() else b''
    result['drm'].append({'connector':connector.name,'status':(connector/'status').read_text().strip(),
       'modes':(connector/'modes').read_text().splitlines() if (connector/'modes').exists() else [],
       'edid_sha256':hashlib.sha256(edid).hexdigest() if edid else None})
for base in ['/etc/xenova','/opt','/usr/share/xenova','/usr/lib/systemd/system']:
    directory=Path(base)
    if directory.exists(): result['display_files'] += [str(p) for p in directory.iterdir() if any(w in p.name.lower() for w in ['display','capture','kiosk','chrom','xenova','weston'])]
if shutil.which('ffmpeg'):result['ffmpeg']=run(['ffmpeg','-hide_banner','-devices']);result['encoders']=run(['ffmpeg','-hide_banner','-encoders'])
if 'encoders' in result:result['encoders']['stdout']='\n'.join(l for l in result['encoders']['stdout'].splitlines() if 'mjpeg' in l)
if shutil.which('xrandr') and result['x_sockets']:
    result['xrandr']=run(['xrandr','--display',':'+Path(result['x_sockets'][0]).name[1:],'--prop'])
print(json.dumps(result))
'''

def execute(transport, code, timeout=90):
    channel=transport.open_session(timeout=10)
    channel.settimeout(timeout)
    channel.exec_command('python3 -')
    channel.sendall(code.encode())
    channel.shutdown_write()
    out=channel.makefile('rb').read().decode()
    err=channel.makefile_stderr('rb').read().decode()
    status=channel.recv_exit_status()
    if status:raise RuntimeError(f'remote command failed ({status}): {err[:1500]}')
    return json.loads(out)

def connect():
    transport=paramiko.Transport(socket.create_connection(('192.168.30.96',22),timeout=10))
    transport.start_client(timeout=10)
    pin=base64.b64encode(hashlib.sha256(transport.get_remote_server_key().asbytes()).digest()).decode().rstrip('=')
    if pin!=PIN:
        transport.close()
        raise RuntimeError('SSH host key differs from previously verified board; no authentication attempted')
    secret=getpass.getpass('Board SSH password (not saved): ')
    transport.auth_password('root',secret)
    return transport

def stage(transport, resume_root=None):
    repo=Path(__file__).resolve().parents[2]/'S15P31E110'
    router=repo/'platform/services/display/router'
    web=repo/'frontend/apps/vm-screens/dist'
    if not (web/'index.html').is_file():raise RuntimeError('Build vm-screens first')
    release='20261027-70c3ed8-'+secrets.token_hex(3)
    root=resume_root or '/opt/xenova-display-probe/'+release
    if resume_root:
        import re
        if not re.fullmatch(r'/opt/xenova-display-probe/20261027-70c3ed8-[a-f0-9]{6}',resume_root):raise ValueError('Unexpected resume directory')
    archive=Path(__file__).parent/(release+'.tar.gz')
    manifest=[]
    with tarfile.open(archive,'w:gz') as tar:
        for source, prefix in [(router/'xenova_display','lib/xenova_display'),(web,'web'),(router/'deploy/board-probe','scripts')]:
            for path in sorted(source.rglob('*')):
                if not path.is_file() or '__pycache__' in path.parts or path.suffix=='.pyc':continue
                name=prefix+'/'+path.relative_to(source).as_posix()
                raw=path.read_bytes()
                if path.suffix in ('.sh','.py','.md'):raw=raw.replace(b'\r\n',b'\n')
                import io
                info=tarfile.TarInfo(name);info.size=len(raw)
                info.mode=0o755 if path.suffix=='.sh' else 0o644
                tar.addfile(info,io.BytesIO(raw))
                manifest.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()})
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    if transport is None:return {'bundle':str(archive),'sha256':digest,'file_count':len(manifest),'board_files_uploaded':False}
    initialize="from pathlib import Path\nimport json\np=Path("+repr(root)+")\n"
    if resume_root:initialize+="assert p.is_dir() and not p.is_symlink()\nassert all(x.name=='bundle.tar.gz' for x in p.iterdir())\n"
    else:initialize+="p.mkdir(parents=True,exist_ok=False,mode=0o700)\n"
    execute(transport,initialize+"p.chmod(0o700)\nprint(json.dumps({'directory_ready':True}))")
    sftp=paramiko.SFTPClient.from_transport(transport)
    try:
        sftp.put(str(archive),root+'/bundle.tar.gz');sftp.chmod(root+'/bundle.tar.gz',0o600)
        # Yocto's minimal Python may omit tarfile/py_compile. Extract locally
        # and send only our manifest-listed regular files through SFTP.
        made={root}
        with tarfile.open(archive,'r:gz') as tar:
            for member in tar.getmembers():
                assert member.isfile() and '..' not in Path(member.name).parts
                destination=root+'/'+member.name
                parent=root
                for part in member.name.split('/')[:-1]:
                    parent+='/'+part
                    if parent not in made:sftp.mkdir(parent,0o755);made.add(parent)
                with tar.extractfile(member) as source:sftp.putfo(source,destination)
                sftp.chmod(destination,member.mode)
    finally:sftp.close()
    code='ROOT='+repr(root)+'\nDIGEST='+repr(digest)+'\nMANIFEST='+repr(manifest)+'\n'+STAGE
    result=execute(transport,code,timeout=120)
    (Path(__file__).parent/'board-stage-20261027.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

STAGE=r'''
import hashlib,json,os,secrets,socket,subprocess,sys,time,urllib.request
from pathlib import Path
root=Path(ROOT)
archive=root/'bundle.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==DIGEST
for row in MANIFEST:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
for name in ('config','run'):(root/name).mkdir(mode=0o700)
domains=json.loads(subprocess.check_output(['xl','list','-l'],text=True,timeout=8))
live={r['config']['c_info']['name']:r['config']['c_info']['uuid'] for r in domains if r.get('domid')!=0}
roles=[('zephyr-drive-a','primary_drive','zephyr','autonomous',False),
       ('zephyr-drive-b','backup_drive','zephyr','manual',False),
       ('debian-dev','interaction','debian','message-board',True)]
assert all(name in live for name,*_ in roles),'Expected VM name missing; no guessed UUID mapping'
bindings={'schema_version':1,'scope':'candidate','bindings':[{'vm_id':live[name],'role':role,
    'expected_os':expected,'app_id':app,'agent_supported':agent} for name,role,expected,app,agent in roles]}
(root/'config/bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
display_token=secrets.token_urlsafe(32);stream_token=secrets.token_urlsafe(32)
feed={'XENOVA_DISPLAY_TOKEN':display_token,'XENOVA_DRIVER':'xen',
 'XENOVA_DISPLAY_BINDINGS':str(root/'config/bindings.json'),
 'XENOVA_DISPLAY_ALLOW_CANDIDATE_BINDINGS':'1','XENOVA_DISPLAY_WEB_ROOT':str(root/'web'),
 'XENOVA_DISPLAY_MQTT_HOST':'127.0.0.1','XENOVA_DISPLAY_MQTT_PORT':'1883'}
import shlex
for name,values in [('feed.env',feed),('kiosk.env',{'XENOVA_DISPLAY_TOKEN':display_token}),('stream.env',{'XENOVA_STREAM_TOKEN':stream_token})]:
    path=root/'config'/name
    path.write_text(''.join(key+'='+shlex.quote(value)+'\n' for key,value in values.items()))
    path.chmod(0o600)
for path in (root/'lib').rglob('*.py'):compile(path.read_bytes(),str(path),'exec')
manifest={'source_commit':'70c3ed8','prepared_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 'scope':'isolated single-HDMI sequential probe; physical graphics not verified',
 'binding_scope':'candidate app IDs; actual Xen UUIDs matched to user-confirmed VM names',
 'files':MANIFEST,'live_vm_ids':live,'packages_installed':False,'boot_configuration_changed':False,
 'vm_commands_sent':False,'system_services_restarted':False}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env={**os.environ,**feed,'PYTHONPATH':str(root/'lib'),'PYTHONPYCACHEPREFIX':str(root/'run/pycache')}
sock=socket.socket()
sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
logfile=root/'run/feed-smoke.log'
process=None
with logfile.open('w') as log:
    try:
        process=subprocess.Popen(['python3','-m','uvicorn','xenova_display.main:create_app','--factory',
            '--host','127.0.0.1','--port',str(port),'--no-access-log'],env=env,stdout=log,stderr=log)
        origin=f'http://127.0.0.1:{port}'
        def get(path):
            request=urllib.request.Request(origin+path,headers={'Authorization':'Bearer '+display_token})
            with urllib.request.urlopen(request,timeout=5) as response:return response.status,response.read()
        deadline=time.monotonic()+20
        last_probe=None
        while True:
            if process.poll() is not None:raise RuntimeError('Trial feed exited; inspect private run/feed-smoke.log')
            try:
                code,raw=get('/api/v1/display/state');state=json.loads(raw)
                last_probe={'http_status':code,'vm_count':len(state.get('vms',[])),
                    'xen_statuses':[v['sources']['xen']['status'] for v in state.get('vms',[])]}
                if state.get('vms') and all(v['sources']['xen']['status']=='fresh' for v in state['vms']):break
            except (OSError,ValueError) as error:last_probe={'error_type':type(error).__name__,'message':str(error)[:300]}
            if time.monotonic()>deadline:raise TimeoutError('Live Xen state was not ready: '+json.dumps(last_probe))
            time.sleep(.2)
        code,raw=get('/api/v1/display/presentation');presentation=json.loads(raw)
        assert get('/display/monitor-1')[0]==200 and get('/display/monitor-2')[0]==200
        checks={'live_xen_vm_count':len(state['vms']),'vm_ids':[v['vm_id'] for v in state['vms']],
            'xen_statuses':[v['sources']['xen']['status'] for v in state['vms']],
            'xen_states':[v['xen_state'] for v in state['vms']],
            'display_pages_http':{'monitor-1':200,'monitor-2':200},'presentation_output_count':len(presentation['outputs']),
            'probe_http_bind':'127.0.0.1','graphical_output_verified':False}
    finally:
        if process:
            process.terminate()
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
        display_token=None;stream_token=None
checks['temporary_feed_stopped']=process.poll() is not None
(root/'run/readiness.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'staged_path':ROOT,'archive_sha256':DIGEST,'file_count':len(MANIFEST),
    'checks':checks,'packages_installed':False,'system_services_restarted':False,
    'physical_profile_generated':False,'reason':'No X11/Chromium/FFmpeg/DRM available at preflight; EDID profile generation deferred'}))
'''

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preflight',action='store_true')
    parser.add_argument('--stage',action='store_true')
    parser.add_argument('--bundle-only',action='store_true')
    parser.add_argument('--resume-root')
    args=parser.parse_args()
    if args.bundle_only:
        print(json.dumps(stage(None)))
        raise SystemExit(0)
    t=connect()
    try:
        result=stage(t,args.resume_root) if args.stage else execute(t,PREFLIGHT)
        if not args.stage:(Path(__file__).parent/'board-preflight-20261027.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result))
    finally:t.close()
