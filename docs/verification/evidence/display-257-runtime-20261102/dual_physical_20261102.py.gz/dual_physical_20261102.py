"""Resume dual-output verification without interrupting active graphics."""
import http.client
import io
import json
import secrets
import threading
import time
import sys
from pathlib import Path
sys.path.append(r'C:\Users\SSAFY\AppData\Roaming\Python\Python311\site-packages')
import paramiko
from board_prepare import connect,execute

HERE=Path(__file__).parent
REPO=HERE.parent/'worktrees/display-257-dual-stream'
ROOT='/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs'
TURBO='--turbo' in sys.argv
trial='xenova-257-'+secrets.token_hex(4)
work='/run/'+trial
stage='/opt/xenova-kiosk-runtime/'+trial
token=secrets.token_urlsafe(32)
outdir=HERE/trial
outdir.mkdir()
t=connect()
result={'trial':trial,'scope':'two physical X11 outputs, authenticated SSH MJPEG reception; no guest input'}
result['test_date']='2026-11-02'
result['encoder_backend']='experimental_xshm_turbojpeg_quality_85' if TURBO else 'ffmpeg_mjpeg_q7'

class TunnelRaw(io.RawIOBase):
 def __init__(self,channel):super().__init__();self.channel=channel
 def readable(self):return True
 def readinto(self,buffer):
  data=self.channel.recv(len(buffer));buffer[:len(data)]=data;return len(data)

class TunnelSocket:
 def __init__(self,channel):self.channel=channel
 def makefile(self,mode,*args,**kwargs):
  assert mode=='rb'
  return io.BufferedReader(TunnelRaw(self.channel))
 def __getattr__(self,name):return getattr(self.channel,name)

def request(path,authorized=True):
 channel=t.open_channel('direct-tcpip',('127.0.0.1',8083),('127.0.0.1',0),timeout=8)
 conn=http.client.HTTPConnection('localhost',8083,timeout=8);conn.sock=TunnelSocket(channel)
 conn.request('GET',path,headers={'Authorization':'Bearer '+token} if authorized else {})
 return conn,conn.getresponse()

def receiver(identity,duration=60,label=None):
 frames=[];parser=bytearray();start=time.monotonic();error=None;conn=None
 try:
  conn,response=request('/streams/'+identity+'.mjpeg')
  if response.status!=200:raise RuntimeError('stream HTTP '+str(response.status))
  while time.monotonic()-start<duration:
   data=response.read1(65536)
   if not data:break
   parser.extend(data)
   while True:
    a=parser.find(b'\xff\xd8');b=parser.find(b'\xff\xd9',max(0,a)+2)
    if a<0:parser[:]=parser[-1:];break
    if b<0:parser[:]=parser[a:];break
    frame=bytes(parser[a:b+2]);del parser[:b+2]
    frames.append({'at':time.monotonic()-start,'bytes':len(frame)})
    if len(frames)==1:(outdir/(identity+'.jpg')).write_bytes(frame)
   if len(parser)>2097152:raise RuntimeError('oversized frame buffer')
 except Exception as exc:error=type(exc).__name__+': '+str(exc)
 finally:
  if conn:conn.close()
  elapsed=time.monotonic()-start
  result[label or identity]={'duration_s':elapsed,'frames':len(frames),'fps':len(frames)/elapsed,'jpeg_mbps':sum(f['bytes'] for f in frames)*8/elapsed/1e6,'error':error,'samples':frames}

try:
 setup=r'''
import json,pathlib,subprocess,os,time
root=pathlib.Path(ROOT);work=pathlib.Path(WORK);stage=STAGE;unit=UNIT
assert root.is_dir() and not work.exists()
work.mkdir(mode=0o700)
def active(u):return subprocess.run(['systemctl','is-active','--quiet',u]).returncode==0
prior={u:active(u) for u in ['xenova-display-kiosk.service','xenova-display-graphics.service']}
(work/'prior.json').write_text(json.dumps(prior))
import hashlib
(work/'graphics-before.sha256').write_text(hashlib.sha256(pathlib.Path('/opt/xenova-display/current/bin/graphics-session.py').read_bytes()).hexdigest())
domains=json.loads(subprocess.check_output(['xl','list','-l'],text=True,timeout=15))
(work/'domains-before.json').write_text(json.dumps([{'domid':r['domid'],'vm_id':r['config']['c_info']['uuid']} for r in domains if r['domid']]))

rollback=work/'rollback.py'
rollback.write_text('import json,pathlib,subprocess\nw=pathlib.Path('+repr(str(work))+')\np=json.loads((w/"prior.json").read_text())\nsubprocess.run(["systemctl","stop",'+repr(unit)+'])\nfor u in ["xenova-display-kiosk.service","xenova-display-graphics.service"]:\n if not p[u]:subprocess.run(["systemctl","stop",u])\noriginal=w/"graphics-session.original"\nif original.exists():\n import hashlib\n dest=pathlib.Path("/opt/xenova-display/current/bin/graphics-session.py")\n meta=json.loads((w/"patch.json").read_text())\n assert hashlib.sha256(dest.read_bytes()).hexdigest() in (meta["original"],meta["patched"])\n dest.write_bytes(original.read_bytes())\npolicy=w/"ssh-policy.original"\nif policy.exists():\n import hashlib\n dest=pathlib.Path("/etc/ssh/xenova-auth.conf")\n meta=json.loads((w/"ssh-policy.json").read_text())\n assert hashlib.sha256(dest.read_bytes()).hexdigest() in (meta["original"],meta["patched"]),"SSH policy changed externally; refusing overwrite"\n dest.write_bytes(policy.read_bytes())\n subprocess.run(["/usr/sbin/sshd","-t"],check=True,timeout=10)\n subprocess.run(["systemctl","reload",meta["service"]],check=True,timeout=15)\n')
subprocess.run(['systemd-run','--quiet','--unit='+unit+'-rollback','--on-active=240s','/usr/bin/python3',str(rollback)],check=True,timeout=12)
import hashlib
policy=pathlib.Path('/etc/ssh/xenova-auth.conf')
assert policy.is_file() and not policy.is_symlink()
raw=policy.read_bytes();lines=raw.decode().splitlines(keepends=True)
matches=[i for i,s in enumerate(lines) if s.strip().lower().startswith('permitopen ')]
assert len(matches)==1,'ambiguous PermitOpen policy'
i=matches[0]
assert '127.0.0.1:8081' in lines[i] and '127.0.0.1:8082' in lines[i]
assert '127.0.0.1:8083' not in lines[i],'8083 already permitted; review rather than change'
lines[i]=lines[i].rstrip('\r\n')+' 127.0.0.1:8083\n';patched=''.join(lines).encode()
ssh=next((u for u in ['sshd.service','ssh.service'] if active(u)),None)
assert ssh,'SSH service not found'
(work/'ssh-policy.original').write_bytes(raw)
(work/'ssh-policy.json').write_text(json.dumps({'original':hashlib.sha256(raw).hexdigest(),'patched':hashlib.sha256(patched).hexdigest(),'service':ssh}))
policy.write_bytes(patched)
subprocess.run(['/usr/sbin/sshd','-t'],check=True,timeout=10)
subprocess.run(['systemctl','reload',ssh],check=True,timeout=15)
(root/stage.lstrip('/')/'lib/xenova_display').mkdir(parents=True)
env=work/'stream.env'
env.write_text('XENOVA_STREAM_TOKEN='+__TOKEN__+'\nPYTHONPATH='+stage+'/lib\nDISPLAY=:5\nXAUTHORITY=/run/xenova-display.Xauthority\nXENOVA_DISPLAY_RUNTIME_CONFIG=/run/xenova-display-runtime.json\nXENOVA_DISPLAY_RUNTIME_STATUS=/run/xenova-kiosk/display-runtime.json\n')
env.chmod(0o600)
print(json.dumps({'prior':prior}))
'''
 for name,value in [('ROOT',ROOT),('WORK',work),('STAGE',stage),('UNIT',trial),('__TOKEN__',token)]:setup=setup.replace(name,repr(value))
 result['setup']=execute(t,setup,timeout=30)
 # sshd reload affects newly authenticated sessions. Reconnect so PermitOpen
 # is evaluated from the temporary policy, rather than the original session.
 t.close()
 t=connect()
 sftp=paramiko.SFTPClient.from_transport(t)
 try:
  sftp.put(str(REPO/'platform/services/display/router/deploy/board-kms/graphics-session.py'),work+'/graphics-session.candidate')
 finally:sftp.close()
 launch=r'''
import json,pathlib,subprocess,os,time,socket,errno,hashlib
root=pathlib.Path(ROOT);work=pathlib.Path(WORK)
prior=json.loads((work/'prior.json').read_text())
assert prior['xenova-display-graphics.service'] and prior['xenova-display-kiosk.service'],'This resumed probe requires the existing owned graphics session'
assert subprocess.run(['systemctl','is-active','--quiet','xenova-display-graphics.service']).returncode==0
quarantined=[]
status=root/'run/xenova-kiosk/display-runtime.json'
deadline=time.monotonic()+45
while time.monotonic()<deadline:
 try:
  d=json.loads(status.read_text())
  if time.monotonic()-d['updated_monotonic']<5 and len(d['outputs'])==2 and all(v['renderer_alive'] and v['status']=='mapped' and v.get('physical_verified') for v in d['outputs'].values()):break
 except (OSError,ValueError,KeyError):pass
 time.sleep(1)
else:raise RuntimeError('two physical renderer outputs not ready')
print(json.dumps({'runtime':d,'quarantined_stale_artifacts':quarantined}))
'''
 original=json.loads((HERE/'preflight_20261030.json').read_text())['graphics_sources']['/opt/xenova-display/current/bin/graphics-session.py'].encode()
 for name,value in [('ROOT',ROOT),('WORK',work),('ORIGINAL',original)]:launch=launch.replace(name,repr(value))
 result['launch']=execute(t,launch,timeout=115)
 sftp=paramiko.SFTPClient.from_transport(t)
 try:
  for p in (REPO/'platform/services/display/router/xenova_display').iterdir():
   if p.is_file() and p.suffix in ('.py','.html'):
    sftp.put(str(p),ROOT+stage+'/lib/xenova_display/'+p.name)
  if TURBO:
   sftp.put(str(HERE/'turbo_worker_20261030.py'),ROOT+stage+'/lib/xenova_display/turbo_worker.py')
   sftp.put(str(HERE/'xshm_capture_20261030.py'),ROOT+stage+'/lib/xenova_display/xshm_capture.py')
   for dependency in ['libturbojpeg.so.0.2.0','copyright']:sftp.put(str(HERE/'turbojpeg-deps'/dependency),ROOT+stage+'/lib/xenova_display/'+dependency)
 finally:sftp.close()
 start=r'''
import json,subprocess,pathlib
root=ROOT;stage=STAGE;work=pathlib.Path(WORK);unit=UNIT;turbo=USE_TURBO
source=r"""
import os,pathlib,sys,hashlib
root=pathlib.Path(ROOT)
sys.path.insert(0,str(root/STAGE.lstrip('/')/'lib'))
sys.path.append('/opt/xenova-display/current/lib')
from xenova_display import stream as relay
from xenova_display.outputs import RuntimeConfig
import uvicorn
owners=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if (p/'comm').read_text().strip()=='Xorg':owners.append(p)
 except OSError:pass
assert len(owners)==1,'ambiguous Xorg mount namespace'
mount=str(owners[0]/'ns/mnt');lib=root/'usr/lib/aarch64-linux-gnu'
assert os.readlink(mount)!=os.readlink('/proc/self/ns/mnt')
original=relay.capture_command
def command(cfg,output):
 prefix=[str(lib/'ld-linux-aarch64.so.1'),'--library-path',str(lib),str(root/'usr/bin/nsenter'),'--mount='+mount,'chroot',str(root),'/usr/bin/setpriv','--reuid=1000','--regid=1000','--clear-groups','/usr/bin/env','DISPLAY=:5','XAUTHORITY=/run/xenova-display.Xauthority']
 if USE_TURBO:
  assert output.width==1280 and output.height==720 and output.y==0 and output.x in (0,1280)
  base=STAGE+'/lib/xenova_display'
  assert hashlib.sha256((root/(base+'/libturbojpeg.so.0.2.0').lstrip('/')).read_bytes()).hexdigest()=='d8e4a12770bcdbcf027a401836f062c8596336082103543b1ecdb97c763037e4'
  return prefix+['/usr/bin/python3',base+'/turbo_worker.py',base,'pipe-xshm',str(output.x//1280),'85','900']
 return prefix+['/usr/bin/ffmpeg',*original(cfg,output)[1:]]
relay.capture_command=command
config=RuntimeConfig.load(root/'run/xenova-display-runtime.json')
app=relay.create_stream_app(config,root/'run/xenova-kiosk/display-runtime.json',os.environ['XENOVA_STREAM_TOKEN'])
relay.StreamServer(uvicorn.Config(app,host='127.0.0.1',port=8083,access_log=False,timeout_graceful_shutdown=5)).run()
""".replace('ROOT',repr(root)).replace('STAGE',repr(stage)).replace('USE_TURBO',repr(turbo))
(work/'stream-host.py').write_text(source)
args=['systemd-run','--quiet','--unit='+unit,'--property=RuntimeMaxSec=180s','--property=TimeoutStopSec=10s','--property=KillMode=control-group','--property=EnvironmentFile='+str(work/'stream.env'),'/usr/bin/python3',str(work/'stream-host.py')]
subprocess.run(args,check=True,timeout=20)
print(json.dumps({'started':True}))
'''
 # Substitute only identifier positions: nested wrapper placeholders are
 # resolved on the board and must remain quoted strings in the outer source.
 start=start.replace('root=ROOT;stage=STAGE;work=pathlib.Path(WORK);unit=UNIT;turbo=USE_TURBO', 'root='+repr(ROOT)+';stage='+repr(stage)+';work=pathlib.Path('+repr(work)+');unit='+repr(trial)+';turbo='+repr(TURBO))
 execute(t,start,timeout=30)
 for _ in range(20):
  try:
   c,r=request('/api/v1/streams');body=json.load(r);c.close()
   if r.status==200 and len(body['streams'])==2 and all(s['status']=='live' and s['physical_verified'] for s in body['streams']):result['initial_status']=body;break
  except (OSError,http.client.HTTPException):pass
  except paramiko.ChannelException as exc:
   if exc.code!=2:raise
  time.sleep(1)
 else:raise RuntimeError('physical capture not live')
 c,r=request('/api/v1/streams',False);result['unauthenticated_http']=r.status;r.read();c.close()
 print('Two physical streams ready; receiving both for 60 seconds.',flush=True)
 workers=[threading.Thread(target=receiver,args=(identity,)) for identity in ['monitor-1','monitor-2']]
 for w in workers:w.start()
 sampler=r'''
import json,os,pathlib,subprocess,time
pid=int(subprocess.check_output(['systemctl','show',UNIT,'--property=MainPID','--value'],text=True).strip())
samples=[];previous={};last=None;hz=os.sysconf('SC_CLK_TCK');page=os.sysconf('SC_PAGE_SIZE')
for _ in range(31):
 now=time.monotonic();rows={}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   head,tail=(p/'stat').read_text().rsplit(')',1);f=tail.split()
   rows[int(p.name)]={'name':head.split('(',1)[1],'parent':int(f[1]),'ticks':int(f[11])+int(f[12]),'start':int(f[19]),'rss':int(f[21])*page}
  except (OSError,ValueError,IndexError):pass
 descendants={pid}
 for _ in range(10):
  grown=descendants|{i for i,r in rows.items() if r['parent'] in descendants}
  if grown==descendants:break
  descendants=grown
 groups={k:{'cpu_percent':0,'rss_sum_bytes':0} for k in ['sender','encoder','native_worker','other_pipeline','browser','xorg']}
 for i,r in rows.items():
  name=r['name'].lower()
  group='sender' if i==pid else 'encoder' if i in descendants and 'ffmpeg' in name else 'native_worker' if i in descendants and 'python' in name else 'other_pipeline' if i in descendants else 'browser' if 'chrom' in name else 'xorg' if name=='xorg' else None
  if group:
   g=groups[group];g['rss_sum_bytes']+=r['rss'];key=(i,r['start'])
   if last and key in previous:g['cpu_percent']+=max(0,r['ticks']-previous[key])/hz/(now-last)*100
 previous={(i,r['start']):r['ticks'] for i,r in rows.items()};last=now
 mem=int(next(s.split()[1] for s in pathlib.Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
 samples.append({'at':now,'groups':groups,'available_bytes':mem})
 time.sleep(1)
print(json.dumps({'samples':samples,'cpu_percent_100_is_one_core':True,'rss_shared_pages_can_be_double_counted':True}))
'''.replace('UNIT',repr(trial))
 result['resource_samples']=execute(t,sampler,timeout=65)
 for w in workers:w.join(timeout=75)
 c,r=request('/api/v1/streams');result['final_status']=json.load(r);c.close()
 # Detaching clients must leave the local display and encoders alive. A new
 # HTTP stream receives the current capture sequence, without an old queue.
 receiver('monitor-1',10,'monitor-1-reconnect')
 result['kiosk_after_client_disconnect']=execute(t,"import json,subprocess; print(json.dumps({'kiosk':subprocess.check_output(['systemctl','is-active','xenova-display-kiosk.service'],text=True).strip(),'graphics':subprocess.check_output(['systemctl','is-active','xenova-display-graphics.service'],text=True).strip()}))",timeout=15)
except Exception as exc:
 result['error']=type(exc).__name__+': '+str(exc)
finally:
 try:
  cleanup=r'''
import json,pathlib,subprocess,shutil,hashlib
work=pathlib.Path(WORK);stage=pathlib.Path(ROOT)/STAGE.lstrip('/');unit=UNIT
if (work/'rollback.py').exists():subprocess.run(['/usr/bin/python3',str(work/'rollback.py')],check=True,timeout=60)
subprocess.run(['systemctl','stop',unit+'-rollback.timer'],capture_output=True,timeout=10)
states={u:subprocess.run(['systemctl','is-active',u],capture_output=True,text=True,timeout=10).stdout.strip() for u in ['xenova-display-kiosk.service','xenova-display-graphics.service','xenova-display-feed.service','xenova-dom0-manager.service','mosquitto.service','tailscaled.service']}
sender_journal=subprocess.run(['journalctl','-u',unit,'-n','25','--no-pager','-o','cat'],capture_output=True,text=True,timeout=10).stdout
policy_meta=json.loads((work/'ssh-policy.json').read_text()) if (work/'ssh-policy.json').exists() else None
policy_restored=policy_meta is not None and hashlib.sha256(pathlib.Path('/etc/ssh/xenova-auth.conf').read_bytes()).hexdigest()==policy_meta['original']
assert policy_restored,'SSH policy was not restored'
graphics_meta=json.loads((work/'patch.json').read_text()) if (work/'patch.json').exists() else None
graphics_restored=graphics_meta is None or hashlib.sha256(pathlib.Path('/opt/xenova-display/current/bin/graphics-session.py').read_bytes()).hexdigest()==graphics_meta['original']
assert graphics_restored
graphics_unchanged=hashlib.sha256(pathlib.Path('/opt/xenova-display/current/bin/graphics-session.py').read_bytes()).hexdigest()==(work/'graphics-before.sha256').read_text()
assert graphics_unchanged
domains_before=json.loads((work/'domains-before.json').read_text())
domains=json.loads(subprocess.check_output(['xl','list','-l'],text=True,timeout=15))
domains_after=[{'domid':r['domid'],'vm_id':r['config']['c_info']['uuid']} for r in domains if r['domid']]
domains_unchanged=sorted(domains_before,key=lambda r:r['vm_id'])==sorted(domains_after,key=lambda r:r['vm_id'])
assert str(stage).startswith(ROOT+'/opt/xenova-kiosk-runtime/xenova-257-') and stage.name==unit
if stage.exists():shutil.rmtree(stage)
assert str(work)=='/run/'+unit and unit.startswith('xenova-257-')
if work.exists():shutil.rmtree(work)
print(json.dumps({'services':states,'ssh_policy_restored':policy_restored,'graphics_source_restored':graphics_restored,'graphics_source_unchanged':graphics_unchanged,'domains_unchanged':domains_unchanged,'temporary_files_removed':not work.exists() and not stage.exists(),'sender_journal':sender_journal}))
'''
  for name,value in [('ROOT',ROOT),('WORK',work),('STAGE',stage),('UNIT',trial)]:cleanup=cleanup.replace(name,repr(value))
  result['cleanup']=execute(t,cleanup,timeout=90)
 except Exception as exc:result['cleanup_error']=type(exc).__name__+': '+str(exc)
 t.close()
 (outdir/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:({a:b for a,b in v.items() if a!='samples'} if isinstance(v,dict) else v) for k,v in result.items()}),flush=True)
