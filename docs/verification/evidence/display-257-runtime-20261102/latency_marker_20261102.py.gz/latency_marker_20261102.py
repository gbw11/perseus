"""Test-only, non-focus-taking X11 marker windows. Closing the client removes them."""
import ctypes as C
import json,os,sys,time

class Attributes(C.Structure):
 _fields_=[('background_pixmap',C.c_ulong),('background_pixel',C.c_ulong),('border_pixmap',C.c_ulong),('border_pixel',C.c_ulong),('bit_gravity',C.c_int),('win_gravity',C.c_int),('backing_store',C.c_int),('backing_planes',C.c_ulong),('backing_pixel',C.c_ulong),('save_under',C.c_int),('event_mask',C.c_long),('do_not_propagate_mask',C.c_long),('override_redirect',C.c_int),('colormap',C.c_ulong),('cursor',C.c_ulong)]
class Color(C.Structure):
 _fields_=[('pixel',C.c_ulong),('red',C.c_ushort),('green',C.c_ushort),('blue',C.c_ushort),('flags',C.c_char),('pad',C.c_char)]

x=C.CDLL('libX11.so.6')
def bind(name,args,result):
 f=getattr(x,name);f.argtypes=args;f.restype=result;return f
open_display=bind('XOpenDisplay',[C.c_char_p],C.c_void_p)
close_display=bind('XCloseDisplay',[C.c_void_p],C.c_int)
root_window=bind('XDefaultRootWindow',[C.c_void_p],C.c_ulong)
default_screen=bind('XDefaultScreen',[C.c_void_p],C.c_int)
colormap=bind('XDefaultColormap',[C.c_void_p,C.c_int],C.c_ulong)
allocate=bind('XAllocNamedColor',[C.c_void_p,C.c_ulong,C.c_char_p,C.POINTER(Color),C.POINTER(Color)],C.c_int)
create=bind('XCreateSimpleWindow',[C.c_void_p,C.c_ulong,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_uint,C.c_ulong,C.c_ulong],C.c_ulong)
change=bind('XChangeWindowAttributes',[C.c_void_p,C.c_ulong,C.c_ulong,C.POINTER(Attributes)],C.c_int)
mapped=bind('XMapRaised',[C.c_void_p,C.c_ulong],C.c_int)
background=bind('XSetWindowBackground',[C.c_void_p,C.c_ulong,C.c_ulong],C.c_int)
clear=bind('XClearWindow',[C.c_void_p,C.c_ulong],C.c_int)
sync=bind('XSync',[C.c_void_p,C.c_int],C.c_int)
destroy=bind('XDestroyWindow',[C.c_void_p,C.c_ulong],C.c_int)
create_gc=bind('XCreateGC',[C.c_void_p,C.c_ulong,C.c_ulong,C.c_void_p],C.c_void_p)
foreground=bind('XSetForeground',[C.c_void_p,C.c_void_p,C.c_ulong],C.c_int)
draw=bind('XDrawString',[C.c_void_p,C.c_ulong,C.c_void_p,C.c_int,C.c_int,C.c_char_p,C.c_int],C.c_int)
free_gc=bind('XFreeGC',[C.c_void_p,C.c_void_p],C.c_int)
d=open_display(os.environ.get('DISPLAY',':5').encode());assert d
windows=[];gcs=[]
try:
 cmap=colormap(d,default_screen(d));root=root_window(d)
 white=Color();exact=Color();assert allocate(d,cmap,b'white',C.byref(white),C.byref(exact))
 for origin in [0,1280]:
  w=create(d,root,origin+1120,620,120,72,0,0,0);assert w
  a=Attributes();a.override_redirect=1;change(d,w,512,C.byref(a));mapped(d,w)
  gc=create_gc(d,w,0,None);foreground(d,gc,white.pixel);windows.append(w);gcs.append(gc)
 sync(d,0);print(json.dumps({'ready':True}),flush=True)
 for line in sys.stdin:
  message=json.loads(line)
  if message.get('quit'):break
  identifier=message['id'];assert type(identifier) is int and 1<=identifier<=30
  rgb=[32+(identifier&3)*56,32+((identifier>>2)&3)*56,32+((identifier>>4)&3)*56]
  color=Color();assert allocate(d,cmap,('#%02x%02x%02x'%tuple(rgb)).encode(),C.byref(color),C.byref(exact))
  started=time.monotonic()
  for w,gc in zip(windows,gcs):
   background(d,w,color.pixel);clear(d,w)
   text=('LATENCY TEST '+str(identifier)).encode();draw(d,w,gc,4,16,text,len(text))
  sync(d,0)
  print(json.dumps({'id':identifier,'rgb':rgb,'board_draw_request':started,'board_draw_done':time.monotonic()}),flush=True)
finally:
 for gc in gcs:free_gc(d,gc)
 for w in windows:destroy(d,w)
 sync(d,0);close_display(d)
