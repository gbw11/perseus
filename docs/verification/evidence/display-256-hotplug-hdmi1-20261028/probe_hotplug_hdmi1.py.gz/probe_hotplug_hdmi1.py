"""Bounded dual physical HDMI trial: KMS, EDID mapping, independent native Chromium windows."""
import hashlib
import json
from pathlib import Path
import sys
import time
import paramiko

HERE=Path(__file__).parent
HELPER=HERE.parent/'display-253/probe_graphics_pages.py'
REPO=HERE.parent/'worktrees/display-256-dual-hdmi'
WEB_REPO=HERE.parent/'worktrees/display-253-vehicle-hdmi'
source=HELPER.read_text(encoding='utf-8').replace("repo=base.parents[1]/'S15P31E110'",'repo=Path('+repr(str(REPO))+')')
source=source.replace("'config','app_reports','state'","'config','state'")
ns={'__file__':str(HELPER)}
exec(compile(source.split('\nt=connect()')[0],str(HELPER),'exec'),ns)
remote=ns['remote']
web=WEB_REPO/'frontend/apps/vm-screens/dist'
files=sorted(p for p in web.rglob('*') if p.is_file())
digest=hashlib.sha256(b''.join(p.relative_to(web).as_posix().encode()+p.read_bytes() for p in files)).hexdigest()
stage='/opt/xenova-display-probe/20261028-dual-kms-'+time.strftime('%H%M%S',time.gmtime())
remote=remote.replace('/opt/xenova-display-probe/20261027-70c3ed8-6695dc',stage)
child=r'''
import json,os,signal,subprocess,sys,time
from pathlib import Path
root=Path(ROOT)
stage=Path(STAGE)
sys.path.insert(0,str(stage/'lib'))
from xenova_display.outputs import RuntimeConfig,X11Layout,parse_xrandr
from xenova_display.idle import X11IdleGuard
def interrupted(s,f):raise SystemExit('stopping bounded dual HDMI trial')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGHUP,interrupted)
processes=[];logs=[];guard=None
result={'scope':'two real KMS HDMI connectors, sandboxed independent Chromium processes','browser_pids':[],'profiles':[]}
env={**os.environ,'DISPLAY':':5','XAUTHORITY':'/run/probe.Xauthority','HOME':'/home/kiosk',
 'XDG_RUNTIME_DIR':'/run/user/1000','CHROME_DEVEL_SANDBOX':'/usr/lib/chromium/chrome-sandbox','LANG':'C.UTF-8'}
user=['/usr/bin/setpriv','--reuid=1000','--regid=1000','--clear-groups']
def command(args):return ['chroot',str(root),*args]
def runner(args,**kwargs):return subprocess.run(command([*user,'/usr/bin/'+args[0],*args[1:]]),env=env,**kwargs)
try:
    subprocess.run(['mount','--rbind','/dev',str(root/'dev')],check=True)
    subprocess.run(['mount','--make-rslave',str(root/'dev')],check=True)
    subprocess.run(['mount','-t','proc','proc',str(root/'proc')],check=True)
    subprocess.run(['mount','--bind','/sys',str(root/'sys')],check=True)
    subprocess.run(command(['/usr/lib/aarch64-linux-gnu/glib-2.0/glib-compile-schemas','/usr/share/glib-2.0/schemas']),check=True)
    cookie=__import__('secrets').token_hex(16)
    subprocess.run(command(['/usr/bin/xauth','-f','/run/probe.Xauthority','add',':5','.',cookie]),check=True,capture_output=True)
    os.chown(root/'run/probe.Xauthority',1000,1000);(root/'run/probe.Xauthority').chmod(0o600)
    log=(root/'run/dual-xorg.log').open('w');logs.append(log)
    xorg=subprocess.Popen(command(['/usr/lib/xorg/Xorg',':5','vt2','-config','/run/probe-Xorg.conf',
        '-logfile','/run/dual-Xorg.log','-nolisten','tcp','-noreset','-auth','/run/probe.Xauthority']),
        stdout=log,stderr=log,env=env,start_new_session=True)
    processes.append(xorg)
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        if xorg.poll() is not None:raise RuntimeError('KMS Xorg exited; inspect isolated Xorg log')
        if (root/'tmp/.X11-unix/X5').exists():break
        time.sleep(.2)
    else:raise TimeoutError('KMS Xorg socket missing')
    text=runner(['xrandr','--query','--props'],capture_output=True,text=True,timeout=8,check=True).stdout
    result['xrandr_before']=text
    rows=parse_xrandr(text)
    expected=json.loads((stage/'config/dual-edid.json').read_text())
    outputs=[]
    for index,(identity,edid) in enumerate(expected.items()):
        matches=[name for name,row in rows.items() if row['connected'] and row['edid_sha256']==edid]
        assert len(matches)==1,'HDMI EDID mapping missing or ambiguous: '+identity
        outputs.append({'output_id':identity,'connector':matches[0],'edid_sha256':edid,
            'width':1280,'height':720,'x':1280*index,'y':0})
    config=RuntimeConfig(backend='x11',display=':5',outputs=outputs)
    layout=X11Layout(config,runner=runner)
    mapped=layout.reconcile()
    assert all(v['physical_verified'] for v in mapped.values()),mapped
    result['layout']=mapped;result['config']=config.model_dump()
    result['xrandr_after']=runner(['xrandr','--query','--props'],capture_output=True,text=True,timeout=8,check=True).stdout
    guard=X11IdleGuard(':5',runner=runner);result['idle_disabled']=guard.enable()
    log=(root/'run/dual-openbox.log').open('w');logs.append(log)
    wm=subprocess.Popen(command([*user,'/usr/bin/openbox','--sm-disable']),stdout=log,stderr=log,env=env,start_new_session=True)
    processes.append(wm);time.sleep(1)
    for index in [1,2]:
        profile=f'/home/kiosk/chrome-dual-{index}-{stage.name}'
        result['profiles'].append(profile)
        origin=json.loads((root/'run/dual-feed-origin.json').read_text())['feed_origin']
        (root/profile.lstrip('/')/'DevToolsActivePort').unlink(missing_ok=True)
        log=(root/'run'/f'dual-chromium-{index}.log').open('w');logs.append(log)
        chrome=subprocess.Popen(command([*user,'/usr/lib/chromium/chromium','--ozone-platform=x11',
            f'--app={origin}/display/monitor-{index}','--kiosk','--no-first-run','--no-default-browser-check','--disable-background-networking',
            '--disable-translate','--disable-features=Translate','--lang=ko-KR',
            '--disable-dev-shm-usage','--disable-gpu','--force-device-scale-factor=1',
            '--window-size=1280,720',f'--window-position={(index-1)*1280},0',
            '--user-data-dir='+profile,'--remote-debugging-address=127.0.0.1','--remote-debugging-port=0']),
            stdout=log,stderr=log,env=env,start_new_session=True)
        processes.append(chrome);result['browser_pids'].append(chrome.pid)
        deadline=time.monotonic()+30
        ready=root/profile.lstrip('/')/'DevToolsActivePort'
        while time.monotonic()<deadline:
            if chrome.poll() is not None:raise RuntimeError(f'Chromium {index} exited')
            if ready.exists():break
            time.sleep(.2)
        else:raise TimeoutError('Chromium port missing')
    (root/'run/dual-ready.json').write_text(json.dumps(result))
    deadline=time.monotonic()+360
    while time.monotonic()<deadline and not (root/'run/stop-graphics-probe').exists():
        available=next(int(l.split()[1]) for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
        if available<96*1024:raise RuntimeError('memory safety limit: stop dual trial below 96MiB available')
        request=root/'run/capture-request.json'
        if request.exists():
            item=json.loads(request.read_text());request.unlink()
            p=runner(item['args'],capture_output=True,text=True,timeout=15,check=False)
            receipt={'code':p.returncode,'error':p.stderr[-1000:]}
            (root/'run'/('capture-'+item['key']+'-result.json')).write_text(json.dumps(receipt))
        time.sleep(.2)
except Exception as e:result['error']=type(e).__name__+': '+str(e)
finally:
    if guard:
        try:guard.restore();result['idle_restored']=guard.settings()
        except Exception as e:result['idle_restore_error']=str(e)
    for p in reversed(processes):
        if p.poll() is None:
            try:os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                p.wait(timeout=3)
    for log in logs:log.close()
    import shutil
    for profile in result['profiles']:
        path=root/profile.lstrip('/')
        assert path.parent==root/'home/kiosk' and path.name.startswith('chrome-dual-')
        if path.is_dir():shutil.rmtree(path)
    result['processes_stopped']=all(p.poll() is not None for p in processes)
    for name in ['dual-Xorg.log','dual-xorg.log','dual-chromium-1.log','dual-chromium-2.log']:
        p=root/'run'/name
        if p.exists():result[name]=p.read_text(errors='replace')[-6500:]
    (root/'run/graphics-child-result.json').write_text(json.dumps(result))
'''.replace('STAGE',repr(stage))
assert repr(ns['child']) in remote
remote=remote.replace(repr(ns['child']),repr(child))
a=remote.index("(root/'run/probe-Xorg.conf').write_text(")
b=remote.index('sys.dont_write_bytecode=True',a)
remote=remote[:a]+'''(root/'run/probe-Xorg.conf').write_text('''+repr('''Section "ServerFlags"
 Option "AutoAddDevices" "false"
 Option "AutoAddGPU" "false"
 Option "AllowEmptyInput" "true"
EndSection
Section "Device"
 Identifier "dual-kms"
 Driver "modesetting"
 Option "kmsdev" "/dev/dri/card0"
 Option "AccelMethod" "none"
 Option "ShadowFB" "true"
 Option "PageFlip" "false"
EndSection
Section "Screen"
 Identifier "dual-screen"
 Device "dual-kms"
 DefaultDepth 24
EndSection
''')+')\n'+remote[b:]
remote=remote.replace("'home/kiosk/chrome-probe/DevToolsActivePort'", "'run/dual-ready.json'")
remote=remote.replace("fb=os.open('/dev/fb1',os.O_RDWR)\noriginal=os.pread(fb,7179264,0);assert len(original)==7179264",r'''
fb=os.open('/dev/fb0',os.O_RDWR)
fixed=bytearray(80);variable=bytearray(160)
fcntl.ioctl(fb,0x4602,fixed,True);fcntl.ioctl(fb,0x4600,variable,True)
original_geometry=struct.unpack_from('4I',variable,0)
original_length=struct.unpack_from('I',fixed,24)[0]
assert 0<original_length<=64*1024*1024
original=os.pread(fb,original_length,0);assert len(original)==original_length
''')
a=remote.index("    ready=root/'run/dual-ready.json'")
b=remote.index('\nfinally:\n',a)
body=r'''
    ready=root/'run/dual-ready.json'
    deadline=time.monotonic()+90
    while time.monotonic()<deadline and not ready.exists():
        if child.poll() is not None:break
        time.sleep(.2)
    if not ready.exists():raise RuntimeError('Dual KMS child did not become ready')
    result['layout']=json.loads(ready.read_text())
    from contextlib import ExitStack
    with ExitStack() as stack:
        channels={};counters={}
        for index in [1,2]:
            debug_port=int((root/f'home/kiosk/chrome-dual-{index}-{stage.name}/DevToolsActivePort').read_text().splitlines()[0])
            code,_,data=http(debug_port,'/json/list');assert code==200
            target=next(v for v in json.loads(data) if v['type']=='page' and v['url']==f'http://127.0.0.1:{port}/display/monitor-{index}')
            channels[index]=stack.enter_context(wsconnect(target['webSocketDebuggerUrl'],proxy=None,open_timeout=5));counters[index]=0
        def cdp(index,method,params):
            ws=channels[index];counters[index]+=1;identifier=counters[index]
            ws.send(json.dumps({'id':identifier,'method':method,'params':params}))
            while True:
                reply=json.loads(ws.recv(timeout=10))
                if reply.get('id')==identifier:
                    if 'error' in reply:raise RuntimeError(str(reply['error']))
                    return reply.get('result',{})
        windows={}
        def inspect(index):
            dom=cdp(index,'Runtime.evaluate',{'expression':"JSON.stringify({title:document.querySelector('h1')?.innerText,text:document.body.innerText,width:innerWidth,height:innerHeight,connected:document.querySelector('main')?.getAttribute('data-connected'),guest:document.querySelector('[aria-label=\"게스트 콘텐츠\"]')?.innerText,scrollHeight:document.documentElement.scrollHeight})",'returnByValue':True})
            return {'dom':json.loads(dom['result']['value']),
                'bounds':cdp(index,'Browser.getWindowBounds',{'windowId':windows[index]})['bounds']}
        for index in [1,2]:
            window=cdp(index,'Browser.getWindowForTarget',{});windows[index]=window['windowId']
            cdp(index,'Browser.setWindowBounds',{'windowId':windows[index],'bounds':{'windowState':'normal'}})
            cdp(index,'Browser.setWindowBounds',{'windowId':windows[index],'bounds':{'left':1280*(index-1),'top':0,'width':1280,'height':720}})
            cdp(index,'Network.setCookie',{'name':'xenova_display','value':cookie,'url':f'http://127.0.0.1:{port}/','httpOnly':True,'sameSite':'Strict','secure':False})
            cdp(index,'Page.navigate',{'url':f'http://127.0.0.1:{port}/display/monitor-{index}'})
        def wait_screen(index):
            deadline=time.monotonic()+12
            expected='드라이버 계기판' if index==1 else '인포테인먼트 · 게스트 데이터'
            while time.monotonic()<deadline:
                value=inspect(index)
                if value['dom'].get('title')==expected and value['dom'].get('connected')=='true':return value
                time.sleep(.3)
            raise RuntimeError('vehicle screen did not render on output '+str(index))
        def assert_fullscreen(index,value):
            assert (value['dom']['width'],value['dom']['height'])==(1280,720),value
            assert value['bounds']['windowState']=='fullscreen',value
            assert (value['bounds']['left'],value['bounds']['top'],value['bounds']['width'],value['bounds']['height'])==(1280*(index-1),0,1280,720),value
        for index in [1,2]:
            value=wait_screen(index)
            # Navigation away from about:blank may exit fullscreen. Apply bounds
            # only after the authenticated target document has rendered.
            cdp(index,'Browser.setWindowBounds',{'windowId':windows[index],'bounds':{'windowState':'normal'}})
            cdp(index,'Browser.setWindowBounds',{'windowId':windows[index],'bounds':{'left':1280*(index-1),'top':0,'width':1280,'height':720}})
            cdp(index,'Browser.setWindowBounds',{'windowId':windows[index],'bounds':{'windowState':'fullscreen'}})
            deadline=time.monotonic()+8
            while time.monotonic()<deadline:
                value=inspect(index)
                if (value['dom']['width'],value['dom']['height'])==(1280,720) and value['bounds']['windowState']=='fullscreen':break
                time.sleep(.2)
            assert_fullscreen(index,value)
            result['pages'].append({'output_id':f'monitor-{index}',**value})
        time.sleep(3)
        for index in [1,2]:assert_fullscreen(index,inspect(index))
        def capture(index,key):
            receipt=root/'run'/f'capture-{key}-result.json';receipt.unlink(missing_ok=True)
            request={'key':key,'args':['ffmpeg','-hide_banner','-loglevel','error','-f','x11grab','-video_size','1280x720',
                '-i',f':5+{1280*(index-1)},0','-frames:v','1','-filter_threads','1','-c:v','mjpeg','-threads','1','-q:v','5',
                '-y',f'/home/kiosk/{key}.jpg']}
            (root/'run/capture-request.json').write_text(json.dumps(request))
            deadline=time.monotonic()+15
            while time.monotonic()<deadline and not receipt.exists():time.sleep(.1)
            assert receipt.exists(),'capture timeout'
            value=json.loads(receipt.read_text());assert value['code']==0,value
            return value
        result['captures']={}
        for index in [1,2]:result['captures'][f'monitor-{index}-initial']=capture(index,f'dual-monitor-{index}-initial')
        print(json.dumps({'event':'displayed','duration_s':180,'titles':[p['dom']['title'] for p in result['pages']]}),flush=True)
        # Keep both native windows visible for physical confirmation.
        # Observe real cable state; do not force layout or reposition after hotplug.
        def drm_state():
            return {p.name:(p/'status').read_text().strip() for p in Path('/sys/class/drm').glob('card*-HDMI-A-*')}
        target='card0-HDMI-A-2'
        result['hotplug']={'target':target,'initial':drm_state(),'events':[],'automatic_reposition_enabled':False}
        print(json.dumps({'event':'unplug_ready','target':target,'timeout_s':180}),flush=True)
        deadline=time.monotonic()+180
        previous=drm_state();removed=False;returned=False
        while time.monotonic()<deadline:
            current=drm_state()
            if current!=previous:
                event={'elapsed_s':round(180-(deadline-time.monotonic()),2),'connectors':current,
                       'windows':{str(i):inspect(i) for i in [1,2]}}
                result['hotplug']['events'].append(event)
                print(json.dumps({'event':'hotplug_change','connectors':current}),flush=True)
                previous=current
            if current.get(target)=='disconnected':removed=True
            if removed and current.get(target)=='connected':returned=True;break
            time.sleep(.5)
        result['hotplug']['disconnect_observed']=removed
        result['hotplug']['reconnect_observed']=returned
        if returned:
            time.sleep(10)
        result['hotplug']['final']=drm_state()
        result['final_windows']={str(index):inspect(index) for index in [1,2]}
        result['hotplug']['final_bounds_match']={str(i):result['final_windows'][str(i)]['bounds']==result['pages'][i-1]['bounds'] for i in [1,2]}
        for index in [1,2]:result['captures'][f'monitor-{index}-last']=capture(index,f'dual-monitor-{index}-last')
        result['completed_dual_display_checks']=False
        result['completed_hotplug_observation']=True
except Exception as e:result['error']=type(e).__name__+': '+str(e)
'''
remote=remote[:a]+body+remote[b:]
remote=remote.replace("child=None\ntry:", "(root/'run/dual-feed-origin.json').write_text(json.dumps({'feed_origin':f'http://127.0.0.1:{port}'}))\nchild=None\ntry:")
start=remote.index('    offset=0\n',remote.index('\nfinally:\n'))
end=remote.index('    os.close(fb)',start)
remote=remote[:start]+r'''
    now=bytearray(160);fcntl.ioctl(fb,0x4600,now,True)
    result['console_geometry_before']=original_geometry
    result['console_geometry_after']=struct.unpack_from('4I',now,0)
    if tuple(result['console_geometry_after'])==tuple(original_geometry):
        offset=0
        while offset<len(original):offset+=os.pwrite(fb,original[offset:],offset)
        restored=os.pread(fb,len(original),0)
        result['framebuffer_restored']=restored==original
        result['restoration_differing_bytes']=sum(a!=b for a,b in zip(restored,original))
    else:
        result['framebuffer_restored']=False
        result['restoration_note']='console geometry changed; skipped unsafe byte restoration'
    result['restored_active_vt']=prior_vt
'''+remote[end:]
remote=remote.replace("print(json.dumps(result))", "print(json.dumps({'event':'complete','result':result}),flush=True)")
remote=remote.replace("'scope':'isolated fbdev Xorg and sandboxed Chromium with existing display pages'", "'scope':'dual physical KMS HDMI; EDID mapping; two independent native renderer windows'")
remote=remote.replace("'existing VM overview/detail renderer; new instrument/infotainment design not implemented here'", "'252 instrument and infotainment build; actual Xen read; MQTT/sensor/media unconnected'")
compile(remote,'<dual-kms-remote>','exec')

out=HERE/('dual-kms-'+time.strftime('%Y%m%d-%H%M%S',time.gmtime()));out.mkdir()
(out/'remote-source.py').write_text(remote,encoding='utf-8')
t=ns['connect']();t.set_keepalive(10);channel=None
result={'stage':stage,'web_sha256':digest,'web_source':'252 uncommitted renderer build; source changes remain in separate 252 worktree','backend_source':'256 branch based on platform ef79127'}
try:
    ns['execute'](t,r'''
import json,shutil
from pathlib import Path
p=Path(STAGE);assert not p.exists()
p.mkdir(mode=0o700);(p/'web').mkdir();(p/'config').mkdir()
old=Path('/opt/xenova-display-probe/20261027-70c3ed8-6695dc')
shutil.copytree(old/'lib',p/'lib',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
(p/'config/bindings.json').write_bytes((old/'config/bindings.json').read_bytes())
print(json.dumps({'stage_created':True}))
'''.replace('STAGE',repr(stage)))
    pre=json.loads((HERE/'kms-preflight-20261028.json').read_text(encoding='utf-8'))
    expected={f'monitor-{i+1}':r['edid_sha256'] for i,r in enumerate(sorted(pre['drm'],key=lambda x:x['name']))}
    assert len(expected)==2
    sftp=paramiko.SFTPClient.from_transport(t)
    made={stage+'/web'}
    try:
        with sftp.open(stage+'/config/dual-edid.json','w') as f:f.write(json.dumps(expected))
        for p in files:
            target=stage+'/web/'+p.relative_to(web).as_posix();parent=target.rsplit('/',1)[0]
            if parent not in made:sftp.mkdir(parent);made.add(parent)
            sftp.put(str(p),target)
        for p in (REPO/'platform/services/display/router/xenova_display').iterdir():
            if p.is_file() and p.suffix in ['.py','.html']:sftp.put(str(p),stage+'/lib/xenova_display/'+p.name)
    finally:sftp.close()
    channel=t.open_session(timeout=10);channel.settimeout(500);channel.exec_command('python3 -')
    channel.sendall(remote.encode());channel.shutdown_write()
    for line in channel.makefile('rb'):
        item=json.loads(line)
        if item['event']=='complete':result['board']=item['result']
        else:print(json.dumps(item,ensure_ascii=False),flush=True)
    result['remote_error']=channel.makefile_stderr('rb').read().decode()[-2000:]
    result['remote_exit']=channel.recv_exit_status()
    sftp=paramiko.SFTPClient.from_transport(t)
    try:
        for name in result.get('board',{}).get('captures',{}):
            sftp.get('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs/home/kiosk/dual-'+name+'.jpg',str(out/(name+'.jpg')))
    finally:sftp.close()
finally:
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if channel:channel.close()
    t.close()
print(json.dumps({'event':'saved','directory':str(out),'error':result.get('board',{}).get('error'),'child_error':result.get('board',{}).get('graphics_child',{}).get('error'),'success':result.get('board',{}).get('completed_dual_display_checks'),'remote_error':result.get('remote_error')}),flush=True)
