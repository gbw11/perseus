from pathlib import Path
import sys,json,socket,time
sys.path.insert(0,str(Path('outputs/display-257').resolve()))
from board_prepare import connect,execute
end=time.monotonic()+180
while True:
 try:
  s=socket.create_connection(('192.168.30.96',22),timeout=3);s.close();break
 except OSError:
  if time.monotonic()>end:raise RuntimeError('SSH did not return within 180 seconds')
  time.sleep(3)
code=r'''
from pathlib import Path
import json,subprocess,time,http.client,hashlib
root=Path('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs')
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert boot!=OLD_BOOT,'reboot not yet observed'
status=root/'run/xenova-kiosk/display-runtime.json';end=time.monotonic()+100
while time.monotonic()<end:
 try:v=json.loads(status.read_text())
 except (OSError,ValueError):v={}
 values=v.get('outputs',{})
 fresh=0<=time.monotonic()-v.get('updated_monotonic',0)<3
 if v.get('layout_epoch')!=OLD_EPOCH and fresh and len(values)==2 and all(o.get('physical_verified') and o.get('renderer_alive') and o.get('applied_revision') is not None for o in values.values()):break
 time.sleep(.5)
def run(args):
 p=subprocess.run(args,text=True,capture_output=True,timeout=15);return {'code':p.returncode,'out':p.stdout,'err':p.stderr[-1000:]}
units=['xenova-display.target','xenova-display-feed.service','xenova-display-graphics.service','xenova-display-kiosk.service','xenova-dom0-manager.service']
flag=Path('/sys/firmware/devicetree/base/chosen/bootloader/tryboot')
r={'boot_id':boot,'tryboot_flag':int.from_bytes(flag.read_bytes(),'big') if flag.exists() else None,'uptime':Path('/proc/uptime').read_text().strip(),'kiosk_status':v,'fresh':fresh,'new_epoch':v.get('layout_epoch')!=OLD_EPOCH,'ready':fresh and len(values)==2 and all(o.get('physical_verified') and o.get('renderer_alive') and o.get('applied_revision') is not None for o in values.values()),'enabled':run(['systemctl','is-enabled','xenova-display.target']),'services':{n:run(['systemctl','show',n,'-p','ActiveState','-p','SubState','-p','MainPID','-p','NRestarts','-p','Result']) for n in units},'xen':run(['xl','list']),'failed':run(['systemctl','--failed','--no-pager']),'listeners':run(['ss','-lnt']),'boot_config_sha256':hashlib.sha256(Path('/boot/config.txt').read_bytes()).hexdigest(),'drm':[]}
for p in sorted(Path('/sys/class/drm').glob('card*-HDMI-A-*')):
 r['drm'].append({'name':p.name,'status':(p/'status').read_text().strip(),'edid_sha256':hashlib.sha256((p/'edid').read_bytes()).hexdigest()})
# Use the existing root-only credential in memory, never return it.
env=dict(line.split('=',1) for line in Path('/etc/xenova/display-256/feed.env').read_text().splitlines() if '=' in line)
for authenticated in [False,True]:
 conn=http.client.HTTPConnection('127.0.0.1',8082,timeout=5)
 try:
  conn.request('GET','/api/v1/display/presentation',headers={'Authorization':'Bearer '+env['XENOVA_DISPLAY_TOKEN']} if authenticated else {})
  resp=conn.getresponse();data=resp.read();r['feed_authenticated' if authenticated else 'feed_unauthenticated']={'status':resp.status}
  if authenticated and resp.status==200:r['presentation']=json.loads(data)
 except Exception as e:r['feed_error']=type(e).__name__
 finally:conn.close()
r['journal']=run(['journalctl','-b','-u','xenova-display-feed.service','-u','xenova-display-graphics.service','-u','xenova-display-kiosk.service','--no-pager','-n','60','-o','cat'])
print(json.dumps(r))
'''
old=json.loads(Path('outputs/display-256/autostart-manual-start.json').read_text(encoding='utf-8'))
code=code.replace('OLD_BOOT',repr(old['boot_id'])).replace('OLD_EPOCH',repr(old['kiosk_status']['layout_epoch']))
t=connect();t.set_keepalive(10)
try:
 r=execute(t,code,timeout=180);Path('outputs/display-256/autostart-after-reboot.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:v for k,v in r.items() if k not in ['presentation','journal']},ensure_ascii=True))
finally:t.close()
