from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('outputs/display-257').resolve()))
from board_prepare import connect,execute
code=r'''
from pathlib import Path
import json,subprocess
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
p=subprocess.run(['systemctl','enable','xenova-display.target'],capture_output=True,text=True,timeout=15)
assert p.returncode==0,p.stderr
state=subprocess.check_output(['systemctl','is-enabled','xenova-display.target'],text=True).strip()
assert state=='enabled',state
print(json.dumps({'boot_id_before':boot,'enabled':state,'enable_output':p.stderr,'new_display_services_only':True}))
'''
t=connect()
try:
 r=execute(t,code);Path('outputs/display-256/autostart-enabled-before-reboot.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
 ch=t.open_session(timeout=10);ch.exec_command('systemctl reboot');ch.settimeout(10)
 try:print('reboot_request_exit',ch.recv_exit_status())
 except Exception as e:print('reboot_connection',type(e).__name__)
finally:t.close()
