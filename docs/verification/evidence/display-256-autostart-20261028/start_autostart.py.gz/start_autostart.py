from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('outputs/display-257').resolve()))
from board_prepare import connect,execute
code=r'''
import json,subprocess,time,http.client,os
from pathlib import Path
units=['xenova-display.target','xenova-display-feed.service','xenova-display-graphics.service','xenova-display-kiosk.service']
def ctl(*args,check=True):
 p=subprocess.run(['systemctl',*args],capture_output=True,text=True,timeout=65)
 if check and p.returncode:raise RuntimeError('systemctl '+args[0]+': '+p.stderr[-1500:])
 return {'code':p.returncode,'out':p.stdout,'err':p.stderr}
r={'unit_load':{n:ctl('show',n,'-p','LoadState','-p','LoadError','-p','FragmentPath')['out'] for n in units},'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
assert all('LoadState=loaded' in s and 'LoadError=' not in s.strip().splitlines() for s in [])
assert all('LoadState=loaded' in s for s in r['unit_load'].values())
p=ctl('start','xenova-display.target',check=False);r['start']=p
status=Path('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs/run/xenova-kiosk/display-runtime.json')
deadline=time.monotonic()+120
while time.monotonic()<deadline:
 try:v=json.loads(status.read_text())
 except (OSError,ValueError):v={}
 outputs=v.get('outputs',{})
 if len(outputs)==2 and time.monotonic()-v.get('updated_monotonic',0)<3 and all(o.get('physical_verified') and o.get('renderer_alive') and o.get('applied_revision') is not None for o in outputs.values()):break
 time.sleep(.5)
r['kiosk_status']=v;r['ready']=len(v.get('outputs',{}))==2 and all(o.get('physical_verified') and o.get('renderer_alive') and o.get('applied_revision') is not None for o in v['outputs'].values())
r['services']={n:ctl('show',n,'-p','ActiveState','-p','SubState','-p','MainPID','-p','NRestarts','-p','Result')['out'] for n in units}
r['journal']=subprocess.run(['journalctl','-u','xenova-display-graphics.service','-u','xenova-display-kiosk.service','-u','xenova-display-feed.service','--no-pager','-n','65','-o','cat'],capture_output=True,text=True,timeout=10).stdout[-15000:]
if not r['ready']:ctl('stop','xenova-display.target',check=False)
print(json.dumps(r))
'''
t=connect();t.set_keepalive(10)
try:
 r=execute(t,code,timeout=240);Path('outputs/display-256/autostart-manual-start.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(r,ensure_ascii=True))
finally:t.close()
