from pathlib import Path
import json,hashlib,sys,paramiko
sys.path.insert(0,str(Path('outputs/display-257').resolve()))
from board_prepare import connect,execute
base=Path('outputs/display-256');repo=Path('outputs/worktrees/display-256-dual-hdmi');deploy=repo/'platform/services/display/router/deploy/board-kms'
release='/opt/xenova-display/releases/20261028-ffed0f8'
root='/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs'
t=connect();t.set_keepalive(10)
try:
 prep=r'''
from pathlib import Path
import json,shutil,subprocess,socket,hashlib,datetime
release=Path(RELEASE);root=Path(ROOT)
assert root.is_dir() and not root.is_symlink()
units=['xenova-display.target','xenova-display-feed.service','xenova-display-graphics.service','xenova-display-kiosk.service']
for name in units:
 assert not (Path('/etc/systemd/system')/name).exists(),'existing unit requires review: '+name
 assert not (Path('/run/systemd/system')/name).exists(),'existing runtime unit: '+name
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  n=(p/'comm').read_text().strip().lower()
  assert not any(k in n for k in ['xorg','chromium','openbox']),'active graphics process'
 except OSError:pass
sock=socket.socket();sock.bind(('127.0.0.1',8082));sock.close()
backup=Path('/root/xenova-display-backup')/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
backup.mkdir(parents=True,mode=0o700)
items=[]
for p in [Path('/boot/config.txt'),Path('/etc/xenova/display-256'),Path('/opt/xenova-display/current')]:
 items.append({'path':str(p),'exists':p.exists(),'symlink':p.is_symlink()})
 if p.is_file():shutil.copy2(p,backup/p.name)
(backup/'manifest.json').write_text(json.dumps({'items':items,'units_initially_absent':units}))
release.mkdir(parents=True,exist_ok=True);(release/'bin').mkdir(exist_ok=True);(release/'web').mkdir(exist_ok=True);(release/'units').mkdir(exist_ok=True)
old=Path('/opt/xenova-display-probe/20261027-70c3ed8-6695dc/lib')
assert old.is_dir()
shutil.copytree(old,release/'lib',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
print(json.dumps({'backup':str(backup),'release':str(release),'units_initially_absent':True}))
'''.replace('RELEASE',repr(release)).replace('Path(ROOT)','Path('+repr(root)+')')
 pre=execute(t,prep)
 (base/'autostart-backup.json').write_text(json.dumps(pre,indent=2)+'\n',encoding='utf-8')
 sftp=paramiko.SFTPClient.from_transport(t)
 try:
  for p in deploy.iterdir():
   if p.is_file():sftp.put(str(p),release+('/bin/' if p.suffix=='.py' else '/units/')+p.name)
  for p in (repo/'platform/services/display/router/xenova_display').iterdir():
   if p.is_file() and p.suffix in ['.py','.html']:sftp.put(str(p),release+'/lib/xenova_display/'+p.name)
  web=Path('outputs/worktrees/display-253-vehicle-hdmi/frontend/apps/vm-screens/dist')
  made={release+'/web'}
  for p in web.rglob('*'):
   if not p.is_file():continue
   target=release+'/web/'+p.relative_to(web).as_posix();parent=target.rsplit('/',1)[0]
   if parent not in made:
    try:sftp.stat(parent)
    except FileNotFoundError:sftp.mkdir(parent)
    made.add(parent)
   sftp.put(str(p),target)
 finally:sftp.close()
 setup=r'''
from pathlib import Path
import json,os,secrets,subprocess,hashlib,sys,shutil
release=Path(RELEASE);root=Path(ROOT)
sys.path.insert(0,str(release/'lib'))
from dom0_manager.config import Settings
from dom0_manager.drivers import build_driver
actual={str(v.vm_id):v.name for v in build_driver(Settings(driver='xen')).list_domains()}
expected={'64b1ab38-89cc-4454-8d94-b8201f4cdd33':'zephyr-drive-a','a77fa3fc-64e5-4d66-8225-2a49920bda2a':'zephyr-drive-b','055226af-b876-4707-8b5d-99e7f33ad3d7':'debian-dev'}
assert all(actual.get(k)==v for k,v in expected.items()),'actual UUID/name mismatch'
old=Path('/opt/xenova-display-probe/20261027-70c3ed8-6695dc/config/bindings.json')
bindings=json.loads(old.read_text());rows=bindings if isinstance(bindings,list) else bindings['bindings']
assert {r['vm_id'] for r in rows}==set(expected)
cfg=Path('/etc/xenova/display-256');cfg.mkdir(parents=True,exist_ok=True,mode=0o700);cfg.chmod(0o700)
(cfg/'bindings.json').write_text(json.dumps({'schema_version':1,'scope':'deployment','bindings':rows},indent=2)+'\n')
token=secrets.token_urlsafe(48)
(cfg/'feed.env').write_text('PYTHONPATH='+str(release/'lib')+'\nXENOVA_DISPLAY_BINDINGS='+str(cfg/'bindings.json')+'\nXENOVA_DISPLAY_WEB_ROOT='+str(release/'web')+'\nXENOVA_DISPLAY_TOKEN='+token+'\n')
(cfg/'kiosk.env').write_text('XENOVA_DISPLAY_TOKEN='+token+'\n')
for p in cfg.iterdir():p.chmod(0o600)
connectors=sorted(Path('/sys/class/drm').glob('card*-HDMI-A-*'),key=lambda p:p.name)
assert len(connectors)==2 and all((p/'status').read_text().strip()=='connected' for p in connectors)
runtime={'backend':'x11','display':':5','feed_origin':'http://127.0.0.1:8082','outputs':[{'output_id':'monitor-'+str(i+1),'connector':'HDMI-'+str(i+1),'edid_sha256':hashlib.sha256((p/'edid').read_bytes()).hexdigest(),'width':1280,'height':720,'x':1280*i,'y':0} for i,p in enumerate(connectors)]}
from xenova_display.outputs import RuntimeConfig
RuntimeConfig.model_validate(runtime)
(root/'run/xenova-display-runtime.json').write_text(json.dumps(runtime,indent=2)+'\n');(root/'run/xenova-display-runtime.json').chmod(0o644)
xorg='''+repr('''Section "ServerFlags"
 Option "AutoAddDevices" "false"
 Option "AutoAddGPU" "false"
 Option "AllowEmptyInput" "true"
EndSection
Section "Device"
 Identifier "xenova-kms"
 Driver "modesetting"
 Option "kmsdev" "/dev/dri/card0"
 Option "AccelMethod" "none"
 Option "ShadowFB" "true"
 Option "PageFlip" "false"
EndSection
Section "Screen"
 Identifier "xenova-screen"
 Device "xenova-kms"
 DefaultDepth 24
EndSection
''')+r'''
(root/'run/xenova-display-Xorg.conf').write_text(xorg)
# Publish the immutable release; never delete the graphics rootfs or old release.
link=Path('/opt/xenova-display/current');assert not link.exists() and not link.is_symlink()
link.symlink_to(release,target_is_directory=True)
installed=[]
for p in (release/'units').iterdir():
 text=p.read_text().replace('@GRAPHICS_ROOT@',str(root))
 dest=Path('/etc/systemd/system')/p.name;assert not dest.exists();dest.write_text(text);dest.chmod(0o644);installed.append(str(dest))
unitnode=root/'opt/xenova-kiosk-runtime/20261028/lib/xenova_display'
for n in ['__init__.py','kiosk.py','outputs.py','idle.py']:shutil.copyfile(release/'lib/xenova_display'/n,unitnode/n)
subprocess.run(['systemctl','daemon-reload'],check=True)
verify=subprocess.run(['systemd-analyze','verify',*installed],capture_output=True,text=True,timeout=30)
print(json.dumps({'uuid_names':actual,'runtime_config':runtime,'installed_units':installed,'verify':{'code':verify.returncode,'out':verify.stdout[-1000:],'err':verify.stderr[-4000:]},'autostart_enabled':False,'tokens_printed':False}))
'''.replace('RELEASE',repr(release)).replace('Path(ROOT)','Path('+repr(root)+')')
 setup=setup.replace('RELEASE',repr(release)).replace('Path(ROOT)','Path('+repr(root)+')')
 r=execute(t,setup)
 (base/'autostart-staged.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(r,ensure_ascii=True))
finally:t.close()
