from pathlib import Path
import sys,json,paramiko
sys.path.insert(0,str(Path('outputs/display-257').resolve()))
from board_prepare import connect,execute
base=Path('outputs/display-256');root='/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs'
code=r'''
from pathlib import Path
import json,subprocess,hashlib,os
root=Path(ROOT);rows=[]
for i in [1,2]:
 args=['systemd-run','--quiet','--wait','--collect','--pipe','--unit=xenova-display-capture-'+str(i),'--property=RootDirectory='+str(root),'--property=MountAPIVFS=yes','--property=BindPaths='+str(root/'run')+':/run '+str(root/'tmp')+':/tmp','--setenv=DISPLAY=:5','--setenv=XAUTHORITY=/run/xenova-display.Xauthority','/usr/bin/setpriv','--reuid=1000','--regid=1000','--clear-groups','/usr/bin/ffmpeg','-hide_banner','-loglevel','error','-f','x11grab','-video_size','1280x720','-i',':5+'+str(1280*(i-1))+',0','-frames:v','1','-filter_threads','1','-c:v','mjpeg','-threads','1','-q:v','5','-y','/home/kiosk/hdmi-autostart-'+str(i)+'.jpg']
 p=subprocess.run(args,text=True,capture_output=True,timeout=30)
 rows.append({'output_id':'monitor-'+str(i),'code':p.returncode,'err':p.stderr[-2000:]})
 assert p.returncode==0,rows[-1]
release=Path('/opt/xenova-display/current').resolve()
manifest={str(p.relative_to(release)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['bin','units','web','lib/xenova_display'] for p in (release/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
permissions={str(p):oct(p.stat().st_mode & 0o777) for p in Path('/etc/xenova/display-256').iterdir()}
print(json.dumps({'captures':rows,'release':str(release),'manifest':manifest,'private_file_modes':permissions,'no_credential_contents_returned':True}))
'''.replace('Path(ROOT)','Path('+repr(root)+')')
t=connect()
try:
 r=execute(t,code,timeout=90);(base/'autostart-captures-manifest.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
 sftp=paramiko.SFTPClient.from_transport(t)
 try:
  for i in [1,2]:sftp.get(root+'/home/kiosk/hdmi-autostart-'+str(i)+'.jpg',str(base/('autostart-monitor-'+str(i)+'.jpg')))
 finally:sftp.close()
 print(json.dumps({'captures':r['captures'],'release':r['release'],'private_file_modes':r['private_file_modes'],'file_count':len(r['manifest'])}))
finally:t.close()
