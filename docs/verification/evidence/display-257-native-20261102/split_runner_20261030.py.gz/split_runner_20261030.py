"""Bounded on-board stage isolation. No network/VM/boot configuration changes."""
import errno,fcntl,hashlib,json,os,shutil,signal,socket,struct,subprocess,sys,time
from pathlib import Path

ROOT=Path(sys.argv[1]);WORK=Path(sys.argv[2]);SECONDS=int(sys.argv[3]);UNIT=WORK.name
MODE=sys.argv[4] if len(sys.argv)>4 else 'split'
assert MODE in ('split','turbo','xshm')
assert ROOT==Path('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs')
assert WORK.parent==Path('/run') and UNIT.startswith('xenova-257-split-') and 5<=SECONDS<=25
DATA=ROOT/'home/kiosk'/UNIT
GRAPHICS=Path('/opt/xenova-display/current/bin/graphics-session.py')
UNITS=['xenova-display-kiosk.service','xenova-display-graphics.service']
PIDS=[]
def emit(event,**data):print(json.dumps({'event':event,**data}),flush=True)
def run(args,timeout=15):
 p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
 return {'code':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()[-1500:]}
def active(unit):return run(['systemctl','is-active',unit])['stdout']=='active'
def vt():
 fd=os.open('/dev/tty0',os.O_RDONLY)
 try:
  raw=bytearray(6);fcntl.ioctl(fd,0x5603,raw,True);return struct.unpack('3H',raw)[0]
 finally:os.close(fd)
def inventory():
 paths=[]
 for base in [Path('/sys/devices/system/cpu/cpufreq'),Path('/sys/devices/system/cpu')]:
  patterns=['policy*/scaling_cur_freq','policy*/scaling_governor','policy*/cpuinfo_max_freq'] if base.name=='cpufreq' else ['cpu*/cpufreq/scaling_cur_freq']
  for pattern in patterns:
   for p in base.glob(pattern):
    try:paths.append({'path':str(p),'value':p.read_text().strip()})
    except OSError:pass
 temperatures=[]
 for p in Path('/sys/class/thermal').glob('thermal_zone*/temp'):
  try:temperatures.append({'zone':p.parent.name,'millicelsius':int(p.read_text())})
  except (OSError,ValueError):pass
 mem={s.split(':')[0]:s.split(':')[1].strip() for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith(('MemTotal:','MemAvailable:','SwapTotal:'))}
 return {'clock_frequency_and_governor':paths,'temperatures':temperatures,'memory':mem,'loadavg':Path('/proc/loadavg').read_text().strip(),'xen_domains':run(['xl','list']),'xen_vcpus':run(['xl','vcpu-list']),'vt':vt(),'throttling':run(['vcgencmd','get_throttled']) if shutil.which('vcgencmd') else 'vcgencmd unavailable'}
def proc_snapshot():
 rows={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   head,tail=(p/'stat').read_text().rsplit(')',1);f=tail.split();name=head.split('(',1)[1]
   if name.lower()=='xorg' or 'chrom' in name.lower():rows[(int(p.name),int(f[19]))]={'ticks':int(f[11])+int(f[12]),'group':'xorg' if name.lower()=='xorg' else 'browser'}
  except (OSError,ValueError,IndexError):pass
 return rows
def core_ticks(before,after,elapsed):
 hz=os.sysconf('SC_CLK_TCK');groups={'browser':0,'xorg':0}
 for k,p in after.items():
  if k in before:groups[p['group']]+=max(0,p['ticks']-before[k]['ticks'])/hz/elapsed
 return groups

prior={u:active(u) for u in UNITS}
before_inventory=inventory();results=[];rollback_ready=False
(WORK/'prior.json').write_text(json.dumps(prior))
rollback='''import hashlib,json,pathlib,subprocess
w=pathlib.Path(WORK);p=json.loads((w/'prior.json').read_text())
for u in ['xenova-display-kiosk.service','xenova-display-graphics.service']:
 if not p[u]:subprocess.run(['systemctl','stop',u],timeout=45)
original=w/'graphics.original'
if original.exists():
 dest=pathlib.Path('/opt/xenova-display/current/bin/graphics-session.py');m=json.loads((w/'graphics.json').read_text())
 assert hashlib.sha256(dest.read_bytes()).hexdigest() in [m['original'],m['candidate']],'graphics source changed externally'
 dest.write_bytes(original.read_bytes())
'''.replace('WORK',repr(str(WORK)))
(WORK/'rollback.py').write_text(rollback)
try:
 assert run(['systemctl','is-active','xenova-display-stream.service'])['stdout']!='active','an existing screen sender is active'
 subprocess.run(['systemd-run','--quiet','--unit='+UNIT+'-rollback','--on-active=600s','/usr/bin/python3',str(WORK/'rollback.py')],check=True,timeout=15)
 rollback_ready=True
 old=GRAPHICS.read_bytes();candidate=(WORK/'graphics.candidate').read_bytes()
 expected=(WORK/'graphics.expected').read_bytes()
 assert old in (expected,candidate),'installed graphics supervisor differs from verified source'
 if not prior[UNITS[1]]:
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    if (p/'comm').read_text().strip().lower()=='xorg':raise RuntimeError('unowned Xorg exists')
   except FileNotFoundError:pass
  sock=ROOT/'tmp/.X11-unix/X5'
  if sock.exists():
   with socket.socket(socket.AF_UNIX) as s:
    s.settimeout(1)
    try:s.connect(str(sock))
    except OSError as exc:
     if exc.errno not in (errno.ECONNREFUSED,errno.ENOENT):raise
    else:raise RuntimeError('X5 still accepts clients')
  for p in [ROOT/'tmp/.X5-lock',sock]:
   if p.exists():p.unlink()
  (WORK/'graphics.original').write_bytes(old)
  (WORK/'graphics.json').write_text(json.dumps({'original':hashlib.sha256(old).hexdigest(),'candidate':hashlib.sha256(candidate).hexdigest()}))
  GRAPHICS.write_bytes(candidate)
 subprocess.run(['systemctl','reset-failed',*UNITS],check=True,timeout=10)
 subprocess.run(['systemctl','start',UNITS[0]],check=True,timeout=60)
 status=ROOT/'run/xenova-kiosk/display-runtime.json';deadline=time.monotonic()+40
 while time.monotonic()<deadline:
  try:
   layout=json.loads(status.read_text())
   if time.monotonic()-layout['updated_monotonic']<5 and all(v['status']=='mapped' and v['renderer_alive'] and v['physical_verified'] for v in layout['outputs'].values()) and len(layout['outputs'])==2:break
  except (OSError,ValueError,KeyError):pass
  time.sleep(.5)
 else:raise RuntimeError('two physical windows not ready')
 assert [layout['outputs'][i]['rectangle'] for i in ['monitor-1','monitor-2']]==[[0,0,1280,720],[1280,0,1280,720]]
 owners=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if (p/'comm').read_text().strip()=='Xorg':owners.append(p)
  except OSError:pass
 assert len(owners)==1
 mount=str(owners[0]/'ns/mnt');lib=ROOT/'usr/lib/aarch64-linux-gnu'
 assert os.readlink(mount)!=os.readlink('/proc/self/ns/mnt')
 prefix=[str(lib/'ld-linux-aarch64.so.1'),'--library-path',str(lib),str(ROOT/'usr/bin/nsenter'),'--mount='+mount,'chroot',str(ROOT),'/usr/bin/setpriv','--reuid=1000','--regid=1000','--clear-groups','/usr/bin/env','DISPLAY=:5','XAUTHORITY=/run/xenova-display.Xauthority','/usr/bin/ffmpeg']
 DATA.mkdir(mode=0o700);os.chown(DATA,1000,1000)
 if MODE in ('turbo','xshm'):
  for name in ['libturbojpeg.so.0.2.0','turbo_worker.py','xshm_capture.py','copyright']:
   shutil.copyfile(WORK/name,DATA/name)
  assert hashlib.sha256((DATA/'libturbojpeg.so.0.2.0').read_bytes()).hexdigest()=='d8e4a12770bcdbcf027a401836f062c8596336082103543b1ecdb97c763037e4'
 emit('ready',inventory=before_inventory,layout=layout,seconds_per_case=SECONDS)
 common=['-hide_banner','-loglevel','error','-nostdin','-y','-stats_period','1','-progress','pipe:1']
 def live(i):return ['-f','x11grab','-draw_mouse','0','-framerate','5','-video_size','1280x720','-i',':5+'+str(i*1280)+',0']
 def output(stage):
  if stage=='capture':return ['-an','-c:v','copy','-f','null','/dev/null']
  if stage=='convert':return ['-an','-filter_threads','1','-vf','format=yuvj420p','-c:v','wrapped_avframe','-f','null','/dev/null']
  return ['-an','-filter_threads','1','-vf','scale=1280:720:flags=fast_bilinear:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1280:720:(ow-iw)/2:(oh-ih)/2,format=yuvj420p','-c:v','mjpeg','-q:v','7','-threads','1','-f','mjpeg','/dev/null']
 # Retain one actual frame from each HDMI source for paced offline comparisons.
 for i in range(2):
  for fmt in ['bgr0','yuvj420p']:
   path='/home/kiosk/'+UNIT+'/monitor-'+str(i+1)+'.'+fmt
   args=prefix+common+live(i)+['-frames:v','1','-an','-filter_threads','1','-vf','format='+fmt,'-c:v','rawvideo','-threads','1','-pix_fmt',fmt,'-f','rawvideo',path]
   p=subprocess.run(args,capture_output=True,text=True,timeout=15)
   assert p.returncode==0,p.stderr[-1000:]
 def offline(i,fmt):
  return ['-stream_loop','-1','-re','-f','rawvideo','-pixel_format',fmt,'-video_size','1280x720','-framerate','5','-i','/home/kiosk/'+UNIT+'/monitor-'+str(i+1)+'.'+fmt]
 cases=[]
 for stage_name in ['capture','convert','jpeg']:
  for count in [1,2]:cases.append((stage_name+'-'+str(count),[prefix+common+live(i)+['-t',str(SECONDS)]+output(stage_name) for i in range(count)]))
 for fmt in ['bgr0','yuvj420p']:
  cases.append(('offline-'+fmt+'-jpeg-2',[prefix+common+offline(i,fmt)+['-t',str(SECONDS)]+output('jpeg') for i in range(2)]))
 shared=prefix+common+['-f','x11grab','-draw_mouse','0','-framerate','5','-video_size','2560x720','-i',':5+0,0','-filter_complex_threads','1','-filter_complex','[0:v]split=2[a][b];[a]crop=1280:720:0:0,format=yuvj420p[v1];[b]crop=1280:720:1280:0,format=yuvj420p[v2]']
 for v in ['v1','v2']:shared+=['-map','['+v+']','-t',str(SECONDS),'-c:v','mjpeg','-q:v','7','-threads','1','-f','mjpeg','/dev/null']
 cases.append(('shared-capture-jpeg-2',[shared]))
 quality_metrics=[]
 if MODE=='xshm':
  cases=[('jpeg-2',[prefix+common+live(i)+['-t',str(SECONDS)]+output('jpeg') for i in range(2)])]
  for quality in [85,90]:
   cases.append(('turbo-xshm-'+str(quality)+'-2',[prefix[:-1]+['/usr/bin/python3','/home/kiosk/'+UNIT+'/turbo_worker.py','/home/kiosk/'+UNIT,'xshm',str(i),str(quality),str(SECONDS*5)] for i in range(2)]))
 if MODE=='turbo':
  # Calibrate JPEG quality using exactly the same captured source frames.
  for i in range(2):
   raw='/home/kiosk/'+UNIT+'/monitor-'+str(i+1)+'.bgr0'
   baseline='/home/kiosk/'+UNIT+'/baseline-'+str(i)+'.jpg'
   command=prefix+common+['-f','rawvideo','-pixel_format','bgr0','-video_size','1280x720','-i',raw,'-frames:v','1','-an','-filter_threads','1','-vf','format=yuvj420p','-c:v','mjpeg','-q:v','7','-threads','1',baseline]
   r=subprocess.run(command,capture_output=True,text=True,timeout=20);assert r.returncode==0,r.stderr[-500:]
   native=prefix[:-1]+['/usr/bin/python3','/home/kiosk/'+UNIT+'/turbo_worker.py','/home/kiosk/'+UNIT,'offline',str(i)]
   candidates=[baseline]
   for quality in [85,90,95]:
    r=subprocess.run(native+[str(quality),'1'],capture_output=True,text=True,timeout=20);assert r.returncode==0,r.stderr[-1000:]
    candidates.append('/home/kiosk/'+UNIT+'/offline-'+str(quality)+'-'+str(i)+'.jpg')
   for image in candidates:
    row={'source_index':i,'image':Path(image).name,'bytes':(ROOT/image.lstrip('/')).stat().st_size}
    for metric in ['psnr','ssim']:
     command=prefix+['-hide_banner','-loglevel','info','-nostdin','-f','rawvideo','-pixel_format','bgr0','-video_size','1280x720','-i',raw,'-i',image,'-filter_complex_threads','1','-filter_complex','[0:v]format=gbrp[ref];[1:v]format=gbrp[img];[ref][img]'+metric,'-frames:v','1','-f','null','/dev/null']
     r=subprocess.run(command,capture_output=True,text=True,timeout=20);assert r.returncode==0,r.stderr[-1000:]
     row[metric+'_log']=[s for s in r.stderr.splitlines() if 'PSNR' in s or 'SSIM' in s]
    quality_metrics.append(row)
  emit('quality_complete',metrics=quality_metrics)
  # Keep a baseline with the original command, then a probe-shortened baseline.
  cases=[('jpeg-2',[prefix+common+live(i)+['-t',str(SECONDS)]+output('jpeg') for i in range(2)]),('jpeg-2-no-probe',[prefix+common+['-probesize','32','-analyzeduration','0','-fpsprobesize','0']+live(i)+['-t',str(SECONDS)]+output('jpeg') for i in range(2)])]
  for mode in ['offline','live']:
   for quality in [85,90,95]:
    commands=[prefix[:-1]+['/usr/bin/python3','/home/kiosk/'+UNIT+'/turbo_worker.py','/home/kiosk/'+UNIT,mode,str(i),str(quality),str(SECONDS*5)] for i in range(2)]
    cases.append(('turbo-'+mode+'-'+str(quality)+'-2',commands))
 for name,commands in cases:
  emit('case_start',name=name)
  p0=proc_snapshot();start=time.monotonic();cpu=0
  processes=[subprocess.Popen(c,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True) for c in commands];PIDS=processes
  rows=[]
  try:
   for p in processes:
    # Observe the exited child without reaping it, so /proc still contains its
    # final CPU ticks. Yocto's minimal Python has no optional resource module.
    deadline=time.monotonic()+SECONDS+20
    while True:
     info=os.waitid(os.P_PID,p.pid,os.WEXITED|os.WNOWAIT|os.WNOHANG)
     if info is not None:break
     if time.monotonic()>deadline:raise TimeoutError('FFmpeg benchmark exceeded its bound')
     time.sleep(.1)
    stat=(Path('/proc')/str(p.pid)/'stat').read_text().rsplit(')',1)[1].split()
    cpu+=sum(int(stat[i]) for i in [11,12,13,14])/os.sysconf('SC_CLK_TCK')
    stdout,stderr=p.communicate(timeout=SECONDS+20)
    progress={}
    for s in stdout.splitlines():
     if '=' in s:
      k,v=s.split('=',1);progress[k]=v
    rows.append({'returncode':p.returncode,'progress':progress,'stderr_tail':stderr[-1000:]})
  finally:
   for p in processes:
    if p.poll() is None:
     os.killpg(p.pid,signal.SIGTERM)
     try:p.wait(timeout=4)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
  elapsed=time.monotonic()-start;p1=proc_snapshot()
  row={'case':name,'wall_seconds':elapsed,'ffmpeg_cpu_seconds':cpu,'ffmpeg_average_cores':cpu/elapsed,'other_average_cores':core_ticks(p0,p1,elapsed),'processes':rows,'environment':inventory()}
  results.append(row);(WORK/'results.json').write_text(json.dumps({'before':before_inventory,'cases':results,'quality_metrics':quality_metrics},indent=2))
  emit('case_complete',name=name,wall_seconds=elapsed,ffmpeg_average_cores=cpu/elapsed,other_average_cores=row['other_average_cores'],frames=[r['progress'].get('frame') for r in rows],errors=[r['stderr_tail'] for r in rows if r['returncode']])
  assert all(r['returncode']==0 for r in rows),'benchmark failed'
 emit('complete',cases=len(results))
except Exception as exc:
 emit('error',kind=type(exc).__name__,message=str(exc))
 raise
finally:
 for p in PIDS:
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
 if rollback_ready:
  subprocess.run(['/usr/bin/python3',str(WORK/'rollback.py')],check=True,timeout=110)
  subprocess.run(['systemctl','stop',UNIT+'-rollback.timer'],capture_output=True,timeout=10)
 if DATA.exists():
  assert DATA.parent==ROOT/'home/kiosk' and DATA.name==UNIT
  if MODE in ('turbo','xshm'):
   samples=WORK/'samples';samples.mkdir(exist_ok=True)
   for p in DATA.iterdir():
    if p.is_file() and p.suffix in ('.jpg','.json'):shutil.copyfile(p,samples/p.name)
  shutil.rmtree(DATA)
 final={'prior':prior,'services':{u:run(['systemctl','is-active',u])['stdout'] for u in [*UNITS,'xenova-dom0-manager.service','xenova-display-feed.service','mosquitto.service','tailscaled.service']},'graphics_source_restored':not (WORK/'graphics.original').exists() or GRAPHICS.read_bytes()==(WORK/'graphics.original').read_bytes(),'vt_before':before_inventory['vt'],'vt_after':vt(),'temporary_frames_removed':not DATA.exists(),'network_configuration_changed':False}
 (WORK/'cleanup.json').write_text(json.dumps(final,indent=2));emit('cleanup',**final)
