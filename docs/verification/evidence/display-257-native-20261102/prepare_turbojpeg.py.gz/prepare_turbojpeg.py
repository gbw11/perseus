"""Download/check/extract one official ARM64 library; never installs a package."""
import hashlib,io,json,struct,tarfile,urllib.request
from pathlib import Path
DEST=Path(__file__).parent/'turbojpeg-deps';DEST.mkdir(exist_ok=True)
url='https://deb.debian.org/debian/pool/main/libj/libjpeg-turbo/libturbojpeg0_2.1.5-4_arm64.deb'
expected='bfce9b617b7de2e313b701de3ad3611b764613820d690592e3e96f3a62f02cdf'
with urllib.request.urlopen(url,timeout=45) as r:raw=r.read()
assert hashlib.sha256(raw).hexdigest()==expected,'Debian SHA256 mismatch'
assert raw.startswith(b'!<arch>\n');offset=8;members={}
while offset<len(raw):
 header=raw[offset:offset+60];size=int(header[48:58]);name=header[:16].decode().strip().rstrip('/')
 members[name]=raw[offset+60:offset+60+size];offset+=60+size+(size%2)
payload=next(data for name,data in members.items() if name.startswith('data.tar'))
files=[]
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:*') as tar:
 for item in tar.getmembers():
  if item.isfile() and (item.name.endswith('/copyright') or '/libturbojpeg.so.' in item.name):
   data=tar.extractfile(item).read();name=Path(item.name).name
   if name.startswith('libturbojpeg'):
    assert data.startswith(b'\x7fELF') and data[4:6]==b'\x02\x01' and struct.unpack_from('<H',data,18)[0]==183,'not ARM64 ELF'
   (DEST/name).write_bytes(data);files.append({'name':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
assert any(f['name'].startswith('libturbojpeg') for f in files)
meta={'package_url':url,'package_sha256':expected,'checksum_source':'https://packages.debian.org/trixie/arm64/libturbojpeg0/download','architecture':'arm64','package_version':'2.1.5-4','files':files,'package_installed':False}
(DEST/'provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
