"""Summarize measured CPU windows separately from the PC receive duration."""
import json,sys
from pathlib import Path
p=Path(sys.argv[1])/'result.json';d=json.loads(p.read_text(encoding='utf-8'))
s=d['resource_samples']['samples'];deltas=[b['at']-a['at'] for a,b in zip(s,s[1:])]
groups={k:sum(b['groups'][k]['cpu_percent']*dt for b,dt in zip(s[1:],deltas))/sum(deltas) for k in s[0]['groups']}
pipeline=sum(groups.get(k,0) for k in ['sender','encoder','native_worker','other_pipeline'])/100
out={'trial':d['trial'],'backend':d.get('encoder_backend','ffmpeg_mjpeg_q7'),'sample_seconds':sum(deltas),'mean_cpu_percent':groups,'pipeline_cores':pipeline,'minimum_available_mib':min(x['available_bytes'] for x in s)/1048576,'streams':{k:{a:b for a,b in d[k].items() if a!='samples'} for k in ['monitor-1','monitor-2','monitor-1-reconnect']},'combined_jpeg_mbps':sum(d[k]['jpeg_mbps'] for k in ['monitor-1','monitor-2']),'unauthenticated_http':d['unauthenticated_http'],'cleanup':{k:v for k,v in d['cleanup'].items() if k!='sender_journal'}}
p.with_name('summary.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
