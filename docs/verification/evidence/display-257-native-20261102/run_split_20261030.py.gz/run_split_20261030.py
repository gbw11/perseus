"""Pinned SSH driver for bounded stage measurements; no forwarding-policy edits."""
import json,secrets,shlex,sys
from pathlib import Path
import paramiko
from board_prepare import connect,execute
HERE=Path(__file__).parent;REPO=HERE.parent/'worktrees/display-257-dual-stream'
ROOT='/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs'
MODE=sys.argv[1] if len(sys.argv)>1 else 'split';assert MODE in ('split','turbo','xshm')
name='xenova-257-split-'+secrets.token_hex(4);work='/run/'+name
outdir=HERE/name;outdir.mkdir()
t=connect();t.set_keepalive(10)
try:
 # The first attempt stopped on import, before installing rollback or starting
 # graphics. Remove only its three known upload files if that exact set remains.
 execute(t,"import json,pathlib; p=pathlib.Path('/run/xenova-257-split-d2c6fd61'); expected={'runner.py','graphics.candidate','graphics.expected'};\nif p.exists():\n assert not p.is_symlink() and {q.name for q in p.iterdir()}==expected\n for q in p.iterdir():\n  assert q.is_file() and not q.is_symlink();q.unlink()\n p.rmdir()\nprint(json.dumps({'unused_first_upload_removed':not p.exists()}))",timeout=15)
 execute(t,'import json,pathlib; p=pathlib.Path('+repr(work)+');p.mkdir(mode=0o700);print(json.dumps({"created":True}))',timeout=15)
 sftp=paramiko.SFTPClient.from_transport(t)
 try:
  sftp.put(str(HERE/'split_runner_20261030.py'),work+'/runner.py')
  sftp.put(str(REPO/'platform/services/display/router/deploy/board-kms/graphics-session.py'),work+'/graphics.candidate')
  if MODE in ('turbo','xshm'):
   sftp.put(str(HERE/'turbo_worker_20261030.py'),work+'/turbo_worker.py')
   sftp.put(str(HERE/'xshm_capture_20261030.py'),work+'/xshm_capture.py')
   for dep_name in ['libturbojpeg.so.0.2.0','copyright']:sftp.put(str(HERE/'turbojpeg-deps'/dep_name),work+'/'+dep_name)
  expected=json.loads((HERE/'preflight_20261030.json').read_text())['graphics_sources']['/opt/xenova-display/current/bin/graphics-session.py'].encode()
  with sftp.file(work+'/graphics.expected','wb') as f:f.write(expected)
 finally:sftp.close()
 args=['systemd-run','--quiet','--wait','--pipe','--unit='+name,'--property=RuntimeMaxSec=480s','--property=TimeoutStopSec=30s','--property=KillMode=control-group','/usr/bin/python3',work+'/runner.py',ROOT,work,'15',MODE]
 channel=t.open_session(timeout=10);channel.settimeout(100)
 channel.exec_command(' '.join(shlex.quote(x) for x in args))
 with (outdir/'events.jsonl').open('w',encoding='utf-8') as log:
  for raw in channel.makefile('rb'):
   line=raw.decode(errors='replace').strip()
   if not line:continue
   log.write(line+'\n');log.flush()
   try:
    row=json.loads(line)
    if row.get('event')=='ready':print(json.dumps({'event':'ready','name':name,'memory':row['inventory']['memory'],'seconds_per_case':row['seconds_per_case']}),flush=True)
    else:print(json.dumps(row),flush=True)
   except ValueError:print(line[:1000],flush=True)
 stderr=channel.makefile_stderr('rb').read().decode(errors='replace')
 status=channel.recv_exit_status()
 (outdir/'stderr.txt').write_text(stderr,encoding='utf-8')
 print(json.dumps({'remote_exit':status,'evidence_directory':str(outdir)}),flush=True)
finally:
 try:
  sftp=paramiko.SFTPClient.from_transport(t)
  try:
   for filename in ['results.json','cleanup.json']:
    try:sftp.get(work+'/'+filename,str(outdir/filename))
    except OSError:pass
   if MODE in ('turbo','xshm'):
    try:
     (outdir/'samples').mkdir()
     for filename in sftp.listdir(work+'/samples'):
      if Path(filename).name==filename and filename.endswith(('.jpg','.json')):sftp.get(work+'/samples/'+filename,str(outdir/'samples'/filename))
    except OSError:pass
  finally:sftp.close()
  cleanup=execute(t,'import json,pathlib,shutil; p=pathlib.Path('+repr(work)+'); c=p/"cleanup.json";assert c.is_file(),"remote rollback or inspection still required";r=json.loads(c.read_text());assert r["graphics_source_restored"] and r["temporary_frames_removed"];assert p.parent==pathlib.Path("/run") and p.name.startswith("xenova-257-split-");shutil.rmtree(p);print(json.dumps({"temporary_directory_removed":not p.exists(),"cleanup":r}))',timeout=20)
  print(json.dumps(cleanup),flush=True)
 except Exception as exc:print(json.dumps({'cleanup_check_error':type(exc).__name__+': '+str(exc),'work':work,'rollback_timer_seconds':600}),flush=True)
 t.close()
