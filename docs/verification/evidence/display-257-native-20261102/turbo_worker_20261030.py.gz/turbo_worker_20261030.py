"""Isolated ARM64 prototype: raw X11 BGRX frames -> TurboJPEG, no service API."""
import ctypes as C
import json,os,signal,subprocess,sys,time
from pathlib import Path

base=Path(sys.argv[1]);mode=sys.argv[2];index=int(sys.argv[3]);quality=int(sys.argv[4]);count=int(sys.argv[5])
assert mode in ('offline','live','pipe','xshm','pipe-xshm') and index in (0,1) and 1<=quality<=100 and 1<=count<=900
def stopping(*_):raise SystemExit(0)
signal.signal(signal.SIGTERM,stopping)
W,H=1280,720;frame=bytearray(W*H*4);buffer=(C.c_ubyte*len(frame)).from_buffer(frame)
lib=C.CDLL(str(base/'libturbojpeg.so.0.2.0'))
lib.tjInitCompress.argtypes=[];lib.tjInitCompress.restype=C.c_void_p
lib.tjCompress2.argtypes=[C.c_void_p,C.c_void_p,C.c_int,C.c_int,C.c_int,C.c_int,C.POINTER(C.c_void_p),C.POINTER(C.c_ulong),C.c_int,C.c_int,C.c_int]
lib.tjCompress2.restype=C.c_int
lib.tjFree.argtypes=[C.c_void_p];lib.tjFree.restype=None
lib.tjDestroy.argtypes=[C.c_void_p];lib.tjDestroy.restype=C.c_int
lib.tjGetErrorStr2.argtypes=[C.c_void_p];lib.tjGetErrorStr2.restype=C.c_char_p
handle=lib.tjInitCompress();assert handle
capture=None;shared=None;times=[];sizes=[];samples=[];last_jpeg=None;start=time.monotonic();is_pipe=mode.startswith('pipe')
try:
 if mode=='offline':
  raw=(base/('monitor-'+str(index+1)+'.bgr0')).read_bytes();assert len(raw)==len(frame);frame[:]=raw
 elif mode in ('xshm','pipe-xshm'):
  from xshm_capture import SharedCapture
  shared=SharedCapture(W,H,index*W,0)
 else:
  args=['/usr/bin/ffmpeg','-hide_banner','-loglevel','error','-nostdin','-probesize','32','-analyzeduration','0','-fpsprobesize','0','-f','x11grab','-draw_mouse','0','-framerate','5','-video_size','1280x720','-i',':5+'+str(index*1280)+',0','-an','-c:v','rawvideo','-pix_fmt','bgr0','-threads','1','-f','rawvideo','pipe:1']
  capture=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 for n in range(count):
  if shared:
   if n:
    deadline=start+n/5
    if deadline>time.monotonic():time.sleep(deadline-time.monotonic())
   source=shared.frame();pitch=shared.pitch
  else:source=buffer;pitch=W*4
  if mode in ('live','pipe'):
   view=memoryview(frame);offset=0
   while offset<len(frame):
    size=capture.stdout.readinto(view[offset:])
    if not size:raise RuntimeError('capture ended before a complete frame')
    offset+=size
  before=time.monotonic();destination=C.c_void_p();size=C.c_ulong()
  try:
   # TJPF_BGRX=3, TJSAMP_420=2, default DCT. Quality is calibrated separately
   # against FFmpeg q=7; the two quality scales are not equated.
   rc=lib.tjCompress2(handle,source,W,pitch,H,3,C.byref(destination),C.byref(size),2,quality,0)
   if rc:raise RuntimeError(lib.tjGetErrorStr2(handle).decode(errors='replace'))
   jpeg=C.string_at(destination,size.value)
  finally:
   if destination:lib.tjFree(destination)
  after=time.monotonic();times.append(after-before);sizes.append(len(jpeg));samples.append(after-start);last_jpeg=jpeg
  if is_pipe:sys.stdout.buffer.write(jpeg);sys.stdout.buffer.flush()
  if mode=='offline' and count>1:
   deadline=start+(n+1)/5
   if deadline>time.monotonic():time.sleep(deadline-time.monotonic())
 elapsed=time.monotonic()-start
 if not is_pipe:(base/(mode+'-'+str(quality)+'-'+str(index)+'.jpg')).write_bytes(last_jpeg)
 row={'mode':mode,'quality':quality,'source_index':index,'width':W,'height':H,'frames':len(sizes),'wall_seconds':elapsed,'observed_fps':len(sizes)/elapsed,'jpeg_mbps':sum(sizes)*8/elapsed/1e6,'jpeg_bytes_total':sum(sizes),'encode_seconds_total':sum(times),'encode_seconds_max':max(times),'frame_arrival_seconds':samples,'jpeg_bytes_each':sizes,'pixel_format':'BGRX','subsampling':'420','library':'libturbojpeg.so.0.2.0'}
 if not is_pipe:
  (base/(mode+'-'+str(quality)+'-'+str(index)+'.json')).write_text(json.dumps(row,indent=2))
  print('frame='+str(len(sizes)));print('progress=end')
finally:
 if shared:shared.close()
 if capture:
  capture.terminate()
  try:capture.wait(timeout=5)
  except subprocess.TimeoutExpired:capture.kill();capture.wait(timeout=3)
  capture.stdout.close()
 lib.tjDestroy(handle)
