import hashlib,json
from pathlib import Path
from board_prepare import connect,execute

remote=r'''
import json,hashlib,pathlib,subprocess
root=pathlib.Path('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs')
paths=[pathlib.Path('/opt/xenova-display/current/lib/xenova_display/kiosk.py'),root/'opt/xenova-kiosk-runtime/20261028/lib/xenova_display/kiosk.py']
sources={str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source':p.read_text()} for p in paths if p.exists()}
print(json.dumps({'sources':sources,'unit':subprocess.check_output(['systemctl','show','xenova-display-kiosk.service','--property=ExecStart,EnvironmentFiles'],text=True,timeout=10)}))
'''
t=connect()
try:
    data=execute(t,remote)
    Path(__file__).with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'hashes':{k:v['sha256'] for k,v in data['sources'].items()},'unit':data['unit']}))
finally:t.close()
