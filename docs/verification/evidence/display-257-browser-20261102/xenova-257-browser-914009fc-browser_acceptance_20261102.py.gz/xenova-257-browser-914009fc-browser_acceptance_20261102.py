"""Stage the actual product worker/host profile; bounded soak and pixel latency."""
import ast,http.client,io,json,math,secrets,shlex,sys,threading,time,traceback
from pathlib import Path
import paramiko
from PIL import Image
from board_prepare import connect,execute

HERE=Path(__file__).parent;REPO=HERE.parent/'worktrees/display-257-dual-stream'
ROOT='/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs'
DURATION=int(sys.argv[1]) if len(sys.argv)>1 else 60
MARKERS=True
BROWSER=True
HOTPLUG='--hotplug' in sys.argv
assert 30<=DURATION<=900
trial='xenova-257-browser-'+secrets.token_hex(4);work='/run/'+trial
stage='/opt/xenova-kiosk-runtime/'+trial;token=secrets.token_urlsafe(32)
outdir=HERE/trial;outdir.mkdir();result={'trial':trial,'duration_target_s':DURATION,'markers_requested':MARKERS,'product_native_worker':True}
source=ast.parse((HERE/'dual_physical_20261102.py').read_text())
def block(name):
 for node in ast.walk(source):
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str):return node.value.value
 raise KeyError(name)
def subst(s):
 values={'ROOT':ROOT,'WORK':work,'STAGE':stage,'UNIT':trial,'__TOKEN__':token}
 class Parameters(ast.NodeTransformer):
  def visit_Name(self,node):
   if isinstance(node.ctx,ast.Load) and node.id in values:return ast.copy_location(ast.Constant(values[node.id]),node)
   return node
 return ast.unparse(ast.fix_missing_locations(Parameters().visit(ast.parse(s))))
class Raw(io.RawIOBase):
 def __init__(self,c):super().__init__();self.c=c
 def readable(self):return True
 def readinto(self,b):
  data=self.c.recv(len(b));b[:len(data)]=data;return len(data)
class Socket:
 def __init__(self,c):self.c=c
 def makefile(self,mode,*_a,**_k):assert mode=='rb';return io.BufferedReader(Raw(self.c))
 def __getattr__(self,k):return getattr(self.c,k)
t=connect();t.set_keepalive(10)
def request(path,auth=True,method='GET',headers=None,body=None):
 ch=t.open_channel('direct-tcpip',('127.0.0.1',8083),('127.0.0.1',0),timeout=8);ch.settimeout(5)
 conn=http.client.HTTPConnection('localhost',8083,timeout=5);conn.sock=Socket(ch)
 conn.request(method,path,body=body,headers=headers if headers is not None else {'Authorization':'Bearer '+token} if auth else {})
 return conn,conn.getresponse()
def status():
 c,r=request('/api/v1/streams')
 try:return r.status,json.load(r)
 finally:c.close()
palette={i:(32+(i&3)*56,32+((i>>2)&3)*56,32+((i>>4)&3)*56) for i in range(1,31)}
class Receiver:
 def __init__(self,identity):
  self.identity=identity;self.frames=[];self.errors=[];self.markers={};self.stop=threading.Event();self.lock=threading.Lock();self.conn=None;self.connections=0
  self.thread=threading.Thread(target=self.run,daemon=True)
 def run(self):
  while not self.stop.is_set():
   try:
    self.conn,response=request('/streams/'+self.identity+'.mjpeg')
    if response.status!=200:raise RuntimeError('stream HTTP '+str(response.status))
    self.connections+=1;parser=bytearray()
    while not self.stop.is_set():
     data=response.read1(65536)
     if not data:raise EOFError('stream ended')
     parser.extend(data)
     while True:
      a=parser.find(b'\xff\xd8');b=parser.find(b'\xff\xd9',max(a,0)+2)
      if a<0:parser[:]=parser[-1:];break
      if b<0:parser[:]=parser[a:];break
      frame=bytes(parser[a:b+2]);del parser[:b+2]
      arrived=time.perf_counter()
      with Image.open(io.BytesIO(frame)) as image:
       image.load()
       if image.size!=(1280,720) or image.mode!='RGB':raise RuntimeError('wrong decoded dimensions or format')
       rgb=image.getpixel((1180,660))
      decoded=time.perf_counter()
      identifier=next((i for i,color in palette.items() if max(abs(a-b) for a,b in zip(rgb,color))<=10),None)
      with self.lock:
       if identifier is not None and identifier not in self.markers:self.markers[identifier]={'decoded_at':decoded,'rgb':rgb}
       self.frames.append({'arrived':arrived,'decoded':decoded,'bytes':len(frame)})
       first=len(self.frames)==1
      if first:(outdir/(self.identity+'-first.jpg')).write_bytes(frame)
      self.last_frame=frame
     if len(parser)>2*1024*1024:raise RuntimeError('frame bound exceeded')
   except Exception as exc:
    if not self.stop.is_set():self.errors.append({'at':time.perf_counter(),'type':type(exc).__name__})
   finally:
    if self.conn:self.conn.close();self.conn=None
   self.stop.wait(.5)
 def close(self):
  self.stop.set()
  if self.conn:self.conn.close()
  self.thread.join(timeout=8)
  if hasattr(self,'last_frame'):(outdir/(self.identity+'-last.jpg')).write_bytes(self.last_frame)
 def summary(self,started,ended):
  frames=[f for f in self.frames if started<=f['decoded']<=ended]
  intervals=[b['decoded']-a['decoded'] for a,b in zip(frames,frames[1:])]
  return {'frames':len(frames),'duration_s':ended-started,'fps':len(frames)/(ended-started),'jpeg_mbps':sum(f['bytes'] for f in frames)*8/(ended-started)/1e6,'connections':self.connections,'errors':self.errors,'largest_decode_gap_s':max(intervals,default=None),'gaps_over_1s':sum(x>1 for x in intervals),'markers':self.markers}
receivers=[];sampler_result={};marker_channel=None;browser=None
try:
 setup=block('setup').replace('--on-active=240s','--on-active=2100s')
 # Include marker stop in the same recovery path, without changing the native
 # host profile or any existing graphics service.
 setup=setup.replace("(root/stage.lstrip('/')/'lib/xenova_display').mkdir(parents=True)","(root/stage.lstrip('/')/'lib/xenova_display').mkdir(parents=True)\nrollback.write_text(rollback.read_text()+'\\nsubprocess.run([\"systemctl\",\"stop\",'+repr(unit+'-marker')+'])\\n')")
 result['setup']=execute(t,subst(setup),timeout=35)
 t.close();t=connect();t.set_keepalive(10)
 sftp=paramiko.SFTPClient.from_transport(t)
 try:
  for p in (REPO/'platform/services/display/router/xenova_display').iterdir():
   if p.is_file() and p.suffix in ('.py','.html'):sftp.put(str(p),ROOT+stage+'/lib/xenova_display/'+p.name)
  sftp.mkdir(ROOT+stage+'/native');sftp.mkdir(ROOT+stage+'/test')
  for filename in ['libturbojpeg.so.0.2.0','copyright']:sftp.put(str(HERE/'turbojpeg-deps'/filename),ROOT+stage+'/native/'+filename)
  sftp.put(str(REPO/'platform/services/display/router/deploy/board-kms/stream-host.py'),work+'/stream-host.py')
  sftp.put(str(HERE/'latency_marker_20261102.py'),ROOT+stage+'/test/marker.py')
 finally:sftp.close()
 prepare=r'''
import hashlib,json,pathlib,subprocess,os
root=pathlib.Path(ROOT);stage=STAGE;work=pathlib.Path(WORK);unit=UNIT
lib=root/stage.lstrip('/')/'native/libturbojpeg.so.0.2.0'
assert hashlib.sha256(lib.read_bytes()).hexdigest()=='d8e4a12770bcdbcf027a401836f062c8596336082103543b1ecdb97c763037e4'
old=(work/'stream.env').read_text();key=next(s for s in old.splitlines() if s.startswith('XENOVA_STREAM_TOKEN='))
(work/'stream.env').write_text(key+'\nPYTHONPATH='+str(root/stage.lstrip('/')/'lib')+':/opt/xenova-display/current/lib\nXENOVA_GRAPHICS_ROOT='+str(root)+'\nXENOVA_STREAM_ENCODER=native_jpeg\nXENOVA_NATIVE_JPEG_LIBRARY='+stage+'/native/libturbojpeg.so.0.2.0\nXENOVA_STREAM_WORKER_LIB='+stage+'/lib\nXENOVA_NATIVE_JPEG_QUALITY=85\n')
env=dict(os.environ)
for line in (work/'stream.env').read_text().splitlines():
 k,v=line.split('=',1);env[k]=v
check=subprocess.run(['/usr/bin/python3',str(work/'stream-host.py'),'--check'],env=env,capture_output=True,text=True,timeout=35)
assert check.returncode==0,check.stderr[-1500:]
args=['systemd-run','--quiet','--unit='+unit,'--property=RuntimeMaxSec='+str(DURATION+120)+'s','--property=TimeoutStopSec=15s','--property=KillMode=control-group','--property=EnvironmentFile='+str(work/'stream.env'),'/usr/bin/python3',str(work/'stream-host.py')]
subprocess.run(args,check=True,timeout=15)
wrapper=work/'marker-host.py'
wrapper.write_text('import os,runpy\nm=runpy.run_path('+repr(str(work/'stream-host.py'))+')\ncfg,_=m["prepare"]()\na=m["stream"].capture_command(cfg,cfg.outputs[0])\ni=a.index("/usr/bin/python3")\na=a[:i+1]+['+repr(stage+'/test/marker.py')+']\nos.execv(a[0],a)\n')
print(json.dumps({'native_dependency_check':True,'started':True}))
'''.replace('DURATION',str(1680))
 result['prepared']=execute(t,subst(prepare),timeout=65)
 for attempt in range(30):
  try:
   code,body=status()
   if code==200 and len(body['streams'])==2 and all(s['status']=='live' and s['physical_verified'] for s in body['streams']):result['initial_status']=body;break
  except (OSError,http.client.HTTPException,paramiko.ChannelException):pass
  time.sleep(.5)
 else:raise RuntimeError('product native streams did not become live')
 c,r=request('/api/v1/streams',False);result['unauthenticated_http']=r.status;r.read();c.close()
 print(json.dumps({'event':'ready','trial':trial,'seconds':DURATION,'native_dependency_check':True}),flush=True)
 started=time.perf_counter();end=started+DURATION
 for receiver in receivers:receiver.thread.start()
 sampler=r'''
import json,os,pathlib,subprocess,time
unit=UNIT;duration=DURATION
units=[unit,'xenova-display-kiosk.service','xenova-display-graphics.service']
paths=[]
for u in units:
 group=subprocess.check_output(['systemctl','show',u,'--property=ControlGroup','--value'],text=True,timeout=10).strip()
 paths.append(pathlib.Path('/sys/fs/cgroup')/group.lstrip('/')/'cgroup.procs')
samples=[];previous={};last=None;hz=os.sysconf('SC_CLK_TCK');page=os.sysconf('SC_PAGE_SIZE');start=time.monotonic()
sender=int(subprocess.check_output(['systemctl','show',unit,'--property=MainPID','--value'],text=True,timeout=5).strip() or 0)
while time.monotonic()-start<duration:
 now=time.monotonic();rows={}
 ids=set()
 for p in paths:
  try:ids.update(map(int,p.read_text().split()))
  except OSError:pass
 for pid in ids:
  try:
   head,tail=(pathlib.Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1);f=tail.split()
   rows[pid]={'name':head.split('(',1)[1],'ticks':int(f[11])+int(f[12]),'birth':int(f[19]),'rss':int(f[21])*page}
  except (OSError,ValueError,IndexError):pass
 groups={k:{'cpu_percent':0,'rss_sum_bytes':0,'pids':[]} for k in ['sender','native_worker','browser','xorg','other_pipeline','other_system']}
 pipeline_ids=set(map(int,paths[0].read_text().split())) if paths[0].exists() else set()
 if sender not in pipeline_ids:
  sender=int(subprocess.check_output(['systemctl','show',unit,'--property=MainPID','--value'],text=True,timeout=5).strip() or 0)
 for pid,row in rows.items():
  name=row['name'].lower();g='sender' if pid==sender else 'native_worker' if pid in pipeline_ids and 'python' in name else 'other_pipeline' if pid in pipeline_ids else 'browser' if 'chrom' in name else 'xorg' if name=='xorg' else 'other_system'
  groups[g]['rss_sum_bytes']+=row['rss'];groups[g]['pids'].append(pid);key=(pid,row['birth'])
  if last and key in previous:groups[g]['cpu_percent']+=max(0,row['ticks']-previous[key])/hz/(now-last)*100
 previous={(pid,row['birth']):row['ticks'] for pid,row in rows.items()};last=now
 mem=int(next(s.split()[1] for s in pathlib.Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
 samples.append({'at':now,'groups':groups,'available_bytes':mem})
 time.sleep(2)
print(json.dumps({'samples':samples,'scope':'service cgroups; no all-process polling'}))
'''.replace('DURATION',str(DURATION))
 def sample():
  try:sampler_result.update(execute(t,subst(sampler),timeout=DURATION+45))
  except Exception as exc:sampler_result['error']=type(exc).__name__+': '+str(exc)
 sampler_thread=threading.Thread(target=sample,daemon=True)
 marker_rows=[]
 if MARKERS:
  args=['systemd-run','--quiet','--wait','--pipe','--collect','--unit='+trial+'-marker','--property=RuntimeMaxSec=1800s','--property=EnvironmentFile='+work+'/stream.env','/usr/bin/python3',work+'/marker-host.py']
  marker_channel=t.open_session(timeout=10);marker_channel.settimeout(45);marker_channel.exec_command(' '.join(shlex.quote(x) for x in args));marker_reader=marker_channel.makefile('rb')
  if not json.loads(marker_reader.readline()).get('ready'):raise RuntimeError('marker did not start')
  marker_lock=threading.Lock()
  def control_marker(data):
   if not (data.get('hide') is True or type(data.get('id')) is int and 1<=data['id']<=63):raise ValueError('invalid marker')
   with marker_lock:
    marker_channel.sendall((json.dumps(data)+'\n').encode());return json.loads(marker_reader.readline())
  control_marker({'hide':True})
  from browser_harness_20261102 import BrowserHarness
  browser=BrowserHarness.__new__(BrowserHarness)
  browser.__init__(lambda method,path,headers,body:request(path,False,method,headers,body),control_marker,token,outdir,secrets.token_urlsafe(24))
  result['browser_version']=browser.browser.version
  result['browser_latency']=browser.latency(list(range(1,31)))
  print(json.dumps({'event':'browser_latency_complete','samples':len(result['browser_latency'])}),flush=True)
 result['marker_requests']=marker_rows
 result['soak_initial_status']=status()[1]
 started=time.perf_counter();end=started+DURATION
 browser_start=browser.reset();proxy_start=browser.snapshot()['proxy']
 sampler_thread.start();browser_samples=[];last_sample=-10
 restarted=False;last_progress=0
 while time.perf_counter()<end:
  elapsed=time.perf_counter()-started
  if False:
   before=status()[1]
   restart=execute(t,"import json,subprocess;subprocess.run(['systemctl','restart',"+repr(trial)+"],check=True,timeout=30);print(json.dumps({'restarted':True}))",timeout=40)
   result['restart']={'at_seconds':elapsed,'before':before,'action':restart};restarted=True
  if elapsed-last_progress>=30:
   snapshot=browser.snapshot()
   print(json.dumps({'event':'progress','elapsed_s':round(elapsed),'browser_frames':{k:v['frames'] for k,v in snapshot['streams'].items()},'connections':{k:v['connections'] for k,v in snapshot['proxy'].items()}}),flush=True);last_progress=elapsed
  if elapsed-last_sample>=5:
   browser_samples.append(browser.snapshot());last_sample=elapsed
  browser.page.wait_for_timeout(500)
 ended=time.perf_counter()
 for receiver in receivers:receiver.close()
 sampler_thread.join(timeout=30);result['resources']=sampler_result
 result['streams']={r.identity:r.summary(started,ended) for r in receivers};result['elapsed_s']=ended-started
 result['final_status']=status()[1]
 result['browser_soak']={'started_browser_ms':browser_start,'final':browser.snapshot(),'proxy_start':proxy_start,'samples':browser_samples}
 browser.page.screenshot(path=str(outdir/'browser-soak-final.png'))
 if HOTPLUG:
  (outdir/'hotplug-ready.json').write_text(json.dumps({'ready':True,'trial':trial,'duration_s':result['elapsed_s']}))
  print(json.dumps({'event':'hotplug_ready','trial':trial}),flush=True)
  deadline=time.monotonic()+900;observations=[];phase='waiting';last_progress=0
  while time.monotonic()<deadline:
   command=outdir/'command.json'
   if command.exists():
    instruction=json.loads(command.read_text());command.unlink()
    if instruction.get('action')=='finish':break
    if instruction.get('action')=='phase':phase=instruction['output']
    if instruction.get('action')=='probe':
     rows=browser.latency(instruction['ids']);result.setdefault('hotplug_freshness',[]).append({'phase':phase,'rows':rows})
     browser.page.screenshot(path=str(outdir/('browser-'+phase+'-restored.png')))
     (outdir/('freshness-'+phase+'.json')).write_text(json.dumps(rows))
    if instruction.get('action')=='soak':
     result['browser_soak_before_hotplug']=result['browser_soak']
     result['resources_before_hotplug']=result['resources']
     result['soak_initial_status']=status()[1]
     browser_start=browser.reset();proxy_start=browser.snapshot()['proxy'];soak_started=time.perf_counter()
     after_resources={}
     def sample_after():
      try:after_resources.update(execute(t,subst(sampler.replace('duration='+str(DURATION),'duration=600',1)),timeout=645))
      except Exception as exc:after_resources['error']=type(exc).__name__+': '+str(exc)
     after_thread=threading.Thread(target=sample_after,daemon=True);after_thread.start()
     after_samples=[];last_sample=-10;last_progress=0
     while time.perf_counter()-soak_started<600:
      elapsed=time.perf_counter()-soak_started
      if elapsed-last_sample>=5:after_samples.append(browser.snapshot());last_sample=elapsed
      if elapsed-last_progress>=30:
       d=browser.snapshot();print(json.dumps({'event':'final_soak_progress','elapsed_s':round(elapsed),'frames':{k:v['frames'] for k,v in d['streams'].items()},'connections':{k:v['connections'] for k,v in d['proxy'].items()}}),flush=True);last_progress=elapsed
      browser.page.wait_for_timeout(500)
     after_elapsed=time.perf_counter()-soak_started;after_thread.join(timeout=30)
     result['resources']=after_resources;result['elapsed_s']=after_elapsed;result['final_status']=status()[1]
     result['browser_soak']={'started_browser_ms':browser_start,'final':browser.snapshot(),'proxy_start':proxy_start,'samples':after_samples}
     browser.page.screenshot(path=str(outdir/'browser-final-post-hotplug-soak.png'))
     (outdir/'final-soak-complete.json').write_text(json.dumps({'elapsed_s':after_elapsed,'browser':result['browser_soak']['final']}))
     if instruction.get('finish'):break
   physical=execute(t,"import pathlib,json,time;root=pathlib.Path("+repr(ROOT)+");p=root/'run/xenova-kiosk/display-runtime.json';d=json.loads(p.read_text());print(json.dumps({'drm':{x.name:(x/'status').read_text().strip() for x in pathlib.Path('/sys/class/drm').glob('card*-*') if (x/'status').exists()},'runtime_age_s':time.monotonic()-d['updated_monotonic'],'runtime':d['outputs']}))",timeout=15)
   row={'pc_at':time.perf_counter(),'phase':phase,'physical':physical,'api':status()[1],'browser':browser.snapshot()}
   observations.append(row);(outdir/'hotplug-latest.json').write_text(json.dumps(row))
   with (outdir/'hotplug-observations.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   if time.monotonic()-last_progress>30:
    print(json.dumps({'event':'hotplug_progress','phase':phase,'drm':physical['drm'],'frames':{k:v['frames'] for k,v in row['browser']['streams'].items()}}),flush=True);last_progress=time.monotonic()
   browser.page.wait_for_timeout(1000)
  result['hotplug']={'observations':observations,'final_phase':phase}
 if MARKERS:
  latencies={}
  for receiver in receivers:
   values=[(receiver.markers[row['id']]['decoded_at']-row['request_started_pc'])*1000 for row in marker_rows if row['id'] in receiver.markers]
   latencies[receiver.identity]={'matched':len(values),'requested':len(marker_rows),'milliseconds':values,'p95_ms':sorted(values)[max(0,math.ceil(len(values)*.95)-1)] if values else None,'scope':'PC control-request start -> JPEG decoded/pixel matched; includes outbound control; no cross-host clock subtraction'}
  result['latency']=latencies
 print(json.dumps({'event':'measurement_complete','elapsed_s':result['elapsed_s'],'fps':{k:v['fps'] for k,v in result['streams'].items()},'latency':result.get('latency')}),flush=True)
except Exception as exc:
 result['error']=type(exc).__name__+': '+str(exc);result['traceback']=traceback.format_exc()
 if marker_channel and marker_channel.recv_stderr_ready():result['marker_stderr']=marker_channel.recv_stderr(8192).decode(errors='replace')
 if marker_channel:
  try:result['marker_diagnostic']=execute(t,"import json,subprocess;print(json.dumps({'journal':subprocess.run(['journalctl','--no-pager','-n','25','-u',"+repr(trial+'-marker')+"],capture_output=True,text=True).stdout}))",timeout=15)
  except Exception as diagnostic:result['marker_diagnostic']=type(diagnostic).__name__
 print(json.dumps({'event':'error','error':result['error'],'traceback':result['traceback'],'marker_stderr':result.get('marker_stderr')}),flush=True)
finally:
 if browser:
  try:browser.close()
  except Exception as exc:result['browser_close_error']=type(exc).__name__
 for receiver in receivers:
  if receiver.thread.ident is not None:receiver.close()
 if marker_channel:
  try:marker_channel.sendall(b'{"quit":true}\n');marker_channel.close()
  except OSError:pass
 try:result['cleanup']=execute(t,subst(block('cleanup')),timeout=100)
 except Exception as exc:result['cleanup_error']=type(exc).__name__+': '+str(exc)
 t.close();(outdir/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'event':'finished','trial':trial,'error':result.get('error'),'cleanup':{k:v for k,v in result.get('cleanup',{}).items() if k!='sender_journal'}}),flush=True)
