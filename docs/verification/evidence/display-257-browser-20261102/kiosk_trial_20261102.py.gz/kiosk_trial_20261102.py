"""Explicitly authorized temporary kiosk-only trial with guarded rollback."""
import json,secrets,sys
from pathlib import Path
import paramiko
from board_prepare import connect,execute

here=Path(__file__).parent
state_path=here/'kiosk-trial-20261102.json'
manifest=json.loads((here/'board-kiosk-candidate-manifest.json').read_text())
action=sys.argv[1]
t=connect()
try:
 if action=='apply':
  trial='xenova-257-kiosk-'+secrets.token_hex(4);work='/run/'+trial
  execute(t,'import pathlib,json;p=pathlib.Path('+repr(work)+');p.mkdir(mode=0o700);print(json.dumps({"created":True}))')
  sftp=paramiko.SFTPClient.from_transport(t)
  try:sftp.put(str(here/'board-kiosk-isolated.py'),work+'/candidate.py')
  finally:sftp.close()
  code=r'''
import ast,hashlib,json,pathlib,subprocess,time
work=pathlib.Path(WORK);meta=MANIFEST;unit=UNIT
candidate=(work/'candidate.py').read_bytes();ast.parse(candidate)
assert hashlib.sha256(candidate).hexdigest()==meta['candidate_sha256']
for i,name in enumerate(meta['paths']):
 p=pathlib.Path(name);assert p.is_file() and not p.is_symlink()
 raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['original_sha256'],'kiosk source changed; refusing overwrite'
 backup=work/('original-'+str(i)+'.py');backup.write_bytes(raw);backup.chmod(0o600)
(work/'manifest.json').write_text(json.dumps(meta))
rollback=work/'rollback.py'
rollback.write_text("""import hashlib,json,pathlib,subprocess
w=pathlib.Path(WORK)
m=json.loads((w/'manifest.json').read_text())
for name in m['paths']:
 p=pathlib.Path(name)
 assert hashlib.sha256(p.read_bytes()).hexdigest() in [m['original_sha256'],m['candidate_sha256']], 'kiosk source changed externally; refusing overwrite'
for i,name in enumerate(m['paths']):
 raw=(w/('original-'+str(i)+'.py')).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==m['original_sha256']
 pathlib.Path(name).write_bytes(raw)
subprocess.run(['systemctl','restart','xenova-display-kiosk.service'],check=True,timeout=90)
""".replace('WORK',repr(str(work))))
subprocess.run(['systemd-run','--quiet','--unit='+unit+'-rollback','--on-active=2400s','/usr/bin/python3',str(rollback)],check=True,timeout=15)
try:
 for name in meta['paths']:pathlib.Path(name).write_bytes(candidate)
 subprocess.run(['systemctl','restart','xenova-display-kiosk.service'],check=True,timeout=90)
 status=pathlib.Path('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs/run/xenova-kiosk/display-runtime.json')
 deadline=time.monotonic()+100
 while time.monotonic()<deadline:
  try:
   d=json.loads(status.read_text())
   if time.monotonic()-d['updated_monotonic']<3 and len(d['outputs'])==2 and all(v.get('status')=='mapped' and v.get('renderer_alive') and v.get('physical_verified') for v in d['outputs'].values()):break
  except (OSError,ValueError,KeyError):pass
  time.sleep(1)
 else:raise RuntimeError('two physical kiosk outputs did not recover')
 print(json.dumps({'trial':unit,'work':str(work),'candidate_active':True,'hashes':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in meta['paths']},'runtime':d}))
except BaseException:
 subprocess.run(['/usr/bin/python3',str(rollback)],check=True,timeout=105)
 raise
'''
  # Replace only AST Name loads, never text inside environment keys/paths.
  import ast
  class Values(ast.NodeTransformer):
   def visit_Name(self,node):
    if isinstance(node.ctx,ast.Load) and node.id in ('WORK','MANIFEST','UNIT'):
     return ast.copy_location(ast.parse(repr({'WORK':work,'MANIFEST':manifest,'UNIT':trial}[node.id]),mode='eval').body,node)
    return node
  code=ast.unparse(ast.fix_missing_locations(Values().visit(ast.parse(code))))
  state_path.write_text(json.dumps({'trial':trial,'work':work,'manifest':manifest},indent=2)+'\n')
  data=execute(t,code,timeout=230)
  (here/(trial+'-applied.json')).write_text(json.dumps(data,indent=2)+'\n')
  print(json.dumps(data))
 elif action=='restore':
  state=json.loads(state_path.read_text());work=state['work'];unit=state['trial']
  assert work=='/run/'+unit and unit.startswith('xenova-257-kiosk-')
  code='''
import hashlib,json,pathlib,subprocess,time
w=pathlib.Path(WORK);unit=UNIT
m=json.loads((w/'manifest.json').read_text())
current={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in m['paths']}
assert all(v in [m['original_sha256'],m['candidate_sha256']] for v in current.values())
if any(v!=m['original_sha256'] for v in current.values()):
 subprocess.run(['/usr/bin/python3',str(w/'rollback.py')],check=True,timeout=105)
hashes={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in m['paths']}
assert all(v==m['original_sha256'] for v in hashes.values())
subprocess.run(['systemctl','stop',unit+'-rollback.timer'],capture_output=True,timeout=15)
assert subprocess.run(['systemctl','is-active','--quiet',unit+'-rollback.timer']).returncode!=0
p=pathlib.Path('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs/run/xenova-kiosk/display-runtime.json');deadline=time.monotonic()+100
while time.monotonic()<deadline:
 try:
  d=json.loads(p.read_text())
  if time.monotonic()-d['updated_monotonic']<4 and len(d['outputs'])==2 and all(v['status']=='mapped' and v['renderer_alive'] and v.get('physical_verified') for v in d['outputs'].values()):break
 except (OSError,ValueError,KeyError):pass
 time.sleep(1)
else:raise RuntimeError('original two-output kiosk not ready after restore')
assert w.parent==pathlib.Path('/run') and w.name.startswith('xenova-257-kiosk-')
assert {x.name for x in w.iterdir()}=={'candidate.py','original-0.py','original-1.py','manifest.json','rollback.py'}
for x in w.iterdir():x.unlink()
w.rmdir()
print(json.dumps({'restored':True,'hashes':hashes,'runtime':d,'rollback_timer_stopped':True,'temporary_files_removed':True}))
'''.replace('WORK',repr(work)).replace('UNIT',repr(unit))
  data=execute(t,code,timeout=225);(here/(unit+'-restored.json')).write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))
 else:raise ValueError('use apply or restore')
finally:t.close()
