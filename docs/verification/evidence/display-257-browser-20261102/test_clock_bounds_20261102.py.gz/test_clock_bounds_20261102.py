from clock_bounds_20261102 import calculate

def fixture(rate=1):
    echoes=[];rows=[]
    for i in range(30):
        t=i*1000
        echoes.append({'sent':t,'received':t+10,'board_clock_s':((t+5)/rate+100000)/1000})
        sent=t+20;paint=sent+350+(i%3)*40
        rows.append({'id':i+1,'sent':sent,'board_draw_request_s':(paint/rate+100000)/1000,
                     'board_draw_done_s':((paint+2)/rate+100000)/1000,
                     'matches':{s:{'afterTwoRAF':paint+250} for s in ['monitor-1','monitor-2']}})
    return rows,echoes

def test_known_video_latency_is_inside_bound_without_counting_outbound_control():
    for rate in [1,.995,1.005]:
        rows,echoes=fixture(rate)
        result=calculate(rows,echoes)
        for stream in result['streams'].values():
            assert stream['matched']==30 and stream['p95_upper_ms']<270
            assert all(x['lower_ms']<=250<=x['upper_ms'] for x in stream['samples'])
            assert all(x['control_request_upper_ms']>=600 for x in stream['samples'])

def test_contradictory_clock_rate_cannot_be_reported_as_latency_success():
    rows,echoes=fixture(1.05)
    try:calculate(rows,echoes)
    except ValueError as exc:assert 'contradicts' in str(exc)
    else:raise AssertionError('invalid clock mapping accepted')

if __name__=='__main__':
    test_known_video_latency_is_inside_bound_without_counting_outbound_control()
    test_contradictory_clock_rate_cannot_be_reported_as_latency_success()
    print('causal clock bound tests passed')
