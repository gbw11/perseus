import importlib.util
from pathlib import Path
import sys
import pytest

here=Path(__file__).parent
router=here.parent/'worktrees/display-257-dual-stream/platform/services/display/router'
sys.path.insert(0,str(router))
spec=importlib.util.spec_from_file_location('xenova_display.board_kiosk_candidate',here/'board-kiosk-isolated.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class Candidate:
    def pytest_collection_modifyitems(self,items):
        for item in items:item.module.Kiosk=module.Kiosk
raise SystemExit(pytest.main([str(router/'tests/test_kiosk_isolation.py'),'-q'],plugins=[Candidate()]))
