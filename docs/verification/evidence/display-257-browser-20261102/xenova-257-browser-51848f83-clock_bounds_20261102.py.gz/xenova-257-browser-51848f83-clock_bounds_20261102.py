"""Causal clock bounds; never subtract unaligned host timestamps directly.

Engineering assumption: during one <=120s batch, browser milliseconds per
board millisecond stay within [0.99,1.01]. This is an explicit rate envelope,
not a certified oscillator guarantee. Inconsistent echoes invalidate results.
"""
import math

def percentile(values, fraction=.95):
    return sorted(values)[max(0,math.ceil(len(values)*fraction)-1)] if values else None

def calculate(rows, echoes, rate_error=.01):
    if not 0 <= rate_error <= .02 or len(echoes)<20:raise ValueError('invalid clock calibration')
    if max(e['received'] for e in echoes)-min(e['sent'] for e in echoes)>120000:
        raise ValueError('clock calibration exceeds short-batch scope')
    for e in echoes:
        if not all(math.isfinite(e[k]) for k in ('sent','received','board_clock_s')) or e['received']<e['sent']:
            raise ValueError('invalid clock echo')

    def bounds(board):
        lowers=[];uppers=[]
        for e in echoes:
            delta=(board-e['board_clock_s'])*1000
            a,b=(1-rate_error)*delta,(1+rate_error)*delta
            lowers.append(e['sent']+min(a,b));uppers.append(e['received']+max(a,b))
        lower,upper=max(lowers),min(uppers)
        if lower>upper+1e-4:raise ValueError('clock-rate envelope contradicts observed echoes')
        return lower,upper

    for e in echoes:bounds(e['board_clock_s'])
    samples={s:[] for s in ('monitor-1','monitor-2')}
    for row in rows:
        begin,end=row['board_draw_request_s'],row['board_draw_done_s']
        if not all(math.isfinite(x) for x in (begin,end)) or end<begin:
            raise ValueError('invalid source draw bracket')
        lower_start,_=bounds(begin);_,upper_done=bounds(end)
        for stream in samples:
            match=row['matches'].get(stream)
            if not match or 'afterTwoRAF' not in match:continue
            displayed=match['afterTwoRAF']
            if displayed<lower_start-1e-4:raise ValueError('pixel arrived before causal source lower bound')
            samples[stream].append({'id':row['id'],
                'lower_ms':max(0,displayed-upper_done),
                'upper_ms':displayed-lower_start,
                'source_clock_uncertainty_ms':upper_done-lower_start,
                'control_request_upper_ms':displayed-row['sent']})
    return {'method':'causal echo bounds, source draw bracket -> product canvas + two RAF callbacks',
        'rate_envelope':[1-rate_error,1+rate_error],
        'assumption':'clock rate envelope over this <=120s batch; not certified physical scanout timing',
        'echoes':len(echoes),'echo_constraints_consistent':True,
        'streams':{s:{'requested':len(rows),'matched':len(v),'p95_lower_ms':percentile([x['lower_ms'] for x in v]),
            'p95_upper_ms':percentile([x['upper_ms'] for x in v]),
            'max_source_clock_uncertainty_ms':max((x['source_clock_uncertainty_ms'] for x in v),default=None),
            'samples':v} for s,v in samples.items()}}
