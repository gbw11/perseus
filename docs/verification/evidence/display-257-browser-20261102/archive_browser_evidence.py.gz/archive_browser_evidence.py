"""Summarize the real product viewer, without rounding observed FPS to five."""
import gzip, hashlib, json, math, shutil, sys
from pathlib import Path

here=Path(__file__).parent;repo=here.parent/'worktrees/display-257-dual-stream'
destination=repo/'docs/verification/evidence/display-257-browser-20261102'
destination.mkdir(parents=True,exist_ok=True)
for name in sys.argv[1:]:
    source=here/name;data=json.loads((source/'result.json').read_text())
    soak=data.get('browser_soak',{});final=soak.get('final',{})
    seconds=(final.get('at',0)-soak.get('started_browser_ms',0))/1000
    latency={}
    for identity in ('monitor-1','monitor-2'):
        values=[r['matches'][identity]['milliseconds'] for r in data.get('browser_latency',[]) if r['matches'].get(identity) and 'milliseconds' in r['matches'][identity]]
        latency[identity]={'requested':len(data.get('browser_latency',[])),'matched':len(values),
            'p50_ms':sorted(values)[max(0,math.ceil(len(values)*.5)-1)] if values else None,
            'p95_ms':sorted(values)[max(0,math.ceil(len(values)*.95)-1)] if values else None,
            'max_ms':max(values) if values else None}
    latency_phases={}
    for phase in ('browser_latency','browser_latency_post_soak'):
        latency_phases[phase]={}
        for identity in ('monitor-1','monitor-2'):
            values=[r['matches'][identity]['milliseconds'] for r in data.get(phase,[]) if r['matches'].get(identity) and 'milliseconds' in r['matches'][identity]]
            latency_phases[phase][identity]={'requested':len(data.get(phase,[])),'matched':len(values),'p95_ms':sorted(values)[max(0,math.ceil(len(values)*.95)-1)] if values else None,'max_ms':max(values) if values else None}
    pooled={}
    for identity in ('monitor-1','monitor-2'):
        values=[r['matches'][identity]['milliseconds'] for phase in ('browser_latency','browser_latency_post_soak') for r in data.get(phase,[]) if r['matches'].get(identity) and 'milliseconds' in r['matches'][identity]]
        pooled[identity]={'matched':len(values),'requested':sum(len(data.get(p,[])) for p in ('browser_latency','browser_latency_post_soak')),'p95_ms':sorted(values)[max(0,math.ceil(len(values)*.95)-1)] if values else None,'max_ms':max(values) if values else None}
    samples=data.get('resources',{}).get('samples',[])
    window=sum(b['at']-a['at'] for a,b in zip(samples,samples[1:]))
    cpu={g:sum((b['at']-a['at'])*b['groups'][g]['cpu_percent']/100 for a,b in zip(samples,samples[1:]))/window for g in ('sender','native_worker','other_pipeline','browser','xorg','other_system')} if window else {}
    capture_bytes={}
    if data.get('soak_initial_status'):
        start={s['output_id']:s['bytes_total'] for s in data['soak_initial_status']['streams']}
        capture_bytes={s['output_id']:s['bytes_total']-start[s['output_id']] for s in data['final_status']['streams']}
    summary={'trial':name,'error':data.get('error'),'browser_version':data.get('browser_version'),'configured_fps':data.get('configured_fps',5),
        'measurement_scope':'PC browser request -> real X11 pixels -> JPEG -> product viewer canvas draw -> two requestAnimationFrame callbacks; includes outbound control; not physical LCD scanout',
        'soak_seconds_browser_clock':seconds,'soak_seconds_controller':data.get('elapsed_s'),
        'streams':{k:{**v,'fps':v['frames']/seconds if seconds else None} for k,v in final.get('streams',{}).items()},
        'browser_latency':latency,'proxy':final.get('proxy'),
        'browser_latency_phases':latency_phases,'browser_latency_same_trial_pooled':pooled,
        'additional_stream_connections_in_soak':{k:v['connections']-soak.get('proxy_start',{}).get(k,{}).get('connections',0) for k,v in final.get('proxy',{}).items()},
        'additional_proxy_errors_in_soak':{k:len(v['errors'])-len(soak.get('proxy_start',{}).get(k,{}).get('errors',[])) for k,v in final.get('proxy',{}).items()},
        'multipart_body_mbps':sum(v['bytes']-soak.get('proxy_start',{}).get(k,{}).get('bytes',0) for k,v in final.get('proxy',{}).items())*8/seconds/1e6 if seconds else None,
        'cpu_mean_cores':cpu,'cpu_sample_seconds':window,
        'jpeg_capture_mbps':sum(capture_bytes.values())*8/seconds/1e6 if seconds and capture_bytes else None,
        'jpeg_rate_note':'encoded source bytes, not wire bytes; interval spans adjacent API snapshots',
        'cleanup':data.get('cleanup'),'hotplug_freshness':data.get('hotplug_freshness')}
    if samples:
        summary['available_min_mib']=min(s['available_bytes'] for s in samples)/1048576
        summary['pipeline_rss_first_last_mib']=[sum(s['groups'][g]['rss_sum_bytes'] for g in ('sender','native_worker','other_pipeline'))/1048576 for s in (samples[0],samples[-1])]
    summary['causal_video_latency_bounds']={}
    for p in sorted(source.glob('clock-latency-bounds-*.json')):
        bounded=json.loads(p.read_text())
        summary['causal_video_latency_bounds'][p.name]={**{k:v for k,v in bounded.items() if k!='streams'},'streams':{s:{k:v for k,v in values.items() if k!='samples'} for s,values in bounded['streams'].items()}}
    if data.get('hotplug'):
        rows=data['hotplug']['observations']
        summary['hotplug_phases']={phase:{'samples':len(sub:=[r for r in rows if r['phase']==phase]),'disconnected_samples':sum(any(v=='disconnected' for v in r['physical']['drm'].values()) for r in sub)} for phase in {r['phase'] for r in rows}}
        for target in ('monitor-1','monitor-2'):
            sub=[r for r in rows if r['phase']==target]
            if not sub:continue
            peer='monitor-2' if target=='monitor-1' else 'monitor-1'
            connector='card0-HDMI-A-'+target[-1]
            disconnected=[r for r in sub if r['physical']['drm'].get(connector)=='disconnected']
            summary['hotplug_phases'][target].update(
                peer=peer,
                peer_unavailable_samples=sum(any(s['output_id']==peer and s['status']!='live' for s in r['api']['streams']) for r in sub),
                peer_new_gaps_over_1s=sub[-1]['browser']['streams'][peer]['gapsOver1s']-sub[0]['browser']['streams'][peer]['gapsOver1s'],
                max_runtime_age_s=max(r['physical']['runtime_age_s'] for r in sub),
                target_unavailable_samples=sum(any(s['output_id']==target and s['status']=='unavailable' for s in r['api']['streams']) for r in disconnected),
                peer_draws_during_observed_disconnect=(disconnected[-1]['browser']['streams'][peer]['frames']-disconnected[0]['browser']['streams'][peer]['frames']) if disconnected else None,
                final_states={s['output_id']:s['status'] for s in sub[-1]['api']['streams']})
    (destination/(name+'-summary.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (destination/(name+'.json.gz')).write_bytes(gzip.compress((source/'result.json').read_bytes(),mtime=0))
    for p in source.glob('*.png'):shutil.copyfile(p,destination/(name+'-'+p.name))
    for p in source.glob('browser-marker-proof-*.json'):shutil.copyfile(p,destination/(name+'-'+p.name))
    for pattern in ['clock-calibration-*.json','clock-latency-bounds-*.json']:
        for p in source.glob(pattern):shutil.copyfile(p,destination/(name+'-'+p.name))
    for p in source.glob('*.py'):(destination/(name+'-'+p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    if (source/'board-kiosk-candidate-manifest.json').exists():shutil.copyfile(source/'board-kiosk-candidate-manifest.json',destination/(name+'-board-kiosk-manifest.json'))
    print(json.dumps({k:v for k,v in summary.items() if k not in ('cleanup','hotplug_freshness')},ensure_ascii=False))
for name in ('browser_acceptance_20261102.py','browser_harness_20261102.py','latency_marker_20261102.py','dual_physical_20261102.py','board_prepare.py','archive_browser_evidence.py'):
    (destination/(name+'.gz')).write_bytes(gzip.compress((here/name).read_bytes(),mtime=0))
files=list((repo/'platform/services/display/router/xenova_display').glob('native_*.py'))
files += [repo/'platform/services/display/router/xenova_display/viewer.html',repo/'platform/services/display/router/xenova_display/kiosk.py',repo/'platform/services/display/router/xenova_display/stream.py',repo/'platform/services/display/router/xenova_display/runtime_status.py',repo/'platform/services/display/router/deploy/board-kms/stream-host.py']
(destination/'source-hashes.json').write_text(json.dumps({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
