"""Prepare a minimal, hash-guarded candidate from the board's exact source."""
import ast,hashlib,json
from pathlib import Path
here=Path(__file__).parent;repo=here.parent/'worktrees/display-257-dual-stream'
inspection=json.loads((here/'inspect_kiosk_20261102.json').read_text())
original=next(iter(inspection['sources'].values()))
before=original['source']
assert hashlib.sha256(before.encode()).hexdigest()==original['sha256']
source=(repo/'platform/services/display/router/xenova_display/kiosk.py').read_text()
methods=source[source.index('    async def _layout_loop'):source.index('\n\nif __name__')]
methods=methods.replace('                if self.browser:\n                    try: await self.browser.close()\n                    finally: self.browser = None\n','')
start,end=before.index('    async def _run(self):'),before.index('\n\nif __name__')
candidate=before[:start]+methods+before[end:]
candidate=candidate.replace('        self.states = {}','        self.states = {}\n        self.mapping = {}\n        self.mapping_at = 0\n        self.launch_lock = asyncio.Lock()')
ast.parse(candidate)
(here/'board-kiosk-isolated.py').write_bytes(candidate.encode())
manifest={'original_sha256':original['sha256'],'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),
 'paths':list(inspection['sources']),'changes':['per-output supervision','independent geometry observations and status publication','per-output verified renderer freshness'],
 'preserved':['original Chromium launch arguments','original per-output persistent profile','sandbox','authentication','existing service unit and environment']}
(here/'board-kiosk-candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
