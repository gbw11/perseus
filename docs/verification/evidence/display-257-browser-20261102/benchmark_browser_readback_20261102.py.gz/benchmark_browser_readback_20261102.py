"""Local observer-overhead comparison; not a substitute for board latency."""
import base64,json
from pathlib import Path
from playwright.sync_api import sync_playwright

here=Path(__file__).parent
url='data:image/jpeg;base64,'+base64.b64encode((here/'xenova-257-runtime-c8966d6e/monitor-1-last.jpg').read_bytes()).decode()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=False)
 page=browser.new_page(viewport={'width':1400,'height':900})
 warnings=[];page.on('console',lambda m:warnings.append(m.text) if 'Canvas2D' in m.text else None)
 data=page.evaluate(r'''async url=>{
  const bitmap=await createImageBitmap(await (await fetch(url)).blob()),result={};
  for(const mode of ['no-readback','direct-product-readback','one-pixel-diagnostic']){
   const canvas=document.createElement('canvas');canvas.width=1280;canvas.height=720;document.body.append(canvas);
   const ctx=canvas.getContext('2d'),off=new OffscreenCanvas(1,1),small=off.getContext('2d',{willReadFrequently:true}),values=[];
   for(let i=0;i<120;i++){
    await new Promise(r=>requestAnimationFrame(r));const start=performance.now();
    if(mode==='one-pixel-diagnostic'){small.drawImage(bitmap,1180,660,1,1,0,0,1,1);small.getImageData(0,0,1,1);}
    ctx.drawImage(bitmap,0,0);
    if(mode==='direct-product-readback')ctx.getImageData(1180,660,1,1);
    values.push(performance.now()-start);
   }
   result[mode]={samples:values,p50_ms:[...values].sort((a,b)=>a-b)[59],p95_ms:[...values].sort((a,b)=>a-b)[113],max_ms:Math.max(...values)};
   canvas.remove();
  }bitmap.close();return result;
 }''',url)
 browser.close()
data['console_warnings']=warnings
(here/'browser-readback-overhead-20261102.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:{a:b for a,b in v.items() if a!='samples'} if isinstance(v,dict) else v for k,v in data.items()}))
