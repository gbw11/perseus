import ast,json
from pathlib import Path
from board_prepare import connect,execute

here=Path(__file__).parent
tree=ast.parse((here/'postflight_20261102.py').read_text())
code=next(n.value.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REMOTE' for t in n.targets))
extra=r'''
for row in out['ipc_uid_1000']:
 p=pathlib.Path('/proc')/row['cpid']/'comm'
 row['creator_comm']=p.read_text().strip() if p.exists() else None
root=pathlib.Path('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs')
paths=['/opt/xenova-display/current/lib/xenova_display/kiosk.py',str(root/'opt/xenova-kiosk-runtime/20261028/lib/xenova_display/kiosk.py')]
out['kiosk_source_hashes']={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in paths}
out['drm']={p.name:(p/'status').read_text().strip() for p in pathlib.Path('/sys/class/drm').glob('card*-*') if (p/'status').exists()}
out['runtime']=json.loads((root/'run/xenova-kiosk/display-runtime.json').read_text())
out['remaining_kiosk_trial_directories']=[str(p) for p in pathlib.Path('/run').glob('xenova-257-kiosk-*')]
print(json.dumps(out))
'''
code=code.replace('print(json.dumps(out))',extra)
t=connect()
try:
    result=execute(t,code,timeout=65)
    (here/'postflight-acceptance-20261102.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
finally:t.close()
