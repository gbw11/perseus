"""Test-only loopback SSH proxy and instrumentation of the unmodified viewer."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from PIL import Image

INSTRUMENT = r'''(() => {
 const p=window.__probe={streams:{},sent:{},matches:{},active:false};
 const original=CanvasRenderingContext2D.prototype.drawImage;
 const decode=globalThis.createImageBitmap.bind(globalThis),pixels=new WeakMap();
 const diagnostic=new OffscreenCanvas(1,1),sample=diagnostic.getContext('2d',{willReadFrequently:true});
 // Never read back the product canvas: that can flush its GPU work or change
 // Chrome's backing-store heuristic. Sample only the same decoded bitmap.
 globalThis.createImageBitmap=(...args)=>decode(...args).then(bitmap=>{
  if(p.active){sample.drawImage(bitmap,1180,660,1,1,0,0,1,1);pixels.set(bitmap,sample.getImageData(0,0,1,1).data);}
  return bitmap;
 });
 CanvasRenderingContext2D.prototype.drawImage=function(...args){
  const result=original.apply(this,args),id=this.canvas.id;
  if(!['monitor-1','monitor-2'].includes(id))return result;
  const now=performance.now(),s=p.streams[id]??={frames:0,first:now,last:now,maxGap:0,gapsOver1s:0};
  if(s.frames){const gap=now-s.last;s.maxGap=Math.max(s.maxGap,gap);if(gap>1000)s.gapsOver1s++;}
  s.frames++;s.last=now;
  if(p.active){
   const rgb=pixels.get(args[0]);if(!rgb)return result;
   let found=null;
   for(let n=1;n<=63;n++)if(Math.max(Math.abs(rgb[0]-(32+(n&3)*56)),Math.abs(rgb[1]-(32+((n>>2)&3)*56)),Math.abs(rgb[2]-(32+((n>>4)&3)*56)))<=10){found=n;break;}
   if(found!==null && p.sent[found]!==undefined && !p.matches[id+':'+found]){
    const key=id+':'+found;p.matches[key]={drawn:now,rgb:[...rgb]};
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
     p.matches[key].afterTwoRAF=performance.now();p.matches[key].milliseconds=performance.now()-p.sent[found];
    }));
   }
  }
  return result;
 };
})();'''


class BrowserHarness:
    def __init__(self, request, marker, token, directory, nonce):
        self.directory, self.nonce = directory, nonce
        self.counts = {'monitor-1': {'connections':0,'bytes':0,'errors':[]},
                       'monitor-2': {'connections':0,'bytes':0,'errors':[]}}
        self.errors = []
        self.proofs = []
        self.calibrations = []
        self.server = None; self.browser = None; self.playwright = None
        owner = self
        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.0'
            disable_nagle_algorithm = True
            def log_message(self,*_): pass
            def do_GET(self): self.forward('GET')
            def do_POST(self): self.forward('POST')
            def forward(self,method):
                if self.path=='/__probe/marker':
                    if self.headers.get('X-Probe-Key') != nonce:
                        self.send_error(403);return
                    data=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
                    try: payload=json.dumps(marker(data)).encode()
                    except Exception as exc:
                        self.send_error(502,type(exc).__name__);return
                    self.send_response(200);self.send_header('Content-Type','application/json')
                    self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload);return
                allowed = self.path in ['/demo','/auth','/api/v1/streams','/streams/monitor-1.mjpeg','/streams/monitor-2.mjpeg']
                if not allowed: self.send_error(404);return
                conn=None;record=None
                try:
                    headers={k:self.headers[k] for k in ('Cookie','Authorization','Content-Type') if k in self.headers}
                    body=self.rfile.read(int(self.headers.get('Content-Length','0'))) if method=='POST' else None
                    conn,response=request(method,self.path,headers,body)
                    self.send_response(response.status)
                    for k,v in response.getheaders():
                        if k.lower() in ('content-type','set-cookie','cache-control','x-content-type-options'):
                            self.send_header(k,v)
                    self.end_headers()
                    if self.path.endswith('.mjpeg') and response.status==200:
                        record=owner.counts[self.path.split('/')[2].split('.')[0]];record['connections']+=1
                    while True:
                        data=response.read1(65536)
                        if not data:break
                        self.wfile.write(data);self.wfile.flush()
                        if record:record['bytes']+=len(data)
                except (BrokenPipeError,ConnectionResetError):pass
                except Exception as exc:
                    if record:record['errors'].append({'at':time.perf_counter(),'type':type(exc).__name__})
                    else:owner.errors.append(type(exc).__name__)
                finally:
                    if conn:conn.close()
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.server.daemon_threads=True
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.playwright=sync_playwright().start()
        self.browser=self.playwright.chromium.launch(
            executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=False,
            args=['--disable-background-timer-throttling','--disable-renderer-backgrounding'])
        self.page=self.browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
        self.page.add_init_script(INSTRUMENT)
        self.page.goto('http://127.0.0.1:'+str(self.server.server_port)+'/demo')
        self.page.locator('#key').fill(token);self.page.locator('#login button').click()
        self.page.wait_for_function("['monitor-1','monitor-2'].every(id=>window.__probe.streams[id]?.frames>2)",timeout=45000)
        self.page.wait_for_function("['monitor-1','monitor-2'].every(id=>document.getElementById(id+'-status').textContent==='화면 수신 중')",timeout=10000)
        self.page.screenshot(path=str(directory/'browser-initial.png'))

    def latency(self, identifiers):
        try:
            rows = self.page.evaluate(r'''async ({ids,key})=>{
         const p=window.__probe;p.active=true;const rows=[],clocks=[];
         try{for(const id of ids){
          const clockSent=performance.now(),clockResponse=await fetch('/__probe/marker',{method:'POST',headers:{'Content-Type':'application/json','X-Probe-Key':key},body:JSON.stringify({clock:true})});
          if(!clockResponse.ok)throw Error('clock echo failed');const clock=await clockResponse.json();clocks.push({sent:clockSent,received:performance.now(),board_clock_s:clock.board_clock_s});
          for(const stream of ['monitor-1','monitor-2'])delete p.matches[stream+':'+id];
          p.sent[id]=performance.now();
          const response=await fetch('/__probe/marker',{method:'POST',headers:{'Content-Type':'application/json','X-Probe-Key':key},body:JSON.stringify({id})});
          if(!response.ok)throw Error('marker control failed');const ack=await response.json(),ackReceived=performance.now();
          const deadline=performance.now()+2500;
          while(performance.now()<deadline&&!['monitor-1','monitor-2'].every(s=>p.matches[s+':'+id]?.milliseconds!==undefined))await new Promise(r=>setTimeout(r,5));
          rows.push({id,sent:p.sent[id],ack_received:ackReceived,board_draw_request_s:ack.board_draw_request,board_draw_done_s:ack.board_draw_done,matches:Object.fromEntries(['monitor-1','monitor-2'].map(s=>[s,p.matches[s+':'+id]??null]))});
          await new Promise(r=>setTimeout(r,250));
         }}finally{p.active=false;p.lastClocks=clocks;}return rows;
        }''',{'ids':identifiers,'key':self.nonce})
            # Cross-check the actual composited viewer, after all timings have
            # been recorded. Screenshot work is not inside the latency samples.
            filename='browser-marker-proof-'+str(len(self.proofs)+1)
            clocks=self.page.evaluate('window.__probe.lastClocks')
            self.calibrations.append(clocks)
            (self.directory/('clock-calibration-'+str(len(self.calibrations))+'.json')).write_text(json.dumps(clocks,indent=2)+'\n')
            proof={'id':identifiers[-1],'pixels':{}}
            self.page.screenshot(path=str(self.directory/(filename+'.png')))
            with Image.open(self.directory/(filename+'.png')) as image:
                identifier=identifiers[-1]
                expected=[32+(identifier&3)*56,32+((identifier>>2)&3)*56,32+((identifier>>4)&3)*56]
                for identity in ('monitor-1','monitor-2'):
                    bounds=self.page.locator('#'+identity).bounding_box()
                    point=(round(bounds['x']+1180/1280*bounds['width']),round(bounds['y']+660/720*bounds['height']))
                    rgb=list(image.convert('RGB').getpixel(point))
                    proof['pixels'][identity]={'point':point,'rgb':rgb,'expected':expected,'matched':max(abs(a-b) for a,b in zip(rgb,expected))<=12}
            self.proofs.append(proof)
            (self.directory/(filename+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
            if not all(v['matched'] for v in proof['pixels'].values()):raise RuntimeError('viewer screenshot did not match decoded marker')
            from clock_bounds_20261102 import calculate
            bounded=calculate(rows,clocks)
            (self.directory/('clock-latency-bounds-'+str(len(self.calibrations))+'.json')).write_text(json.dumps(bounded,indent=2)+'\n')
            return rows
        finally:
            self.page.evaluate("async key=>{await fetch('/__probe/marker',{method:'POST',headers:{'Content-Type':'application/json','X-Probe-Key':key},body:JSON.stringify({hide:true})})}",self.nonce)

    def snapshot(self):
        data=self.page.evaluate("({at:performance.now(),streams:window.__probe.streams,message:document.querySelector('#message').textContent,statuses:Object.fromEntries(['monitor-1','monitor-2'].map(id=>[id,document.getElementById(id+'-status').textContent]))})")
        data['proxy']=json.loads(json.dumps(self.counts));return data

    def reset(self):
        return self.page.evaluate("()=>{window.__probe.streams={};return performance.now()}")

    def close(self):
        if self.browser:self.browser.close()
        if self.playwright:self.playwright.stop()
        if self.server:self.server.shutdown();self.server.server_close()
