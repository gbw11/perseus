import json,os,sys,time,tempfile,subprocess,signal,uuid
from pathlib import Path
repo=Path('/mnt/c/Users/SSAFY/Desktop/자율프로젝트/outputs/worktrees/display-256-dual-hdmi')
sys.path.insert(0,str(repo/'platform/services/dom0-manager'))
from dom0_manager.runtime_logs import LogStore
out=Path('/mnt/c/Users/SSAFY/Desktop/자율프로젝트/outputs/runtime-logs')
tmp=Path(tempfile.mkdtemp(prefix='xenova-runtime-logs-'))
db=tmp/'logs.sqlite3';unit='xenova-runtime-log-probe-'+uuid.uuid4().hex[:8]+'.service'
env={**os.environ,'PYTHONPATH':str(repo/'platform/services/dom0-manager')}
readers=[];results={'environment':'local WSL systemd; not Raspberry Pi','unit':unit,'database':str(db),'actual_journal':True}
def start():
 log=(tmp/('collector-'+str(len(readers))+'.log')).open('w')
 proc=subprocess.Popen([sys.executable,'-m','dom0_manager.log_collector','--db',str(db),'--unit',unit],env=env,stdout=log,stderr=log)
 readers.append((proc,log));time.sleep(1);assert proc.poll() is None
 return proc
def stop(proc):
 proc.send_signal(signal.SIGTERM);proc.wait(timeout=5);assert proc.returncode==0

def publish(marker):
 code='import time; print('+repr(marker+' function completed password=not-a-real-password')+',flush=True);time.sleep(1)'
 p=subprocess.run(['systemd-run','--quiet','--wait','--collect','--unit='+unit,'--property=StandardOutput=journal',sys.executable,'-u','-c',code],capture_output=True,text=True,timeout=20)
 assert p.returncode==0,p.stderr
 deadline=time.monotonic()+10
 while time.monotonic()<deadline:
  logs=LogStore(db).query()['items']
  if any(marker in r['message'] for r in logs):return
  time.sleep(.2)
 raise AssertionError('journal record did not arrive: '+marker)
try:
 first=start();publish('PROBE_FIRST');stop(first)
 store=LogStore(db);first_count=len(store.query()['items']);checkpoint=store.checkpoint('dom0');assert checkpoint
 second=start();publish('PROBE_SECOND');stop(second)
 rows=store.query()['items'];messages=[r['message'] for r in rows]
 assert sum('PROBE_FIRST' in m for m in messages)==1,messages
 assert sum('PROBE_SECOND' in m for m in messages)==1,messages
 assert all('not-a-real-password' not in m for m in messages)
 assert store.sources()[0]['state']=='disconnected'
 results.update({'passed':True,'record_count':len(rows),'first_record_count':first_count,'checkpoint_persisted':True,'restart_no_duplicate':True,'second_record_after_restart':True,'secret_redacted_before_storage':True,'collector_stopped':True,'records':rows})
except Exception as exc:
 results.update({'passed':False,'error':str(exc),'collector_logs':[(tmp/('collector-'+str(i)+'.log')).read_text() for i in range(len(readers))]})
 raise
finally:
 for proc,log in readers:
  if proc.poll() is None:proc.terminate();proc.wait(timeout=5)
  log.close()
 subprocess.run(['systemctl','stop',unit],capture_output=True)
 (out/'local-journal-result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in results.items() if k!='records'}))
