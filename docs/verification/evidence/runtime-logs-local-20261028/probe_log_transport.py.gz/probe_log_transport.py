import json,os,sys,time,tempfile,subprocess,signal,uuid,socket,threading,secrets,hashlib
from pathlib import Path
repo=Path('/mnt/c/Users/SSAFY/Desktop/자율프로젝트/outputs/worktrees/display-256-dual-hdmi')
sys.path[:0]=[str(repo/'platform/services/dom0-manager'),str(repo/'platform/services/vm-agent/mqtt-client')]
import uvicorn,httpx
from dom0_manager.runtime_logs import LogStore
from dom0_manager.config import Settings
from dom0_manager.main import create_app
out=Path('/mnt/c/Users/SSAFY/Desktop/자율프로젝트/outputs/runtime-logs')
tmp=Path(tempfile.mkdtemp(prefix='xenova-log-http-'));db=tmp/'logs.sqlite3';config=tmp/'sources.json'
producer_key=secrets.token_urlsafe(32);reader_key=secrets.token_urlsafe(32)
vm='00000000-0000-4000-8000-000000000003';source='local-probe-vm3'
unit='xenova-log-http-probe-'+uuid.uuid4().hex[:8]+'.service'
config.write_text(json.dumps({'sources':{source:{'vm_id':vm,'components':[unit],'token_sha256':hashlib.sha256(producer_key.encode()).hexdigest()}}}))
store=LogStore(db);settings=Settings(driver='mock',service_token=reader_key,runtime_log_db=str(db),runtime_log_ingest_config=str(config))
sock=socket.socket();sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
workers=[];servers=[]
results={'environment':'local WSL systemd + real HTTP Manager mock driver; no real VM/board','unit':unit,'actual_http_ingestion':True}
def start_server():
 listener=socket.socket();listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);listener.bind(('127.0.0.1',port));listener.listen(16)
 server=uvicorn.Server(uvicorn.Config(create_app(settings),log_level='critical',access_log=False,ws='none'))
 thread=threading.Thread(target=lambda:server.run(sockets=[listener]),daemon=True);thread.start()
 end=time.monotonic()+5
 while time.monotonic()<end and not server.started:time.sleep(.05)
 assert server.started
 servers.append((server,thread));return server,thread

def ship():
 log=(tmp/('shipper-'+str(len(workers))+'.log')).open('w')
 env={**os.environ,'PYTHONPATH':os.pathsep.join(sys.path[:2]),'XENOVA_LOG_SOURCE_TOKEN':producer_key}
 proc=subprocess.Popen([sys.executable,'-m','dom0_manager.log_shipper','--endpoint',f'http://127.0.0.1:{port}/api/v1/logs/ingest','--source',source,'--unit',unit,'--checkpoint',str(tmp/'cursor')],env=env,stdout=log,stderr=log)
 workers.append((proc,log));return proc

def publish(marker):
 text=marker+' cross-process log password="not-a-real-secret"'
 code='import time;print('+repr(text)+',flush=True);time.sleep(.5)'
 p=subprocess.run(['systemd-run','--quiet','--wait','--collect','--unit='+unit,'--property=StandardOutput=journal',sys.executable,'-u','-c',code],capture_output=True,text=True,timeout=15)
 assert p.returncode==0,p.stderr
 end=time.monotonic()+10
 while time.monotonic()<end:
  rows=store.query()['items']
  if any(marker in r['message'] for r in rows):return
  time.sleep(.2)
 raise AssertionError('forwarded log missing: '+marker)
try:
 server,thread=start_server();worker=ship();publish('HTTP_FIRST')
 worker.terminate();worker.wait(timeout=6);assert worker.returncode==0
 saved=(tmp/'cursor').read_text();epoch=store.epoch
 server.should_exit=True;thread.join(timeout=10);assert not thread.is_alive()
 failed=ship();failed.wait(timeout=12);assert failed.returncode!=0
 assert (tmp/'cursor').read_text()==saved
 server,thread=start_server();worker=ship();publish('HTTP_SECOND')
 client=httpx.Client(base_url=f'http://127.0.0.1:{port}',timeout=5,trust_env=False)
 assert client.get('/api/v1/logs',headers={'Authorization':'Bearer '+producer_key}).status_code==401
 assert client.get('/api/v1/vms',headers={'Authorization':'Bearer '+producer_key}).status_code==401
 response=client.get('/api/v1/logs',params={'vm_id':vm},headers={'Authorization':'Bearer '+reader_key});assert response.status_code==200
 page=response.json();messages=[r['message'] for r in page['items']]
 assert sum('HTTP_FIRST' in m for m in messages)==1
 assert sum('HTTP_SECOND' in m for m in messages)==1
 assert all('not-a-real-secret' not in m for m in messages)
 assert all(r['vm_id']==vm and r['source_id']==source for r in page['items'])
 assert page['epoch']==epoch
 client.close()
 results.update({'passed':True,'read_status':response.status_code,'records':page['items'],'network_failure_preserved_checkpoint':True,'receiver_restart_preserved_epoch':True,'reconnect_no_duplicate':True,'source_token_read_denied':True,'source_token_control_denied':True,'source_uuid_bound_by_receiver':True,'secrets_redacted':True})
except Exception as exc:
 results.update({'passed':False,'error':str(exc),'worker_logs':[(tmp/('shipper-'+str(i)+'.log')).read_text() for i in range(len(workers))]});raise
finally:
 for proc,log in workers:
  if proc.poll() is None:proc.terminate();proc.wait(timeout=6)
  log.close()
 for server,thread in servers:
  server.should_exit=True;thread.join(timeout=10)
 subprocess.run(['systemctl','stop',unit],capture_output=True)
 (out/'local-http-transport-result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in results.items() if k not in ['records','worker_logs']}))
