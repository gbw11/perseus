import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent.parent/'display-257'))
from board_prepare import connect,execute
here=Path(__file__).parent
old=(here/'backup-original/config.txt').read_bytes()
new=old.replace(b'dtoverlay=vc4-kms-v3d\n',b'dtoverlay=vc4-kms-v3d-pi4,cma-64\n')
assert new!=old and new.count(b'dtoverlay=vc4-kms-v3d-pi4,cma-64')==1
code=r"""import hashlib,json,os,subprocess
from pathlib import Path
p=Path('/boot/config.txt');old_hash=OLD
assert hashlib.sha256(p.read_bytes()).hexdigest()==old_hash,'normal config changed; preserve external work'
backup=Path('/root/xenova-hdmi-backup/20261028-060513/config.txt')
assert backup.is_file() and hashlib.sha256(backup.read_bytes()).hexdigest()==old_hash,'backup mismatch'
flag=Path('/sys/firmware/devicetree/base/chosen/bootloader/tryboot')
assert flag.exists() and int.from_bytes(flag.read_bytes(),'big')==1,'validated trial boot is required'
connectors=[q for q in Path('/sys/class/drm').glob('card*-HDMI-A-*') if (q/'status').read_text().strip()=='connected']
assert len(connectors)==2,'both HDMI outputs must still be connected'
assert 'CmaTotal:          65536 kB' in Path('/proc/meminfo').read_text(),'preserve existing CMA reservation'
assert subprocess.run(['systemctl','is-active','--quiet','xenova-dom0-manager.service']).returncode==0
xen=subprocess.check_output(['xl','list'],text=True)
assert all(name in xen for name in ['debian-dev','zephyr-drive-a','zephyr-drive-b']),'wait for original guest fleet'
data=DATA
with Path('/boot/config.txt.new').open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
assert hashlib.sha256(Path('/boot/config.txt.new').read_bytes()).hexdigest()==NEW
os.replace('/boot/config.txt.new','/boot/config.txt');os.sync()
print(json.dumps({'normal_config_persisted':True,'new_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'changed_from':'dtoverlay=vc4-kms-v3d','changed_to':'dtoverlay=vc4-kms-v3d-pi4,cma-64',
 'backup':str(backup),'xen':xen,'connected_hdmi':[q.name for q in connectors],
 'no_additional_reboot':True,'kernel_xen_boot_script_replaced':False}))
""".replace('OLD',repr(hashlib.sha256(old).hexdigest())).replace('DATA',repr(new)).replace('NEW',repr(hashlib.sha256(new).hexdigest()))
t=connect()
try:
 r=execute(t,code)
 (here/'persisted-hdmi-config-20261028.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(r,ensure_ascii=False,indent=2))
finally:t.close()
