"""Backup and stage an official Pi4 KMS overlay, then request one tryboot reboot."""
import base64
import getpass
import hashlib
import json
from pathlib import Path
import socket
import sys
import time
import paramiko
sys.path.insert(0,str(Path(__file__).parent.parent/'display-257'))
from board_prepare import PIN,execute
HERE=Path(__file__).parent
manifest=json.loads((HERE/'backup-original/manifest.json').read_text(encoding='utf-8'))
overlay=(HERE/'source/vc4-kms-v3d-pi4.dtbo').read_bytes()
assert overlay[:4]==b'\xd0\x0d\xfe\xed'
original=(HERE/'backup-original/config.txt').read_bytes()
assert original.count(b'dtoverlay=vc4-kms-v3d\n')==1
trial=original.replace(b'dtoverlay=vc4-kms-v3d\n',b'dtoverlay=vc4-kms-v3d-pi4,cma-64\n')+b'\n# Xenova 256 one-shot HDMI KMS trial; normal config.txt is unchanged.\n'
password=getpass.getpass('Board SSH password (memory only): ')
def connect():
    t=paramiko.Transport(socket.create_connection(('192.168.30.96',22),timeout=4))
    try:
        t.start_client(timeout=6)
        pin=base64.b64encode(hashlib.sha256(t.get_remote_server_key().asbytes()).digest()).decode().rstrip('=')
        if pin!=PIN:raise RuntimeError('SSH host key mismatch; no authentication attempted')
        t.auth_password('root',password);return t
    except Exception:t.close();raise
result={'normal_config_modified':False,'overlay_sha256':hashlib.sha256(overlay).hexdigest(),
    'trial_config_sha256':hashlib.sha256(trial).hexdigest(),'reboot_request':'systemctl reboot "0 tryboot"',
    'kernel_commit':'95b85bebbedcaedfa7ca79116ed38b7376fba412','expected_cma_mib':64}
out=HERE/'tryboot-result-20261028.json'
t=connect()
try:
    code=r'''
import hashlib,json,os,shutil,time
from pathlib import Path
expected=EXPECTED
for name,digest in expected.items():assert hashlib.sha256((Path('/boot')/name).read_bytes()).hexdigest()==digest,'boot file changed since backup'
assert not Path('/boot/tryboot.txt').exists(),'existing tryboot configuration must be preserved'
assert not Path('/boot/overlays/vc4-kms-v3d-pi4.dtbo').exists(),'existing overlay must be preserved'
backup=Path('/root/xenova-hdmi-backup')/time.strftime('%Y%m%d-%H%M%S',time.gmtime())
backup.mkdir(parents=True,mode=0o700)
for name in expected:shutil.copyfile(Path('/boot')/name,backup/name);(backup/name).chmod(0o600)
Path('/boot/overlays').mkdir(exist_ok=True)
print(json.dumps({'backup':str(backup),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'original_hashes':expected}))
'''.replace('EXPECTED',repr(manifest['sha256']))
    result['preflight']=execute(t,code)
    sftp=paramiko.SFTPClient.from_transport(t)
    try:
        for name,data in [('/boot/overlays/vc4-kms-v3d-pi4.dtbo',overlay),('/boot/tryboot.txt',trial)]:
            with sftp.open(name+'.new','wb') as f:f.write(data)
            sftp.posix_rename(name+'.new',name)
    finally:sftp.close()
    result['staged']=execute(t,r'''
import hashlib,json,os
from pathlib import Path
assert hashlib.sha256(Path('/boot/config.txt').read_bytes()).hexdigest()==CONFIG
assert hashlib.sha256(Path('/boot/tryboot.txt').read_bytes()).hexdigest()==TRIAL
assert hashlib.sha256(Path('/boot/overlays/vc4-kms-v3d-pi4.dtbo').read_bytes()).hexdigest()==OVERLAY
os.sync()
print(json.dumps({'normal_config_unchanged':True,'trial_and_overlay_hashes_verified':True}))
'''.replace('CONFIG',repr(manifest['sha256']['config.txt'])).replace('TRIAL',repr(result['trial_config_sha256'])).replace('OVERLAY',repr(result['overlay_sha256'])))
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'event':'staged','backup':result['preflight']['backup'],'normal_config_unchanged':True}),flush=True)
    execute(t,r'''
import json,subprocess
subprocess.Popen(['/bin/sh','-c','sleep 2; systemctl reboot "0 tryboot"'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
print(json.dumps({'reboot_scheduled':True}))
''')
finally:t.close()
started=time.monotonic();next_report=started+25
try:
    while time.monotonic()-started<200:
        time.sleep(4)
        try:
            t=connect()
            try:
                row=execute(t,r'''
import datetime,hashlib,json,subprocess
from pathlib import Path
read=lambda p:Path(p).read_text().strip()
rows=[]
for path in Path('/sys/class/drm').glob('card*-*'):
    if not (path/'status').exists():continue
    edid=(path/'edid').read_bytes() if (path/'edid').exists() else b''
    rows.append({'name':path.name,'status':read(path/'status'),'modes':read(path/'modes'),'edid_bytes':len(edid),'edid_sha256':hashlib.sha256(edid).hexdigest() if edid else None})
tryboot=Path('/sys/firmware/devicetree/base/chosen/bootloader/tryboot')
print(json.dumps({'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'boot_id':read('/proc/sys/kernel/random/boot_id'),'tryboot_flag':int.from_bytes(tryboot.read_bytes(),'big') if tryboot.exists() else None,
 'drm':rows,'dri_nodes':[str(p) for p in Path('/dev/dri').glob('*')],
 'hdmi_statuses':{str(p.parent):read(p).replace('\u0000','') for p in Path('/sys/firmware/devicetree/base').rglob('status') if 'hdmi@' in p.parent.name},
 'xen':subprocess.check_output(['xl','list'],text=True),
 'config_sha256':hashlib.sha256(Path('/boot/config.txt').read_bytes()).hexdigest(),
 'dmesg_graphics':'\n'.join(l for l in subprocess.check_output(['dmesg'],text=True).splitlines() if any(k in l.lower() for k in ['vc4','hdmi','drm','cma:','framebuffer','v3d']))}))
''',timeout=30)
            finally:t.close()
            if row['boot_id']!=result['preflight']['boot_id']:
                result['postboot']=row;result['reboot_observed']=True
                print(json.dumps({'event':'reconnected','tryboot_flag':row['tryboot_flag'],'drm':row['drm'],'hdmi_statuses':row['hdmi_statuses']}),flush=True)
                break
        except (OSError,EOFError,paramiko.SSHException):pass
        if time.monotonic()>=next_report:
            print(json.dumps({'event':'waiting_for_reboot','elapsed_s':round(time.monotonic()-started)}),flush=True);next_report=time.monotonic()+25
    else:result['reboot_observed']=False;result['reason']='SSH unavailable or boot id unchanged within bounded observation; normal config remains untouched'
finally:
    password=None
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'event':'complete','reboot_observed':result.get('reboot_observed'),'normal_config_modified':False}),flush=True)
