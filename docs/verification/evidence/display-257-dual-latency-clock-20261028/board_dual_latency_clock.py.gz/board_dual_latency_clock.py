"""Two independent encoders of ONE physical source; decoded-pixel latency upper bound."""
import sys
sys.path.append(r'C:\Users\SSAFY\AppData\Roaming\Python\Python311\site-packages')
import io
import json
from pathlib import Path
import threading
import time
from PIL import Image

HERE = Path(__file__).parent
source = (HERE/'board_soak_optimized.py').read_text(encoding='utf-8')
ns = {'__file__': str(HERE/'board_soak_optimized.py')}
exec(compile(source.split("\noutdir=HERE/")[0], '<soak-definitions>', 'exec'), ns)
remote = ns['remote']
remote = remote.replace("for identity in ['monitor-1','monitor-2']:", "for identity in ['monitor-2']:")
remote = remote.replace('time.perf_counter()+330', 'time.perf_counter()+240')
old_rows = """rows={o.output_id:{'status':'mapped' if o.output_id==identity else 'unavailable',
                'renderer_alive':o.output_id==identity,'rectangle':[o.x,o.y,o.width,o.height],
                'connector':o.connector,'physical_verified':False} for o in config.outputs}"""
new_rows = """rows={o.output_id:{'status':'mapped','renderer_alive':True,
                'rectangle':[0,0,o.width,o.height],'connector':o.connector,
                'physical_verified':False} for o in config.outputs}"""
assert old_rows in remote
remote = remote.replace(old_rows, new_rows)
old_app = '    stream_app=relay.create_stream_app(config,status_file,token,allow_virtual=True)'
new_app = r'''
    # Deliberate diagnostic factory: each encoder owns a valid configuration with
    # its active output at x=0. Metadata truthfully reports the duplicated source.
    # This does NOT exercise two-output EDID mapping or two distinct renderers.
    def duplicated_physical_source(cfg, output, status):
        raw=cfg.model_dump()
        for row in raw['outputs']:row['x']=0 if row['output_id']==output.output_id else 1824
        own=RuntimeConfig.model_validate(raw)
        actual=next(o for o in own.outputs if o.output_id==output.output_id)
        return relay.Capture(own,actual,status)
    stream_app=relay.create_stream_app(config,status_file,token,allow_virtual=True,
        capture_factory=duplicated_physical_source)
    @stream_app.get('/probe/clock')
    def probe_clock():return {'board_clock':time.perf_counter()}
    @stream_app.post('/probe/marker')
    async def marker(request: relay.Request):
        body=await request.json();identifier=body.get('id')
        if type(identifier) is not int or not 1<=identifier<=30:
            raise relay.HTTPException(400)
        rgb=[64+(identifier&3)*48,64+((identifier>>2)&3)*48,64+((identifier>>4)&3)*48]
        expression="""(()=>{let e=document.getElementById('latency-probe');
        if(!e){e=document.createElement('div');e.id='latency-probe';document.body.appendChild(e)}
        Object.assign(e.style,{position:'fixed',left:'100px',top:'100px',width:'300px',height:'180px',
        zIndex:'2147483647',background:COLOR,color:'white',fontSize:'20px',pointerEvents:'none'});
        e.innerText='LATENCY TEST '+ID;return true})()""".replace('COLOR',json.dumps('rgb('+','.join(map(str,rgb))+')')).replace('ID',str(identifier))
        # CDP shares the source browser's main tab; serialize these probe calls.
        before=time.perf_counter()
        evaluated=await relay.asyncio.to_thread(cdp,'Runtime.evaluate',{'expression':expression,'returnByValue':True})
        if evaluated.get('exceptionDetails'):raise relay.HTTPException(500)
        return {'id':identifier,'rgb':rgb,'board_command_monotonic':before}
'''
assert old_app in remote
remote = remote.replace(old_app, new_app)
remote = remote.replace("if stream_server.started and stream_app.state.captures[identity].snapshot()[1] is not None:break",
    "if stream_server.started and all(c.snapshot()[1] is not None for c in stream_app.state.captures.values()):break")
remote = remote.replace("'scope':'single physical fbdev; vehicle screens; 2x300s relay soak'",
    "'scope':'ONE physical source duplicated into two independent encoders; 90s concurrent reception'")
compile(remote,'<dual-remote>','exec')
outdir=HERE/'dual-latency-clock-20261028'
assert not outdir.exists(), 'preserve prior trial; use a fresh output folder'
outdir.mkdir()
(outdir/'remote-source.py').write_text(remote,encoding='utf-8')
request=ns['request']


class Receiver:
    def __init__(self,t,item,identity):
        self.t=t;self.item=item;self.identity=identity
        self.frames=[];self.error=None;self.latest=None;self.first=None;self.last=None
        self.markers={};self.stop=threading.Event();self.ready=threading.Event()
        self.channel=None;self.worker=threading.Thread(target=self.run,daemon=True)
    def run(self):
        response=None
        try:
            ch,response=request(self.t,self.item['port'],f'/streams/{self.identity}.mjpeg',
                headers={'Authorization':'Bearer '+self.item['token']},stream=True)
            self.channel=ch;ch.settimeout(5)
            assert response.status==200
            buf=bytearray()
            while not self.stop.is_set():
                data=response.read(4096)
                if not data:raise EOFError('stream closed')
                buf.extend(data)
                while True:
                    start=buf.find(b'--frame\r\n');end=buf.find(b'\r\n\r\n',max(0,start))
                    if start<0 or end<0:break
                    import re
                    header=bytes(buf[start:end]).decode('ascii')
                    length=int(re.search(r'Content-Length: (\d+)',header)[1])
                    sequence=int(re.search(r'X-Frame-Sequence: (\d+)',header)[1])
                    assert 0<length<=2*1024*1024
                    if len(buf)<end+4+length+2:break
                    jpeg=bytes(buf[end+4:end+4+length]);del buf[:end+4+length+2]
                    received=time.perf_counter()
                    with Image.open(io.BytesIO(jpeg)) as image:
                        image.load()
                        assert image.size==(1280,720)
                        rgb=image.getpixel((140,140))[:3]
                    decoded=time.perf_counter()
                    self.frames.append({'received_monotonic':received,'decoded_monotonic':decoded,
                        'sequence':sequence,'jpeg_bytes':length,'sample_rgb':rgb})
                    self.latest=rgb;self.last=jpeg
                    if self.first is None:
                        self.first=jpeg;(outdir/f'{self.identity}-first.jpg').write_bytes(jpeg)
                        self.ready.set()
                    for identifier in range(1,31):
                        expected=(64+(identifier&3)*48,64+((identifier>>2)&3)*48,64+((identifier>>4)&3)*48)
                        if max(abs(a-b) for a,b in zip(expected,rgb))<=15:
                            self.markers.setdefault(identifier,decoded)
        except Exception as e:
            if not self.stop.is_set():self.error=type(e).__name__+': '+str(e)
        finally:
            if self.last:(outdir/f'{self.identity}-last.jpg').write_bytes(self.last)
            if response:response.close()
            if self.channel:self.channel.close()
    def finish(self):
        self.stop.set()
        if self.channel:self.channel.close()
        self.worker.join(timeout=7)
        assert not self.worker.is_alive(),'receiver thread did not stop'
        return {'output_id':self.identity,'frames':self.frames,'error':self.error,
            'decoder':'Pillow JPEG load + RGB pixel classification on PC; browser presentation excluded'}


def receive_both(t,item):
    assert request(t,item['port'],'/api/v1/streams')[0]==401
    receivers=[Receiver(t,item,key) for key in ['monitor-1','monitor-2']]
    measurements=[]
    try:
        for receiver in receivers:receiver.worker.start()
        for receiver in receivers:assert receiver.ready.wait(12), receiver.error or 'first frame timeout'
        start=time.perf_counter();next_report=start+30
        # 120 seconds of plain dual streaming, then 30 uniquely colored marker changes.
        while time.perf_counter()-start<20:
            assert all(not r.error for r in receivers),[r.error for r in receivers]
            if time.perf_counter()>=next_report:
                print(json.dumps({'event':'dual_progress','elapsed_s':round(time.perf_counter()-start),
                    'frames':[len(r.frames) for r in receivers]}),flush=True);next_report+=30
            time.sleep(.1)
        clock_probes=[]
        def calibrate(label):
            for _ in range(12):
                before=time.perf_counter()
                code,_,body=request(t,item['port'],'/probe/clock',headers={'Authorization':'Bearer '+item['token']})
                after=time.perf_counter();assert code==200
                remote_clock=json.loads(body)['board_clock']
                clock_probes.append({'phase':label,'pc_before':before,'pc_after':after,'board_clock':remote_clock,
                    'rtt_s':after-before,'offset_lower_s':remote_clock-after,'offset_upper_s':remote_clock-before})
                time.sleep(.03)
        calibrate('before')
        for identifier in range(1,31):
            # One PC monotonic clock: no NTP/clock-offset assumption. This is an
            # upper bound including PC->board command and board CDP paint scheduling.
            sent=time.perf_counter()
            code,_,body=request(t,item['port'],'/probe/marker','POST',{'id':identifier},
                {'Authorization':'Bearer '+item['token']})
            ack=time.perf_counter();assert code==200,(code,body[:200])
            reply=json.loads(body)
            deadline=sent+3
            while time.perf_counter()<deadline and not all(identifier in r.markers for r in receivers):time.sleep(.002)
            measurements.append({'id':identifier,'command_sent_pc_monotonic':sent,
                'command_ack_ms':(ack-sent)*1000,'expected_rgb':reply['rgb'],
                'board_command_monotonic':reply['board_command_monotonic'],
                'detected_pc':{r.identity:r.markers.get(identifier) for r in receivers},
                'request_to_decoded_pixel_upper_bound_ms':{r.identity:
                    (r.markers[identifier]-sent)*1000 if identifier in r.markers else None for r in receivers}})
            print(json.dumps({'event':'latency_sample','id':identifier,
                'upper_bound_ms':measurements[-1]['request_to_decoded_pixel_upper_bound_ms']}),flush=True)
            time.sleep(.65)
        calibrate('after')
        while time.perf_counter()-start<90:time.sleep(.1)
        return {'duration_s':time.perf_counter()-start,'latency':measurements,'clock_probes':clock_probes}
    finally:
        row={'receivers':[r.finish() for r in receivers],'measurements':measurements,'clock_probes':locals().get('clock_probes',[])}
        (outdir/'pc-receivers.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


t=ns['ns']['namespace']['connect']();channel=None
result={'scope':'two encoders, one source duplicated; NOT dual physical HDMI or distinct renderers',
    'transport':'authenticated HTTP MJPEG over pinned SSH direct-tcpip (board to this PC)',
    'latency_scope':'PC command sent -> board DOM paint request -> X11 capture -> JPEG encode -> SSH network -> PC JPEG decode + pixel recognition; conservative upper bound, not photon/browser latency',
    'stage':ns['stage']}
try:
    ns['stage_sources'](t)
    channel=t.open_session(timeout=10);channel.settimeout(420);channel.exec_command('python3 -')
    channel.sendall(remote.encode());channel.shutdown_write()
    for line in channel.makefile('rb'):
        item=json.loads(line)
        if item['event']=='ready':
            try:result['pc']=receive_both(t,item)
            finally:
                import paramiko
                sftp=paramiko.SFTPClient.from_transport(t)
                with sftp.open('/opt/xenova-graphics-probe/20261027-1ddf34f25d30/rootfs/run/pc-monitor-2-done','w') as f:f.write('done')
                sftp.close()
        elif item['event']=='complete':result['board']=item['result']
    result['remote_error']=channel.makefile_stderr('rb').read().decode()[-2500:]
    result['remote_exit']=channel.recv_exit_status()
finally:
    (outdir/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if channel:channel.close()
    t.close()
print(json.dumps({'event':'complete','exit':result.get('remote_exit'),'error':result.get('board',{}).get('error')}),flush=True)
