import gzip
import json
from pathlib import Path
import statistics

base=Path(__file__).parent/'dual-latency-clock-20261028'
raw=json.loads((base/'result.json').read_text(encoding='utf-8'))
pc=json.loads((base/'pc-receivers.json').read_text(encoding='utf-8'))

def stats(values):
    values=sorted(values)
    if not values:return None
    return {'n':len(values),'mean':statistics.mean(values),'p95':values[round((len(values)-1)*.95)],
            'max':max(values),'min':min(values)}

samples=raw.get('board',{}).get('pages',[{}])[0].get('relay',{}).get('samples',[])
valid=[s for s in samples if 'groups' in s]
weights=[b['monotonic']-a['monotonic'] for a,b in zip(valid,valid[1:])]
groups={}
for group in valid[0]['groups'] if valid else []:
    values=[s['groups'][group]['cpu_core_percent'] for s in valid[1:]]
    groups[group]=stats(values)
    groups[group]['time_weighted_mean']=sum(v*w for v,w in zip(values,weights))/sum(weights)
result={'scope':raw['scope'],'transport':raw['transport'],'latency_scope':raw['latency_scope'],
        'duration_s':raw.get('pc',{}).get('duration_s'),'remote_exit':raw.get('remote_exit'),
        'board_error':raw.get('board',{}).get('error'),'groups_cpu_core_percent':groups,
        'cpu_unit':'100%=one CPU core; Python includes diagnostic sampler; browser not part of sender+encoder target',
        'streams':[]}
if groups:
    result['sender_plus_encoders_cpu_time_weighted_percent']=groups['python_combined']['time_weighted_mean']+groups['encoder']['time_weighted_mean']
    result['single_core_average_target_passed']=result['sender_plus_encoders_cpu_time_weighted_percent']<=100
for receiver in pc['receivers']:
    frames=receiver['frames'];identity=receiver['output_id']
    intervals=[b['received_monotonic']-a['received_monotonic'] for a,b in zip(frames,frames[1:])]
    duration=frames[-1]['received_monotonic']-frames[0]['received_monotonic'] if len(frames)>1 else 0
    latency=[m['request_to_decoded_pixel_upper_bound_ms'].get(identity) for m in pc['measurements']]
    matched=[v for v in latency if v is not None]
    result['streams'].append({'output_id':identity,'error':receiver['error'],'frames':len(frames),
        'observed_fps':(len(frames)-1)/duration if duration else None,
        'jpeg_payload_mbps':sum(f['jpeg_bytes'] for f in frames[1:])*8/duration/1e6 if duration else None,
        'gaps_over_1s':sum(x>1 for x in intervals),
        'skipped_sequences':sum(max(0,b['sequence']-a['sequence']-1) for a,b in zip(frames,frames[1:])),
        'decode_ms':stats([(f['decoded_monotonic']-f['received_monotonic'])*1000 for f in frames]),
        'latency_attempts':len(latency),'latency_matched':len(matched),'latency_timeouts':sum(v is None for v in latency),
        'request_to_decoded_pixel_upper_bound_ms':stats(matched),
        'software_upper_bound_p95_500ms_passed':len(matched)==30 and stats(matched)['p95']<=500,
        'encoder_epochs':len({s['captures'][identity]['capture_epoch'] for s in valid}),
        'unavailable_samples':sum(s['captures'][identity]['status']!='live' for s in valid)})
board=raw.get('board',{})
result['cleanup']={k:board.get(k) for k in ['namespace_exit','feed_stopped','framebuffer_restored','restoration_differing_bytes','restored_active_vt']}
result['cleanup']['graphics_children_stopped']=board.get('graphics_child',{}).get('processes_stopped')
result['physical_dual_output_acceptance']=False
result['browser_or_photon_latency_acceptance']=False
result['temperature_max_celsius']=max((v['celsius'] for s in valid for v in s['temperatures']),default=None)
result['min_memory_available_bytes']=min((s['memory']['MemAvailable'] for s in valid),default=None)

probes=pc.get('clock_probes',[])
best=[min([p for p in probes if p['phase']==phase],key=lambda p:p['rtt_s']) for phase in ['before','after']]
low=min(p['offset_lower_s'] for p in best)
high=max(p['offset_upper_s'] for p in best)
mid=(low+high)/2
result['clock_calibration']={'all_probes':probes,'selected_min_rtt_probes':best,
    'offset_low_s':low,'offset_high_s':high,'offset_estimate_s':mid,
    'uncertainty_half_width_ms':(high-low)*500,
    'assumption':'PC/board perf_counter clock offset remains within the envelope of the best pre/post RTT brackets during this short trial; no NTP synchronization assumed.'}
for stream in result['streams']:
    identity=stream['output_id'];values=[];lower=[];upper=[]
    for marker in pc['measurements']:
        receiver=next(r for r in pc['receivers'] if r['output_id']==identity)
        candidates=[f['decoded_monotonic'] for f in receiver['frames']
            if f['decoded_monotonic']>=marker['command_sent_pc_monotonic']
            and max(abs(a-b) for a,b in zip(f['sample_rgb'],marker['expected_rgb']))<=15]
        if not candidates:continue
        detected=min(candidates)
        duration=detected-marker['board_command_monotonic']
        values.append((duration+mid)*1000)
        lower.append((duration+low)*1000);upper.append((duration+high)*1000)
    stream['eventual_markers_received']=len(values)
    stream['board_marker_request_to_pc_decoded_ms_estimate']=stats(values)
    stream['late_samples_included_in_final_distribution']=True
    stream['clock_uncertainty_p95_interval_ms']=[stats(lower)['p95'],stats(upper)['p95']]
    stream['board_to_decoded_p95_target_status']='unproven'
    if len(values)==30 and stats(upper)['p95']<=500:
        stream['board_to_decoded_p95_target_status']='within_500ms_with_measured_clock_envelope'
    elif stats(lower)['p95']>500:
        stream['board_to_decoded_p95_target_status']='exceeds_500ms_even_at_low_clock_bound'
result['latency_scope']='Board CDP marker-change request -> browser paint scheduling -> X11 capture -> JPEG encode -> actual SSH transport -> PC JPEG decode+pixel detection. Includes board paint scheduling; excludes PC->board control request, excludes physical photons and receiver browser display.'

(base/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(base/'samples.json.gz').write_bytes(gzip.compress(json.dumps({'board_result':raw,'pc':pc},ensure_ascii=False,separators=(',',':')).encode(),mtime=0))
print(json.dumps(result,ensure_ascii=False,indent=2))
